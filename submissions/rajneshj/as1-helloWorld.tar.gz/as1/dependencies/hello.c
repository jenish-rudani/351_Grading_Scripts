/*
helloworld.c
Purpose: Run a reaction time game on a beaglebone using embedded software and cross compilation
Author: Rajnesh Joshi
*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

//INFORMATION ON THE VALUE OF THE USER BUTTON'S STATUS
#define USERfile "/sys/class/gpio/gpio72/value"

//Random number ranges for main process suspension
#define MINIMUM_RAND_TIME = 500;
#define MAXIMUM_RAND_TIME = 3500;

//FILE DEFINITIONS FOR LED0
#define LED0brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED0trigger "/sys/class/leds/beaglebone:green:usr0/trigger"

//FILE DEFINITIONS FOR LED1
#define LED1brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED1trigger "/sys/class/leds/beaglebone:green:usr1/trigger"

//FILE DEFINITIONS FOR LED2
#define LED2brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED2trigger "/sys/class/leds/beaglebone:green:usr2/trigger"

//FILE DEFINITIONS FOR LED3
#define LED3brightness "/sys/class/leds/beaglebone:green:usr3/brightness"
#define LED3trigger "/sys/class/leds/beaglebone:green:usr3/trigger"

//runCommand
//Purpose: Allow linux commands to be ran in the c program
static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it 
    // so we don't get an error when closing the pipe.
    char buffer[1024];
        while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
            // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

//configureGPIO
//Purpose: Configure GPIO USER Pin, and set it to an input
static void configureGPIO(){
    runCommand("config-pin p8.43 gpio");
    runCommand("cd /sys/class/gpio/gpio72");
    runCommand("sudo echo in > direction");
}

//isButtonPressed
//Purpose: Check the status of the button by reading the USER GPIO file
bool isButtonPressed()
{
    bool buttonSate;
    FILE *pFile = fopen(USERfile, "r");

    if (pFile == NULL)
    {
        printf("ERROR: Unable to open GPIO file for read\n");
        exit(-1);
    }

    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // convert string to int
    int value = atoi(buff);
    if (!value)
        buttonSate = true;
    else
        buttonSate = false;

    fclose(pFile);
    return buttonSate;
}

//writeNoneToSingleLEDTrigger
//Purpose: Write none to the LED trigger so we can have nothing else triggering
static void writeNoneToSingleLEDTrigger(char* TriggerFile){
    FILE* pLedTriggerFile = fopen(TriggerFile, "w");

    if (pLedTriggerFile == NULL){
        printf("ERROR OPENING %s. \n", TriggerFile);
    }

    int charWritten = fprintf(pLedTriggerFile, "none");
    if (charWritten <= 0){
        printf("ERROR WRITING DATA\n");
        exit(1);
    }
    fclose(pLedTriggerFile);
}

//writeNoneAllLED
//Purpose: Write none to all LED triggers
static void writeNoneAllLED(){
    writeNoneToSingleLEDTrigger(LED0trigger);
    writeNoneToSingleLEDTrigger(LED1trigger);
    writeNoneToSingleLEDTrigger(LED2trigger);
    writeNoneToSingleLEDTrigger(LED3trigger); 
}

//turnOnLED
//Purpose: Turn on single LED by writing to its brightness file
static void turnOnLED(char* LEDFile){
    FILE * pLEDBrightnessFile = fopen(LEDFile, "w");

    if (pLEDBrightnessFile == NULL){
        printf("ERROR OPENING %s.", LEDFile);
        exit(1);
    }

    fprintf(pLEDBrightnessFile, "1");
    fclose(pLEDBrightnessFile);

}

//turnOffLED
//Purpose: Turn off single LED by writing to its brightness file
static void turnOffLED(char* LEDFile){
    FILE * pLEDBrightnessFile = fopen(LEDFile, "w");

    if (pLEDBrightnessFile == NULL){
        printf("ERROR OPENING %s.", LEDFile);
        exit(1);
    }

    fprintf(pLEDBrightnessFile, "0");
    fclose(pLEDBrightnessFile);

}

//turnOnAllLED
//Purpose: Turn on all LEDs by writing to all LED filesstatic 
void turnOnAllLED(){
    turnOnLED(LED0brightness);
    turnOnLED(LED1brightness);
    turnOnLED(LED2brightness);
    turnOnLED(LED3brightness);
}

//turnOffAllLED
//Purpose: Turn off all LEDs by writing to all LED files
static void turnOffAllLED(){
    turnOffLED(LED0brightness);
    turnOffLED(LED1brightness);
    turnOffLED(LED2brightness);
    turnOffLED(LED3brightness);
}

//getTimeInMs
//Purpose: Obtain the time in ms
static long long getTimeInMs(void) 
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 
    + nanoSeconds / 1000000;
    return milliSeconds;
}

//sleepForMs
//Purpose: Allow the program to be suspended for a certain amount of time in ms
static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

//displaySummary
//Purpose: Provided game summary output, and calculate if a new bestTime has been achieved
static void displaySummary(long long responseTime, long long bestTime){
    if (responseTime < bestTime){
        printf("New best time!\n");
        printf("Your reaction time was %lld, best so far in game was %lld \n", bestTime, bestTime);
        return;
    }

        printf("Your reaction time was %lld, best so far in game was %lld \n", responseTime, bestTime);
}


int main(){


    long long responseTime = 0;
    long long bestTime = responseTime;
    long long startTime;
    long long endTime;
	bool replay = true;

	configureGPIO();

	writeNoneAllLED();


	while(replay){
		
        bool gameLoop = true;
        //Begin with zero LEDs on
        turnOffAllLED();
   
		//Hold down the button, and once released...
		while(isButtonPressed()){
            // do nothing
		}
		
        if (!(isButtonPressed())){
                    //Turn on the LED0
        turnOnLED(LED0brightness);

        //Wait a random amount of time
        printf("When LED3 lights up, press the USER button\n");
        int sleepTime = rand() % (3500 + 1 -500) + 500;
        sleepForMs(sleepTime);

        //Turn on LED3
        turnOnLED(LED3brightness);

        //Begin Timer
        startTime = getTimeInMs(); 
        while(gameLoop){
            if (isButtonPressed())
            {
                endTime = getTimeInMs();
                // Calculate total time
                responseTime = endTime - startTime;
                break;
            }
            if ((getTimeInMs() - startTime) >= 5000)
            {
                printf("No input within 5000ms; quitting!\n");
                turnOffAllLED();
                replay = false;
                writeNoneAllLED();
                exit(-1);
            
            }

        }
        
        //Calculate total time
        responseTime = endTime - startTime;

        //Light up all LEDs
        turnOnAllLED();

        //Assess if the score was a new record or not, and display 
        if (responseTime == 0){
            displaySummary(5000, bestTime);
            turnOnAllLED();
        }
        else if (responseTime < bestTime || bestTime == 0)
        {
            turnOnAllLED();
            bestTime = responseTime;
            displaySummary(bestTime, bestTime);
        }
        else{
            turnOnAllLED();
            displaySummary(responseTime, bestTime);
        }
        }
        else
        {
            turnOnAllLED();
            displaySummary(5000,bestTime);
        }

    }

}

	
