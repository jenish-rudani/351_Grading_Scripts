#include <stdio.h>
#include <stdlib.h>
#include <time.h>   //nanosleep()
#include <stdbool.h> //bool

#define LED0_Brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_Brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_Brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_Brightness "/sys/class/leds/beaglebone:green:usr3/brightness"
#define LED0_Trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_Trigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_Trigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_Trigger "/sys/class/leds/beaglebone:green:usr3/trigger"
#define UserButtonValue "/sys/class/gpio/gpio72/value"
#define UserButtonDirection "/sys/class/gpio/gpio72/direction"
#define GpioExport "/sys/class/gpio/export"


static void writeToFile(const char * filename, const char * value);
static int readFromFile(char * filename);
static void setAllLEDBrightness(char * brightness);
static void setAllLEDTriggers(char * trigger);
static void gpioExport(int val);
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
static void command(char * command);
static long long randomTimeInMs(); //Range: 500ms to 3000ms

int main(void)
{
    setAllLEDTriggers("none"); //set led triggers
    setAllLEDBrightness("0");
    command("config-pin p8.43 gpio");
    writeToFile(UserButtonDirection, "in");
    gpioExport(72); //config pin for user button
    sleepForMs(300);
    printf("Hello embedded world, from Justin Jiang!\nWhen LED3 lights up, press the USER button!\n");
    long long bestTime = 5000;
    while(1)
    {
        long long waitStartTime = getTimeInMs();
        long long reactionTime = 0;
        bool reactedInTime = false;
        bool reactedEarly = false;
        while(readFromFile(UserButtonValue) == 0)
        {
            //Step 1: wait while user button is held
        }
        setAllLEDBrightness("0"); //Turn off all Leds
        writeToFile(LED0_Brightness, "1"); // Step 2: Light up LED0

        //Step 3 : wait between 500ms to 3000ms
        while(getTimeInMs() - waitStartTime != randomTimeInMs())
        {
            //If the user button is pressed while waiting
            if(readFromFile(UserButtonValue) == 0)
            {
                reactedEarly = true;
            }
        }
        //Step 4: If the user button is press early skip to Step 7 (light all LEDS)
        if(reactedEarly == true)
        {
            reactionTime = 5000;
            printf("Your recation time was %lldms; best so far in game is %lldms\n", reactionTime, bestTime);
            setAllLEDBrightness("1");
            continue;
        }
        //Step 5: Light up LED3 and start timer
        writeToFile(LED3_Brightness, "1");
        long long reactStartTime = getTimeInMs();

        //Step 6: While the time is less than 5000ms, If the User button is pressed record the reaction time
        while(getTimeInMs() < reactStartTime + 5000)
        {
            long long reactFinishTime = 0;
            if(readFromFile(LED3_Brightness) == 1 && readFromFile(UserButtonValue) == 0)
            {
                reactFinishTime = getTimeInMs();
                reactionTime = reactFinishTime - reactStartTime;
                //If the reaction time is faster than the best time, update best time
                if(reactionTime < bestTime)
                {
                    printf("New best time!\n");
                    bestTime = reactionTime;
                }
                //Step 7: Light up all the LEDS
                setAllLEDBrightness("1");
                //Step 8: display all Information
                printf("Your recation time was %lldms; best so far in game is %lldms\n", reactionTime, bestTime);
                reactedInTime = true;
                break;
            }
        }
        //If the user button was not pressed within 5000ms of LED3 being lit up
        if(reactedInTime == false)
        {
            printf("No input within 5000ms; quitting!\n");
            exit(1);
        }
    }
    return 0;
}

static void writeToFile(const char * filename, const char * value)
{
    FILE * file = fopen(filename, "w");
    if(file == NULL)
    {
        printf("ERROR: Unable to open %s\n", filename);
        exit(1);
    }
    fprintf(file,"%s",value);
    fclose(file);
}

static int readFromFile(char * filename)
{
    FILE * file = fopen(filename, "r");
    const int length = 1024;
    char buffer[length];
    fgets(buffer, length, file);
    fclose(file);
    int val = atoi(buffer);
    return val;
}

static void setAllLEDBrightness(char * brightness)
{
    writeToFile(LED0_Brightness, brightness);
    writeToFile(LED1_Brightness, brightness);
    writeToFile(LED2_Brightness, brightness);
    writeToFile(LED3_Brightness, brightness);
}

static void setAllLEDTriggers(char * trigger)
{
    writeToFile(LED0_Trigger, trigger);
    writeToFile(LED1_Trigger, trigger);
    writeToFile(LED2_Trigger, trigger);
    writeToFile(LED3_Trigger, trigger);
}

static void gpioExport(int val)
{
    FILE * file = fopen(GpioExport, "w");
    if(file == NULL)
    {
        printf("ERROR: Unable to open export file\n");
        exit(1);
    }
    fprintf(file, "%d", val);
    fclose(file);
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void command(char * command)
{
    system(command);
}

static long long randomTimeInMs()
{
    long long lowerBound = 500;
    long long upperBound = 3000;
    long long randomTime = (rand() % (upperBound - lowerBound + 1)) + lowerBound; // returns a time between 500 ms to 3000ms
    return randomTime;
}