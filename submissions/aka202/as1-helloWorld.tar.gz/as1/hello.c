/*
Written by: Amaan Khan
Last updated: 2022-10-04
This program runs on the beaglebone green and is used to
measure your reaction speed by how fast you can press a button
after it lights up
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

//LED 0 definitions
#define LED0trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED0brightness "/sys/class/leds/beaglebone:green:usr0/brightness"

//LED 1 definitions
#define LED1trigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED1brightness "/sys/class/leds/beaglebone:green:usr1/brightness"

//LED 2 definitions
#define LED2trigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED2brightness "/sys/class/leds/beaglebone:green:usr2/brightness"

//LED 3 definitions
#define LED3trigger "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED3brightness "/sys/class/leds/beaglebone:green:usr3/brightness"

// USER BUTTON value directory and value of button when being held down
#define USERButtonVALUE "/sys/class/gpio/gpio72/value"
#define BUTTONDOWN 48

#define MINIMUM_WAIT 500
#define MAXIMUM_WAIT 3000

#define TOO_LONG 5000

static long long getTimeInMs(void);
static void writeToFile(const char* fileName, const char* value);
static char readFirstFromFile(char *fileName);
static void runCommand(char* command);
static long long randomNumberInRange(int min, int max);
static void initializeButton();
static void initializeLEDs();
static void lightAllLEDs();
static void turnOffAllLEDs();
static void displaySummary();

int main(int argc, char *argv[]){
    initializeButton();
    initializeLEDs();

    int gamesPlayed = 0;
    int minWait = MINIMUM_WAIT;
    int maxWait = MAXIMUM_WAIT;
    int bestReactionTime = TOO_LONG;

    long long startTime = getTimeInMs();
    long long endTime = getTimeInMs();
    
    bool inputWithinFiveThousandMs = true;
    bool newGame = true;
    bool waitingRandomTime = false;
    printf("Hello embedded world, from Amaan!\n");
    printf("When LED3 lights up, press the USER button!\n");
    printf("To start playing press the USER button.\n");

    while(inputWithinFiveThousandMs){
        endTime = getTimeInMs();
        if(readFirstFromFile(USERButtonVALUE)==BUTTONDOWN){
            newGame = true;
        }
        while(newGame == true){
            if(readFirstFromFile(USERButtonVALUE)==BUTTONDOWN){
                writeToFile(LED0brightness,"1");
                startTime = getTimeInMs();
                waitingRandomTime = true;
            }else{
                turnOffAllLEDs();
                newGame = false;
            }
        }
        long long waitTime = randomNumberInRange(minWait,maxWait);
        long long startWait = getTimeInMs();
        bool userWaitedTime = false;
        long long endWait;
        while(waitingRandomTime){
            endWait=getTimeInMs();
            if(readFirstFromFile(USERButtonVALUE)==BUTTONDOWN){
                lightAllLEDs();
                displaySummary(TOO_LONG,bestReactionTime,gamesPlayed);
                gamesPlayed+=1;
                startWait = getTimeInMs();
                startTime = getTimeInMs();
                newGame = true;
                userWaitedTime = false;
                waitingRandomTime = false;
                break;
            }
            if((endWait-startWait)>waitTime){
                waitingRandomTime = false;
                userWaitedTime = true;
            }
        }
        if(userWaitedTime){
            startTime = getTimeInMs();
            writeToFile(LED3brightness,"1");
            int beginningReactionTime = getTimeInMs();
            int endingReactionTime = getTimeInMs();
            bool waitingForReaction = true;
            while(waitingForReaction){
                endTime = getTimeInMs();
                if(readFirstFromFile(USERButtonVALUE)==BUTTONDOWN){
                    startTime = getTimeInMs();
                    endingReactionTime = getTimeInMs();
                    lightAllLEDs();
                    if((endingReactionTime-beginningReactionTime)<bestReactionTime){
                        printf("New best time!\n");
                        bestReactionTime = (endingReactionTime-beginningReactionTime);
                    }
                    displaySummary(endingReactionTime-beginningReactionTime,bestReactionTime,gamesPlayed);
                    gamesPlayed+=1;
                    waitingForReaction = false;
                    newGame = true;
                }
                if((endTime-startTime)>TOO_LONG){
                    newGame= true;
                    break;
                }
            }
        }
        if((endTime-startTime)>TOO_LONG){
            printf("no input within 5000 ms; quitting!\n");
            inputWithinFiveThousandMs = false;
            turnOffAllLEDs();
        }
    }
    return 0;
}







static void displaySummary(int thisReaction, int bestReaction,int gamesPlayed){
    if(gamesPlayed==0){
         printf("your reaction time was %dms; best so far in this game is %dms.\n",thisReaction,thisReaction);
    }else{
    printf("your reaction time was %dms; best so far in this game is %dms.\n",thisReaction,bestReaction);
    }
}

static char readFirstFromFile(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
    printf("ERROR: Unable to open file (%s) for read\n", fileName);
    exit(-1);
    }

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];

    fgets(buff, MAX_LENGTH, pFile);

    // Close
    fclose(pFile);
    return buff[0];
}



static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}

static long long randomNumberInRange(int min, int max){
    srand(time(0));
    return (rand()%(max-min+1))+min;
}
static void initializeLEDs(){
    writeToFile(LED0brightness,"0");
    writeToFile(LED1brightness,"0");
    writeToFile(LED2brightness,"0");
    writeToFile(LED3brightness,"0");
    writeToFile(LED0trigger,"none");
    writeToFile(LED1trigger,"none");
    writeToFile(LED2trigger,"none");
    writeToFile(LED3trigger,"none");
}
static void  lightAllLEDs(){
    writeToFile(LED0brightness,"1");
    writeToFile(LED1brightness,"1");
    writeToFile(LED2brightness,"1");
    writeToFile(LED3brightness,"1");
}
static void turnOffAllLEDs(){
    writeToFile(LED0brightness,"0");
    writeToFile(LED1brightness,"0");
    writeToFile(LED2brightness,"0");
    writeToFile(LED3brightness,"0");
}
static void initializeButton(){
    runCommand("config-pin p8.43 gpio");
    runCommand("echo in > /sys/class/gpio/gpio72/direction");
}
static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}


static void writeToFile(const char* fileName, const char* value)
{
	FILE *pFile = fopen(fileName, "w");
	fprintf(pFile, "%s", value);
	fclose(pFile);
}






