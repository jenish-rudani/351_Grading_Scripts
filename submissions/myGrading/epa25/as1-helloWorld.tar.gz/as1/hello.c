#define LED0_PATH "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_PATH "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_PATH "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_PATH "/sys/class/leds/beaglebone:green:usr3/brightness"
#define USER_PATH "/sys/class/gpio/gpio72/value"
#define config_user "config-pin p8.43 gpio"
#define user_input "echo in > /sys/class/gpio/gpio72/direction"

#include <string.h> 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>


static long long getTimeInMs(void); // Function Given from Assignment1

static void sleepForMs(long long delayInMs);    // Function Given from Assignment1

static void runCommand(char* command);  // Function Given from Assignment1

int readFromFileToScreen(char *fileName);   // Function Given from GPIO guide

void turnOneLED(char *ledpath); // Function to turn on LED, from LED guide
   
void turnAllLED();  // Function to turn on all LEDS

void turnOffLED(char *ledpath); //Function to turn on LED, from LED guide

void turnOffAll();  // Funciton to shut off all LEDS



int main(int argc, char* args[])
{

printf("Hello embedded world, from Ethan!\n");

runCommand(config_user);    // Configs the User button
runCommand(user_input);     // Sets the User button as input

printf("\nWhen LED3 lights up, press the USER button!\n");


long long react_time, best_t = 5000; // 5000 is best time available 

while(1){

    
    
    turnOffAll(); // Turns of all LEDS to initialize 

   
    while(!readFromFileToScreen(USER_PATH))  // waits while user hold button
    {
    
    sleepForMs(10);
    }
    
    
    turnOneLED(LED0_PATH);  //Turns on LED0 to start program

    sleepForMs((rand()% 6 + 1 )* 500);  // Random time from 0.5 to 3s

   

    


        
    if(readFromFileToScreen(USER_PATH) == 0)    // If button is pressed before LED3 turns on
        {
        react_time = 5000;
        }

    while(readFromFileToScreen(USER_PATH))   //While button is not being pressed. The LED3 then turns on
        {
        turnOneLED(LED3_PATH);
        long long temp1 = getTimeInMs();    // time start
        long long temp2 = temp1;    // current time

        
        while((temp2-temp1) <= 5000)    // When your current time is less then start time, continue
            {
            temp2 = getTimeInMs();  // current time being checked over and over
            if ( (temp2 - temp1 ) > 5000)   // if the current time - start time is > 5000ms then exit the program
            {
            printf("No input within 5000ms, quitting!\n");
            exit(1);
            }
            if (!readFromFileToScreen(USER_PATH))   // When button is pressed, then record the reaction time by taking current - start
            {
            react_time = temp2 - temp1;
            break; // break and exit out of this loop
            }    
        }
    }
    
        
        turnAllLED();   // All LEDS turn on now 

        
        if(react_time < best_t) // If react time is less then the current best replace it
        {
            best_t = react_time;
            printf("New best time!\n");
        }

        printf("Your reaction time was %4lldms; ", react_time);
        printf( "Best so far in the game is %4lldms\n", best_t);

    turnOffAll(); // Turns off all LEDS to reset program
    
}


return 0;
}



static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;  
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}



static void sleepForMs(long long delayInMs)
{
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}


static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}



int readFromFileToScreen(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read value
int var;
fscanf(pFile, "%d", &var);
// Close
fclose(pFile);
return var;
}





void turnOneLED(char *ledpath) // Function to turn on LED, from LED guide
    {
        FILE *pLedBrightnessFile = fopen(ledpath, "w");
            if (pLedBrightnessFile == NULL) {
                printf("ERROR OPENING %s.", ledpath);
                exit(1);
            }
            int charWritten = fprintf(pLedBrightnessFile, "1");
            if (charWritten <= 0){
                printf("ERROR WRITING DATA");
                exit(1);
                
        }
        fclose(pLedBrightnessFile);
    }
    


void turnAllLED()
    {
        turnOneLED(LED0_PATH);
        turnOneLED(LED1_PATH);
        turnOneLED(LED2_PATH);
        turnOneLED(LED3_PATH);
    }

void turnOffLED(char *ledpath)

{
       {
        FILE *pLedBrightnessFile = fopen(ledpath, "w");
            if (pLedBrightnessFile == NULL) {
                printf("ERROR OPENING %s.", ledpath);
                exit(1);
            }
            int charWritten = fprintf(pLedBrightnessFile, "0");
            if (charWritten <= 0){
                printf("ERROR WRITING DATA");
                exit(1);
                
        }
        fclose(pLedBrightnessFile);
    }
}

void turnOffAll() {
    turnOffLED(LED0_PATH);
    turnOffLED(LED1_PATH);
    turnOffLED(LED2_PATH);
    turnOffLED(LED3_PATH);
}
