#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define DA_TRIGGER_FILE_NAME0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define DA_TRIGGER_FILE_NAME1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define DA_TRIGGER_FILE_NAME2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define DA_TRIGGER_FILE_NAME3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define DA_BRIGHTNESS_FILE_NAME0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define DA_BRIGHTNESS_FILE_NAME1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define DA_BRIGHTNESS_FILE_NAME2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define DA_BRIGHTNESS_FILE_NAME3 "/sys/class/leds/beaglebone:green:usr3/brightness"

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void setLEDTriggers(char path[], char *trigger)
{
    FILE *pLedTriggerFile = fopen(path, "w");
    fprintf(pLedTriggerFile, trigger);
    fclose(pLedTriggerFile);   
}


static void setLEDBrightness(char path[], char *brightnessLevel)
{
    FILE *pLedBrightnessFile = fopen(path, "w");
    fprintf(pLedBrightnessFile, brightnessLevel);
    fclose(pLedBrightnessFile);
}

int readFromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
// Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
// Close
    fclose(pFile);
    return atoi(buff);
}

static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
 // printf("--> %s", buffer); // Uncomment for debugging
    }
 // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
 }
}

void turnOnLED0(){
    setLEDTriggers(DA_TRIGGER_FILE_NAME0, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME1, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME2, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME3, "none");

    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME0, "1");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME1, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME2, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME3, "0");
}

void turnOnLED3(){
    setLEDTriggers(DA_TRIGGER_FILE_NAME0, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME1, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME2, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME3, "none");

    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME0, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME1, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME2, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME3, "1");
}

void turnOnAllLEDs(){
    setLEDTriggers(DA_TRIGGER_FILE_NAME0, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME1, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME2, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME3, "none");

    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME0, "1");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME1, "1");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME2, "1");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME3, "1");
}

void turnOffAllLEDs(){
    setLEDTriggers(DA_TRIGGER_FILE_NAME0, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME1, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME2, "none");
    setLEDTriggers(DA_TRIGGER_FILE_NAME3, "none");

    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME0, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME1, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME2, "0");
    setLEDBrightness(DA_BRIGHTNESS_FILE_NAME3, "0");
}

int main(int argc, char* args[])
{
    
    printf("Hello embedded world, from Clinton!\n");
    printf("When LED3 lights up, press the USER button!\n");
    runCommand("config-pin p8.43 gpio");
    runCommand("config-pin -q p8.43");
    
    long long recordTime = 5000;
    
    while(1){

        bool hasTheUserCheated = false;
        

        while(readFromFileToScreen("/sys/class/gpio/gpio72/value") == 0){

        }
        turnOnLED0();
        srand(time(NULL));
        long long randomDelayTime = (500 + rand()%2501);
        long long randomDelayTimeInterval = randomDelayTime/50;
        long long reactionTime = 0;
        int i = 0;
        
        while(i < 50){
            sleepForMs(randomDelayTimeInterval);
            if (readFromFileToScreen("/sys/class/gpio/gpio72/value") == 0){ //when the user presses the button before the delay runs out 
                
                reactionTime = 5000;
                if(reactionTime < recordTime){
                    recordTime = reactionTime;
                    printf("New best time!\n");
                }
                hasTheUserCheated = true;
                break;    
            }
            i++;
        }
        turnOnLED3();
        long long startTime = getTimeInMs();
        
        while(hasTheUserCheated == false){

            if(readFromFileToScreen("/sys/class/gpio/gpio72/value") == 0){
                long long timeWhenPressed = getTimeInMs();
                reactionTime = timeWhenPressed - startTime;
                
                if(reactionTime < recordTime){
                    recordTime = reactionTime;
                    printf("New best time!\n");
                }
                break;

            }
            long long endTime = getTimeInMs();
            if(endTime - startTime >= 5000){
                turnOffAllLEDs();

                printf("No input within 5000ms; quitting!\n");
                
                exit(1);
            }
        }

        turnOnAllLEDs();  
        printf("Your reaction time was %lld; best so far in game is %lld \n", reactionTime, recordTime);

         
    }
    


    return 0;
}
