// Include the header file
#include "hello.h"

// main function
int main()
{
    // Intializes random number gen seed
    srand((unsigned)time(0));
    // Initialize and set brightness of LEDs
    ledSetup();
    // Initialize USER Button
    initButton();
    // Print welcome message
    printf("Hello embedded world, from Sahaj Singh!\n\n");
    printf("When LED3 lights up, press the USER button!\n");

    // Variables
    int mainLoop = 1;
    int gameLoop = 1;
    int noResponse = 0;
    long long bestTime = 0;
    long long reactionTime = 0;

    // Main loop
    while (mainLoop)
    {
        // Read button state
        int buttonPressed = readButton();
        // Start Round if button is not pressed
        if (!buttonPressed)
        {
            // Set all leds to off
            allSet(0);
            // Then start game by setting LED0 to on state
            setBrightness(LED0_BRIGHTNESS, 1);
            // wait a random amount of time between 0.5 and 3 seconds
            long long delay = (rand() % timerUpperLimit) + timerLowerLimit;
            sleepForMs(delay);
            // check if button is pressed already
            int earlyPress = readButton();
            if (earlyPress)
            {
                // If button is pressed, don't start game
                gameLoop = 0;
                reactionTime = invalidResponseLimit;
            }
            else
            {
                // If button is not pressed, start game
                gameLoop = 1;
                // turn on LED3
                setBrightness(LED3_BRIGHTNESS, 1);
                // start timer
                long long startTime = getTimeInMs();
                // wait for button press
                while (gameLoop)
                {
                    // check if button is pressed
                    int gameButton = readButton();
                    if (getTimeInMs() >= (startTime + invalidResponseLimit))
                    {
                        // If button is not pressed within 5 seconds, end the round and quit the game
                        printf("No input within 5000ms; Quitting.\n");
                        mainLoop = 0;
                        noResponse = 1;
                        break;
                    }
                    if (gameButton)
                    {
                        // If button is pressed, end the round and record the time
                        reactionTime = getTimeInMs() - startTime;
                        break;
                    }
                }
            }
            // End Round and print results if button is pressed
            if (!noResponse)
            {
                // Turn on all LEDs
                allSet(1);
                // Check for new best time
                if (reactionTime < bestTime || bestTime == 0)
                {
                    bestTime = reactionTime;
                    printf("New best time!\n");
                }
                // Print reaction time and best time of all rounds
                printf("Your reaction time was %lld ms; best so far in game is %lld ms\n", reactionTime, bestTime);
            }
        }
    }
    // Initialize and set brightness of LEDs
    ledSetup();
    return 0;
}
