// Header Guard
#ifndef HELLO_H
#define HELLO_H

// Include header files for C libraries
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

// Path to LED Trigger files
#define LED0_TRIGGER "/sys/class/leds/beaglebone:green:usr0/trigger" // USER LED0
#define LED1_TRIGGER "/sys/class/leds/beaglebone:green:usr1/trigger" // USER LED1
#define LED2_TRIGGER "/sys/class/leds/beaglebone:green:usr2/trigger" // USER LED2
#define LED3_TRIGGER "/sys/class/leds/beaglebone:green:usr3/trigger" // USER LED3

// Path to LED Brightness files
#define LED0_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr0/brightness" // USER LED0
#define LED1_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr1/brightness" // USER LED1
#define LED2_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr2/brightness" // USER LED2
#define LED3_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr3/brightness" // USER LED3

// Path to USER Button files
#define BUTTON_DIRECTION "/sys/class/gpio/gpio72/direction" // USER Button Direction
#define BUTTON_VALUE "/sys/class/gpio/gpio72/value"         // USER Button Value

// Other Definitions
#define bufferSize 1024           // Buffer size for file I/O
#define invalidResponseLimit 5000 // Maximum time to wait for button press
#define timerUpperLimit 2501      // Upper limit for random delay
#define timerLowerLimit 500       // Lower limit for random delay

// Function to check if file was opened correctly
void OpenCheck(FILE *fp, char *message)
{
    // Check for null pointer (file not opened)
    if (fp == NULL)
    {
        printf("Error: %s\n", message);
        exit(-1);
    }
}

// Function to check if file was written to correctly
void WrittenCheck(int status, char *message)
{
    // Check for error (file not written to)
    if (status < 0)
    {
        printf("Error: %s\n", message);
        exit(-1);
    }
}

// Function to initialize all LEDs
void initLEDs()
{
    FILE *pLedTrigger = NULL;
    int charWritten = 0;

    // Initialize LED0 settings
    pLedTrigger = fopen(LED0_TRIGGER, "w");
    OpenCheck(pLedTrigger, "Failed to open LED0 trigger file.");
    charWritten = fprintf(pLedTrigger, "none");
    WrittenCheck(charWritten, "Failed to write to LED0 trigger file.");
    fclose(pLedTrigger);

    // Initialize LED1 settings
    pLedTrigger = fopen(LED1_TRIGGER, "w");
    OpenCheck(pLedTrigger, "Failed to open LED1 trigger file.");
    charWritten = fprintf(pLedTrigger, "none");
    WrittenCheck(charWritten, "Failed to write to LED1 trigger file.");
    fclose(pLedTrigger);

    // Initialize LED2 settings
    pLedTrigger = fopen(LED2_TRIGGER, "w");
    OpenCheck(pLedTrigger, "Failed to open LED2 trigger file.");
    charWritten = fprintf(pLedTrigger, "none");
    WrittenCheck(charWritten, "Failed to write to LED2 trigger file.");
    fclose(pLedTrigger);

    // Initialize LED3 settings
    pLedTrigger = fopen(LED3_TRIGGER, "w");
    OpenCheck(pLedTrigger, "Failed to open LED3 trigger file.");
    charWritten = fprintf(pLedTrigger, "none");
    WrittenCheck(charWritten, "Failed to write to LED3 trigger file.");
    fclose(pLedTrigger);
}

// Function to set the brightness of the LED
void setBrightness(char *path, int brightness)
{
    FILE *pLedBrightness = NULL;
    int charWritten = 0;

    // Open the LED brightness file and set the brightness value
    pLedBrightness = fopen(path, "w");
    OpenCheck(pLedBrightness, "Failed to open LED brightness file.");
    charWritten = fprintf(pLedBrightness, "%d", brightness);
    WrittenCheck(charWritten, "Failed to write to brightness file.");
    fclose(pLedBrightness);
}

// Function to set the brightness of all LEDs
void allSet(int brightness)
{
    setBrightness(LED0_BRIGHTNESS, brightness);
    setBrightness(LED1_BRIGHTNESS, brightness);
    setBrightness(LED2_BRIGHTNESS, brightness);
    setBrightness(LED3_BRIGHTNESS, brightness);
}

// Function to intialize the LEDs and then set the brightness
void ledSetup()
{
    // Initialize LEDs to NONE and set brightness to 0
    initLEDs();
    allSet(0);
}

// Proivded funtion to get time in milliseconds
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

// Proivded to sleep the current time in milliseconds
static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}

// Function to run linux commands
static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[bufferSize];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

// Initialize the USER Button
void initButton()
{
    // configure button to be gpio
    runCommand("config-pin p8.43 gpio");

    FILE *pButton = NULL;
    int charWritten = 0;

    // Set the direction of the button to input
    pButton = fopen(BUTTON_DIRECTION, "w");
    OpenCheck(pButton, "Failed to open button file.");
    charWritten = fprintf(pButton, "in");
    WrittenCheck(charWritten, "Failed to write to button file.");
    fclose(pButton);
}

// Function to read the USER Button is pressed
int readButton()
{
    FILE *pButton = NULL;
    int buttonValue = 0;

    pButton = fopen(BUTTON_VALUE, "r");
    OpenCheck(pButton, "Failed to open button file.");
    fscanf(pButton, "%d", &buttonValue);
    fclose(pButton);
    buttonValue = !buttonValue;
    return buttonValue;
}

#endif