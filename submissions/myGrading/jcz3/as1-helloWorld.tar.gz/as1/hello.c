#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define LED_TRIGGER_PATH "/sys/class/leds/beaglebone:green:usr%d/trigger"
#define LED_BRIGHTNESS_PATH "/sys/class/leds/beaglebone:green:usr%d/brightness"
#define userButton "/sys/class/gpio/gpio72/value"

void writeToTriggerFile(char* trigger)
{
    FILE *pLedTriggerFile = fopen(trigger, "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", trigger);
        exit(1);
    }
    int charWritten = fprintf(pLedTriggerFile, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedTriggerFile);
}

void writeToBrightnessFile(char* brightness, int i)
{
    FILE *pLedTriggerFile = fopen(brightness, "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", brightness);
        exit(1);
    }
    int charWritten = fprintf(pLedTriggerFile,"%d", i);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedTriggerFile);
}

void writingToGPIO(float value){
    FILE *pFile = fopen("/sys/class/gpio/export", "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(pFile, "%f", value);
    fclose(pFile);
}

int readFromFileToScreen(char *button)
{
    FILE *pFile = fopen(button, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", button);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    //printf("Read: '%s'\n", buff);
    return(atoi(buff));
}

void setLedOnOrOff(int led0, int led1, int led2, int led3){
    int size = 100;
    char trigger[size];
    char brightness[size];
    for(int i = 0; i < 4; i++){
        sprintf(trigger, LED_TRIGGER_PATH, i); 
        writeToTriggerFile(trigger);
        sprintf(brightness, LED_BRIGHTNESS_PATH, i); 
        writeToBrightnessFile(brightness,0);
    }
    if(led0 == 1 && led1 == 1 && led2 == 1 && led3 == 1){
        for(int i = 0; i < 4; i++){
            sprintf(brightness, LED_BRIGHTNESS_PATH, i); 
            writeToBrightnessFile(brightness,1);
        }
    } else if(led0 == 1){
        sprintf(brightness, LED_BRIGHTNESS_PATH, 0);  
        writeToBrightnessFile(brightness,1);
    } else if(led3 == 1){
        sprintf(brightness, LED_BRIGHTNESS_PATH, 3);  
        writeToBrightnessFile(brightness,1);
    }  else{
        //this is left empty
    }
}

static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}

void waitIfUserHoldDownUserButton(){
    while(readFromFileToScreen(userButton) == 0){
    }
}

int main(){
    printf("Hello embedded world, from Leon!\n");
    printf("When LED3 lights up, press the USER button!\n");
    runCommand("config-pin p8.43 gpio");
    runCommand("config-pin -q p8.43");
    runCommand("echo 72 > export");
    writingToGPIO(72);
    long long bestTime = 5000;
    long long currentTime = 0;
    while(1){
        bool userCheated = false;
        waitIfUserHoldDownUserButton();
        setLedOnOrOff(1,0,0,0);
        srand(time(NULL));
        long long randomNumber = ((rand() % (2501)) + 500);
        long long randomTimer = (randomNumber/100);
        for(int i =0; i < 100; i++){
            if(readFromFileToScreen(userButton) == 1 ){
                sleepForMs(randomTimer);
            } else{
                userCheated = true;
                break;
            }
        }
        if(userCheated == true){
            currentTime = 5000;
            if(bestTime > currentTime){
                printf("New best time!\n");
                bestTime = currentTime;
            }
        } else if(userCheated == false){
            long long startTime = getTimeInMs();
            while(readFromFileToScreen(userButton) != 0){
                setLedOnOrOff(0,0,0,1);
                long long timerCheck = getTimeInMs();
                if(readFromFileToScreen(userButton) == 0){
                    long long stopTime = getTimeInMs();
                    currentTime = (stopTime - startTime);
                    if(bestTime > currentTime){
                        printf("New best time!\n");
                        bestTime = currentTime;
                    }
                    break;
                 } else if((timerCheck - startTime) > 5000){
                    printf("No input within 5000ms; quitting!\n");
                    setLedOnOrOff(0,0,0,0);
                    exit(1);
                }
            }
        } 
        printf("Your reaction time was %lld; best so far in game is %lld \n",currentTime,bestTime);
        setLedOnOrOff(1,1,1,1);
        sleepForMs(1000);
     }
    return 0;
}
