#ifndef TIMING_H_
#define TIMING_H_
#include <time.h>

#define _POSIX_C_SOURCE 200809L

// Returns a long long value that represents the current time in ms
long long getTimeInMs(void);

// Works as a "wait for 'delayInMs' ms" function
void sleepForMs(long long delayInMs);

#endif