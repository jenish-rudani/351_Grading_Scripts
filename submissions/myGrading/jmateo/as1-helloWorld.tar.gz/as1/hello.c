#include <stdio.h>
#include <sys/wait.h>
#include "timing.h"
#include "leds.h"
#include "button.h"

void runCommand(char* command);

//must execute config-pin to force the button's pin to be treated as GPIO
//must configure the button's pin to be input
//use timers

int main(){
    char *myName = "Justin";
    printf("Hello embedded world, from %s!\n", myName);
    // Set up Button
    runCommand("config-pin p8.43 gpio"); //force the button's pin to be treated as GPIO
    writeToFile(BUTTON_pathDirection, "in");
    writeToFile(BUTTON_pathactiveLow, "1");
    // Initialize LEDs to "none" trigger, off
    setTrigger(LED0_pathTrigger, "none");
    setTrigger(LED1_pathTrigger, "none");
    setTrigger(LED2_pathTrigger, "none");
    setTrigger(LED3_pathTrigger, "none");
    setBrightness(LED0_pathBrightness, false);
    setBrightness(LED1_pathBrightness, false);
    setBrightness(LED2_pathBrightness, false);
    setBrightness(LED3_pathBrightness, false);

    long long bestTime = 10000;
    int gameCount = 1;
    srand(time(NULL));
    printf("The game: Click the button to initiate the game, click again once LED3 lights up. Easy!\n");
    // Loop this as long as the player wants to play
    while(1){
        long long startTime = getTimeInMs();
        long long currentTime = getTimeInMs();
        bool play = false;
        // Only initiate game once player doesn't press button, then presses, then lets go
        while(currentTime - startTime < 5000){
            if (readButton(BUTTON_pathValue)){
                while(readButton(BUTTON_pathValue));
                play = true;
                break;
            }
            currentTime = getTimeInMs();
        }
        if (!play){
            printf("No input within 5 seconds... Goodbye!\n");
            break;
        }
        sleepForMs(250);
        printf("Starting game #%d!\n", gameCount++);
        
        // Turn on LED0
        setBrightness(LED0_pathBrightness, true);
        setBrightness(LED1_pathBrightness, false);
        setBrightness(LED2_pathBrightness, false);
        setBrightness(LED3_pathBrightness, false);

        // Initialize needed time references
        startTime = getTimeInMs();
        currentTime = getTimeInMs();
        long long randomTime = (rand() % 2500) + 500; // ms
        long long responseTime = 0;
        bool end = false; 
        //sleepForMs(randomTime);
        while(currentTime - startTime < randomTime){
            if (readButton(BUTTON_pathValue)){
                printf("Pressed too early!\n");
                responseTime = 5000;
                end = true;
                break;
            }
            currentTime = getTimeInMs();
        }

        // // Check if the user pressed the button too soon
        // if (readButton(BUTTON_pathValue)){ //pressed too soon
        //     responseTime = 5000;
        //     end = true;
        // }
        
        // Start the timer, which the result will be their response time
        if (!end){
            setBrightness(LED3_pathBrightness, true);
            // runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");
            startTime = getTimeInMs();
            currentTime = getTimeInMs();
            while(1){
                if (readButton(BUTTON_pathValue)){
                    responseTime = currentTime - startTime;
                    break;
                }
                currentTime = getTimeInMs();
                if (currentTime - startTime > 5000){ //lost time
                    printf("You took too long to press the button.\n");
                    break;
                }
            }
        }

        // Set all LEDs to on
        setBrightness(LED0_pathBrightness, true);
        setBrightness(LED1_pathBrightness, true);
        setBrightness(LED2_pathBrightness, true);
        setBrightness(LED3_pathBrightness, true);

        // Calculate the resulting response time, update best time if needed
        if(!end)
            responseTime = currentTime - startTime;
        if (responseTime < bestTime)
            bestTime = responseTime;
        printf("Response Time: %lld ms, Best Response Time: %lld ms\n", responseTime, bestTime);
        //printf("Do you want to continue? Press the button within 5 seconds if so.\n");
        sleepForMs(500);
    }

    // Reset all configurations of LEDs
    setTrigger(LED0_pathTrigger, "none");
    setTrigger(LED1_pathTrigger, "none");
    setTrigger(LED2_pathTrigger, "none");
    setTrigger(LED3_pathTrigger, "none");
    setBrightness(LED0_pathBrightness, false);
    setBrightness(LED1_pathBrightness, false);
    setBrightness(LED2_pathBrightness, false);
    setBrightness(LED3_pathBrightness, false);
    return 0;
}

// Implementation wholely inspired from assignment document (Brian Fraser)
void runCommand(char* command){
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}