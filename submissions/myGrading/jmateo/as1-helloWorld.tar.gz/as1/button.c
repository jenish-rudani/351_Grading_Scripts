#include "button.h"
#include <stdio.h>

// Implementation wholely inspired from assignment document (Brian Fraser)
void writeToFile(char *fileName, char *toWrite){
    FILE *pFile = fopen(fileName, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }

    fprintf(pFile, toWrite);

    fclose(pFile);
}

// Implementation partially inspired from assignment document (Brian Fraser)
int readButton(char *fileName){
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    // Read string (line)
    char result[MAX_LENGTH];
    fgets(result, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    if (result[0] == '1')
        return 1;
    else   
        return 0;
}