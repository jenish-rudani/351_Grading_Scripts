#ifndef LEDS_H_
#define LEDS_H_
#include <stdbool.h>
#include <stdlib.h>

// Paths of LED characteristics that need to be set
#define LED0_path "/sys/class/leds/beaglebone:green:usr0"
#define LED1_path "/sys/class/leds/beaglebone:green:usr1"
#define LED2_path "/sys/class/leds/beaglebone:green:usr2"
#define LED3_path "/sys/class/leds/beaglebone:green:usr3"
#define LED0_pathTrigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_pathTrigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_pathTrigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_pathTrigger "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED0_pathBrightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_pathBrightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_pathBrightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_pathBrightness "/sys/class/leds/beaglebone:green:usr3/brightness"

// Sets the trigger with the string trigger at the path LED_pathTrigger
void setTrigger(char *LED_pathTrigger, char *trigger);

// Sets the brightness with the string state at the path LED_pathBrightness
void setBrightness(char *LED_pathBrightness, bool state);

#endif