#include "leds.h"
#include <stdio.h>

// Implementation wholely inspired from assignment document (Brian Fraser)
void setTrigger(char *LED_pathTrigger, char *trigger){
    FILE *pLedTriggerFile = fopen(LED_pathTrigger, "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", LED_pathTrigger);
        exit(1);
    }
    int charWritten = fprintf(pLedTriggerFile, trigger);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedTriggerFile);
}

// Implementation wholely inspired from assignment document (Brian Fraser)
void setBrightness(char *LED_pathBrightness, bool state){
    FILE *pLedBrightnessFile = fopen(LED_pathBrightness, "w");
    if (pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", LED_pathBrightness);
        exit(1);
    }
    int charWritten = fprintf(pLedBrightnessFile, "%d", state);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedBrightnessFile);
}