/*
* Description: Prints the message "Hello embedded world, from Kaleigh!" then
*              loops through a button reaction game.
* Author: Kaleigh Toering
* Sources Used: Assignment 1 Description
*/

#include <stdio.h>
#include <stdbool.h>
#include "led.h"
#include "button.h"
#include "timer.h"


int main() {
    // Run Button and LED Initialization Configuration
    led_setAllTriggersToNone();
    led_turnAllOff();
    button_configForGPIO(BUTTON_USER_PIN_SPECIFER);
    button_setToInput(BUTTON_USER_GPIO_DIRECTION_FILEPATH);
    timer_setSpecificTimer(300);

    // Display the hello-world welcome messgae
    printf("Hello embedded world, from Kaleigh!\n\n");
    printf("When LED3 lights up, press the USER button!\n");

    // Set default best time to max time
    int userBestTime = 5000;

    // Loop through program until timeout termination
    while(true) {
        // Check if USR button is already pressed
        while (button_isPressed(BUTTON_USER_GPIO_VALUE_FILEPATH) == true);

        // Turn on LED0
        led_turnOn(LED_0_BRIGHTNESS_FILEPATH);

        // Set random timer (500 ms, 3000ms)
        int minNumberMs = 500;
        int maxNumberMs = 3000;
        timer_setRandomTimer(minNumberMs, maxNumberMs);

        int userResponseTime = 0;

        // CIf user pressed the button too early, assign max time
        if (button_isPressed(BUTTON_USER_GPIO_VALUE_FILEPATH) == true) {
            userResponseTime = 5000;
        }

        else {
            // Turn on LED3
            led_turnOn(LED_3_BRIGHTNESS_FILEPATH);

            // Record timer start time
            long long startTime = timer_recordStartTime();

            // Wait until timeout or button press
            while (button_isPressed(BUTTON_USER_GPIO_VALUE_FILEPATH) == false) {
                if (timer_checkCurrentTimerValue(startTime) > 5000) break;
            }
            
            // Record response time 
            userResponseTime = timer_checkCurrentTimerValue(startTime);
            
            // Alert user of timeout 
            if ( userResponseTime> 5000) {
                printf("No input within 5000ms; quitting!\n");
                led_turnAllOff();
                return 0;
            }
        }

        // Turn on all LEDs
        led_turnAllOn();

        // Check if this round was the user's best time
        if (userResponseTime < userBestTime) {
            printf("New best time!\n");
            userBestTime = userResponseTime;
        }

        // Print out game statistics 
        printf("Your reaction time was %4d; best so far in the game is %4d.\n", userResponseTime, userBestTime);
        
        // Turn off all LEDs
        led_turnAllOff();
    }

    return 0;
}