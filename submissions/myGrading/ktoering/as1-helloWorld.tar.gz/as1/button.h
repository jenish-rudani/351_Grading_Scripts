/*
* Description: Contains functions to control the BeagleBone Button
* Author: Kaleigh Toering
* Sources Used: ENSC 351 GPIO guide, Assignment 1 runCommand code examples
*/

// header guards
#ifndef BUTTON_H
#define BUTTON_H

// library includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// program specifc information
#define BUTTON_USER_PIN_SPECIFER "p8.43"
#define BUTTON_GPIO_EXPORT_FILEPATH "/sys/class/gpio/export"
#define BUTTON_USER_GPIO_VALUE_FILEPATH "/sys/class/gpio/gpio72/value"
#define BUTTON_USER_GPIO_DIRECTION_FILEPATH "/sys/class/gpio/gpio72/direction"
#define BUTTON_USER_LINUX_GPIO_NUMBER "72"

// Configures the specified button for GPIO using the config-pin command
void button_configForGPIO(char* bbgPinSpecifer);

// Sets GPIO button to input by writing to the GPIO direction file
void button_setToInput(char* gpioDirectionFilePath);

// Returns true if the button specified by the gpio file path 
// is currntly being pressed, else false
bool button_isPressed(char* gpioVaueFilePath);

#endif