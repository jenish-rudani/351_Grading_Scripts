/*
* Description: Contains functions which control the BeagleBone LEDs
* Author: Kaleigh Toering
* Sources Used: ENSC 351 LED guide
*/

// header guards
#ifndef LED_H
#define LED_H
#include <stdio.h>
#include <stdlib.h>

// define file paths to access led trigger files
#define LED_0_TRIGGER_FILEPATH "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED_1_TRIGGER_FILEPATH "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED_2_TRIGGER_FILEPATH "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED_3_TRIGGER_FILEPATH "/sys/class/leds/beaglebone:green:usr3/trigger"

// define file paths to access led brightness files
#define LED_0_BRIGHTNESS_FILEPATH "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED_1_BRIGHTNESS_FILEPATH "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED_2_BRIGHTNESS_FILEPATH "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED_3_BRIGHTNESS_FILEPATH "/sys/class/leds/beaglebone:green:usr3/brightness"

// Turn a single LED on, given the brightness file path
void led_turnOn(char* ledBrightnessFilePath);

// Turn a single LED off, given the brightness file path
void led_turnOff(char* ledBrightnessFilePath);

// Changes a single LED's trigger to "none" given trigger file path
void led_setTriggerToNone(char* ledTriggerFilePath);

// Sets all LED Triggers used in this program to none 
void led_setAllTriggersToNone(void);

// Turns on all LEDs used in this program
void led_turnAllOn(void);

// Turns off all LEDs used in this program
void led_turnAllOff(void);

#endif