/*
* Description: Contains all timer related functions
* Author: Kaleigh Toering
* Sources Used: ENSC 351 Assignment 1 timer example code,
*               https://stackoverflow.com/questions/1202687/how-do-i-get-a-specific-range-of-numbers-from-rand
*/

// header guards
#ifndef TIMER_H
#define TIMER_H

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

// commonly used timing conversion values
#define TIMER_CONVERSION_NS_PER_MS "1000000"
#define TIMER_CONVERSION_NS_PER_SECOND "1000000000"

// Triggers program to sleep for a random amount of milliseconds between min and max values 
void timer_setRandomTimer(long long minPossibleMs, long long maxPossibleMs);

// Triggers program to sleep for the specified amount of milliseconds
void timer_setSpecificTimer(long long timerLength);

// Returns current time, used to start a non-waiting timer
long long timer_recordStartTime(void);

// Returns length of time elpased between specified start time and current time,
// used to calculate time elapsed for a non-waiting timer
long long timer_checkCurrentTimerValue(long long startTime);

#endif