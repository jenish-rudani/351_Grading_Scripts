/*
* Description: Contains all timer related functions
* Author: Kaleigh Toering
* Sources Used: ENSC 351 Assignment 1 timer example code,
*               https://stackoverflow.com/questions/1202687/how-do-i-get-a-specific-range-of-numbers-from-rand
*/

#include "timer.h"

// Returns the current time in milliseconds
static long long helper_getCurrentTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

// Triggers program to sleep for the specified time in milliseconds
static void helper_sleepForMs(long long delayInMs)
{
    long long delayNs = delayInMs * atoi(TIMER_CONVERSION_NS_PER_MS);
    int seconds = delayNs / atoi(TIMER_CONVERSION_NS_PER_SECOND);
    int nanoseconds = delayNs % atoi(TIMER_CONVERSION_NS_PER_SECOND);

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
    return;
}

// Triggers program to sleep for a random amount of milliseconds between min and max values 
void timer_setRandomTimer(long long minPossibleMs, long long maxPossibleMs) 
{
    // seed rand() with time 
    srand(time(NULL));
    // logic from: https://stackoverflow.com/questions/1202687/how-do-i-get-a-specific-range-of-numbers-from-rand
    long long randomTimeMs = (rand() % (maxPossibleMs - minPossibleMs + 1)) + minPossibleMs;
    
    helper_sleepForMs(randomTimeMs);
    return;
}

// Triggers program to sleep for the specified amount of milliseconds
void timer_setSpecificTimer(long long timerLength) 
{
    helper_sleepForMs(timerLength);
    return;
}

// Returns current time, used to start a non-waiting timer
long long timer_recordStartTime(void) 
{
    return helper_getCurrentTimeInMs();
}

// Returns length of time elpased between specified start time and current time,
// used to calculate time elapsed for a non-waiting timer
long long timer_checkCurrentTimerValue(long long startTime) {
    return helper_getCurrentTimeInMs() - startTime;
}