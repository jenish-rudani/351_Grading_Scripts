/*
* Description: Contains functions which control the BeagleBone LEDs
* Author: Kaleigh Toering
* Sources Used: ENSC 351 LED guide
*/

#include "led.h"

// Turn a single LED on, given the brightness file path
void led_turnOn(char* ledBrightnessFilePath)
{
    // open brightness file
    FILE *ledTriggerFile = fopen(ledBrightnessFilePath, "w");
    if (ledTriggerFile == NULL) {
        printf("ERROR: cannot open %s\n", ledBrightnessFilePath);
        exit(1);
    }

    // write "1" to turn on
    int writer = fprintf(ledTriggerFile, "1");
    if (writer <= 0) {
        printf("ERROR: cannot write to %s\n", ledBrightnessFilePath);
    }

    // close file
    fclose(ledTriggerFile);
    return;
}

// Turn a single LED off, given the brightness file path
void led_turnOff(char* ledBrightnessFilePath)
{
    // open brightness file
    FILE *ledTriggerFile = fopen(ledBrightnessFilePath, "w");
    if (ledTriggerFile == NULL) {
        printf("ERROR: cannot open %s\n", ledBrightnessFilePath);
        exit(1);
    }

    // write "0" to turn off
    int writer = fprintf(ledTriggerFile, "0");
    if (writer <= 0) {
        printf("ERROR: cannot write to %s\n", ledBrightnessFilePath);
    }

    // close file
    fclose(ledTriggerFile);
    return;
}

// Changes a single LED's trigger to "none" given trigger file path
void led_setTriggerToNone(char* ledTriggerFilePath) 
{
    // open trigger file
    FILE *ledTriggerFile = fopen(ledTriggerFilePath, "w");
    if (ledTriggerFile == NULL) {
        printf("ERROR: cannot open %s\n", ledTriggerFilePath);
        exit(1);
    }

    // write "none" to file
    int writer = fprintf(ledTriggerFile, "none");
    if (writer <= 0) {
        printf("ERROR: cannot write to %s\n", ledTriggerFilePath);
    }

    // close file
    fclose(ledTriggerFile);
    return;
}

// Sets all LED Triggers used in this program to none 
void led_setAllTriggersToNone(void) 
{
    led_setTriggerToNone(LED_0_TRIGGER_FILEPATH);
    led_setTriggerToNone(LED_1_TRIGGER_FILEPATH);
    led_setTriggerToNone(LED_2_TRIGGER_FILEPATH);
    led_setTriggerToNone(LED_3_TRIGGER_FILEPATH);

    return;
}

// Turns on all LEDs used in this program
void led_turnAllOn(void) 
{
    led_turnOn(LED_0_BRIGHTNESS_FILEPATH);
    led_turnOn(LED_1_BRIGHTNESS_FILEPATH);
    led_turnOn(LED_2_BRIGHTNESS_FILEPATH);
    led_turnOn(LED_3_BRIGHTNESS_FILEPATH);
    
    return;
}

// Turns off all LEDs used in this program
void led_turnAllOff(void) 
{
    led_turnOff(LED_0_BRIGHTNESS_FILEPATH);
    led_turnOff(LED_1_BRIGHTNESS_FILEPATH);
    led_turnOff(LED_2_BRIGHTNESS_FILEPATH);
    led_turnOff(LED_3_BRIGHTNESS_FILEPATH);
    
    return;
}
