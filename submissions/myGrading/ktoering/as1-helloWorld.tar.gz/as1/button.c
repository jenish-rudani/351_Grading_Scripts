/*
* Description: Contains functions to control the BeagleBone Button
* Author: Kaleigh Toering
* Sources Used: ENSC 351 GPIO guide, Assignment 1 runCommand code examples
*/

#include "button.h"

// Runs a specified linux command
static void helper_runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it so no error upon closing pipe
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL) {
            break;
        }
    }

    // Get the exit code rom the pope; non-zero is error
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf("  command:    %s\n", command);
        printf("  exit code:  %d\n", exitCode);
    }
    return;
}

// Configures the specified button for GPIO using the config-pin command
void button_configForGPIO(char* bbgPinSpecifer) 
{
    // construct config command
    char fullConfigCommand[30];
    strcpy(fullConfigCommand, "config-pin ");
    strcat(fullConfigCommand, bbgPinSpecifer);
    strcat(fullConfigCommand, " gpio");

    helper_runCommand(fullConfigCommand);
    return;
}

// Sets GPIO button to input by writing to the GPIO direction file
void button_setToInput(char* gpioDirectionFilePath)
{
    // write Linux GPIO number to export file
    FILE *pFile = fopen(gpioDirectionFilePath, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open the direction file.\n");
        exit(1);
    }

    // write "in" to file
    fprintf(pFile, "in");

    // close file
    fclose(pFile);
    return;
}

// Returns true if the button specified by the gpio file path 
// is currntly being pressed, else false
bool button_isPressed(char* gpioVaueFilePath) 
{
    // read from pin file
    FILE *pFile = fopen(gpioVaueFilePath, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", gpioVaueFilePath);
        exit(1);
    }

    // read string
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);

    // close file
    fclose(pFile);

    // return negated status value, default is 0 for pressed and 1 for high
    return !atoi(buff);
}