/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

//beagle led path
#define led "/sys/class/leds/beaglebone:green:usr" // at top of file  

//getTime
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
//command line 
static void runCommand(char* command);
// turn off LEDS
static void turnOffLEDS(void);
static void turnOffLED0(void);
static void turnOffLED1(void);
static void turnOffLED2(void);
static void turnOffLED3(void);
// turn on LEDS
static void turnOnLEDS(void);
static void turnOnLED0(void);
static void turnOnLED1(void);
static void turnOnLED2(void);
static void turnOnLED3(void);
// get and read gpio data
static void enableUserBtn(void);
static int readUserBtn(void);
static int mainGame(long long *bestTime);

int main()
{
    // initialize led and userbtn
    turnOffLEDS();
    enableUserBtn();
    
    // set big time as the bestTime for beginning
    long long bestTime = 1000000;
    // welcome message
    printf("Hello embedded world, from sarah \n\n");
    // instructions
    printf("WHEN LED3 lights up, press the USER button! \n");

    int timesPlayed = 0;
    // game will continute until timeElapsed is less than 5000
    while(mainGame(&bestTime) == 1) {
    	timesPlayed++;
    }
    printf("No input within 5000ms; that's a wrap! \n");
    return 0;
}

static int mainGame(long long *bestTime){
    // wait for user to let go of user button
    bool userInit = false;
    while(userInit == false) {
    	if(readUserBtn() == 1) {
    	  userInit = true;
    	  turnOnLED0();
    	  break;
    	}
    }
    // choose a random time between 500ms and 3000ms to sleep for
    double randTime = (double)rand() / ((double)RAND_MAX + 1);
    randTime = randTime*(3000 - 500) + 500;
    sleepForMs(randTime);
    // if the user btn is already down, set time to 5000
    if(readUserBtn() == 0) {
        turnOnLEDS();
        long long currentTime = 5000;
     	printf("You pressed the button way too soon! \n");
     	if(currentTime < *bestTime) {
            *bestTime = currentTime;
            printf("WOOW! That's your new best time! \n");
        }
     	printf("Your reaction time was %lld ms \n", currentTime);
     	printf("Your best so far is %lld ms\n", *bestTime);
     	return 1;
    }
    // turn on LED3 to start the game
    turnOnLED3();
    long long startTime = getTimeInMs();
    // when the button is down record time
    while((getTimeInMs() - startTime <= 5000)) {
        if(readUserBtn() == 0) {
            turnOnLED3();
     	    long long endTime = getTimeInMs();
     	    long long currentTime = endTime - startTime;
     	    //test for the best time
     	    if(currentTime < *bestTime) {
                *bestTime = currentTime;
                printf("WOOW! That's your new best time! \n");
            }
            // turn on LEDS
            turnOnLEDS();
            printf("Your reaction time was %lld ms \n", currentTime);
            printf("Your best so far is %lld ms \n", *bestTime);
            // turn LEDs off for the next game
            turnOffLEDS();
            return 1;
        }
    } 
  return 0;
}

static void enableUserBtn(void) {
    runCommand("config-pin p8.43 gpio");
    //Use fopen() to open the file for write access
    FILE *pFile = fopen("/sys/class/gpio/export", "w");
    if (pFile == NULL) {
	    printf("ERROR: Unable to open export file.\n");
	    exit(1);
    }
    // Write to data to the file using fprintf():
    fprintf(pFile, "%d", 72);
    // Close the file using fclose():
    fclose(pFile); 
    
    // not sure why this command doesnt work, folder doesn't exist for some reason
    // code works without it regardless so I'm leaving it out but i do know this is a step 	that should happen
    /*
    FILE *inputFilePointer = fopen("/sys/class/gpio/gpio72/direction", "w");
    if (inputFilePointer == NULL) {
	    printf("ERROR: Unable to open input file.\n");
	    exit(1);
    }
    // Write to data to the file using fprintf():
    fprintf(inputFilePointer, "in");
    // Close the file using fclose():
    fclose(inputFilePointer); 
    */
}


static int readUserBtn(void) {
    FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", "sys/class/gpio/gpio72/value" );
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    int val = atoi(buff);
    return val;
}

// led functions
static void turnOnLEDS(void) {
    turnOnLED0();
    turnOnLED1();
    turnOnLED2();
    turnOnLED3();
}

static void turnOnLED0(void) {  
    FILE *pLedBrightnessFile = fopen(led "0/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "1");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedBrightnessFile);
}

static void turnOnLED1(void) {  
    FILE *pLedBrightnessFile = fopen(led "1/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "1");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedBrightnessFile);
}

static void turnOnLED2(void) {  
    FILE *pLedBrightnessFile = fopen(led "2/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "1");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedBrightnessFile);
}

static void turnOnLED3(void) {  
    FILE *pLedBrightnessFile = fopen(led "3/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "1");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedBrightnessFile);
}


// turn off leds
static void turnOffLED0(void) {
    FILE *pLedTriggerFile = fopen(led "0/trigger", "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWritten = fprintf(pLedTriggerFile, "0");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedTriggerFile);
    
    FILE *pLedBrightnessFile = fopen(led "0/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "0");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedBrightnessFile);
}


static void turnOffLED1(void) {

    FILE *pLedTriggerFile = fopen(led "1/trigger", "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWritten = fprintf(pLedTriggerFile, "0");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedTriggerFile);
    
    FILE *pLedBrightnessFile = fopen(led "1/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "0");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedBrightnessFile);
}

static void turnOffLED2(void) {
    FILE *pLedTriggerFile = fopen(led "2/trigger", "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWritten = fprintf(pLedTriggerFile, "0");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedTriggerFile);
    
    FILE *pLedBrightnessFile = fopen(led "2/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "0");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedBrightnessFile);
}

static void turnOffLED3(void) {
    FILE *pLedTriggerFile = fopen(led "3/trigger", "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWritten = fprintf(pLedTriggerFile, "0");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedTriggerFile);
    
    FILE *pLedBrightnessFile = fopen(led "3/brightness", "w");
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", led);
        exit(1);
    }
    
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "0");
    if (charWrittenBrightness <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedBrightnessFile);
}

static void turnOffLEDS(void) {
    turnOffLED0();
    turnOffLED1();
    turnOffLED2();
    turnOffLED3();
}

static long long getTimeInMs(void) {
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs) {
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command) {
 // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
 // printf("--> %s", buffer); // Uncomment for debugging
    }
 // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}





