#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>

#define LED0_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED0_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr0/brightness"

#define LED1_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED1_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr1/brightness"

#define LED2_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED2_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr2/brightness"

#define LED3_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED3_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr3/brightness"

#define USER_BUTTON_DIR_FILE "/sys/class/gpio/gpio72/direction"
#define USER_BUTTON_INPUT_FILE "/sys/class/gpio/gpio72/value"

static long long getTimeInMs(void) // Taken from assignment document
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}

static void sleepForMs(long long delayInMs) // Taken from assignmnet document
{
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command) // Taken from assignment document
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}

void file_write(char* filename, char* value)
{
    FILE *pfile = fopen(filename, "w");
    if(pfile == NULL)
    {
        printf("Error opening %s\n", filename);
    }
    
    if(fprintf(pfile, value) <= 0)
    {
        printf("Error writing to %s\n", filename);
        exit(1);
    }
    fclose(pfile);
}

void button_game_init(void)
{
    runCommand("config-pin p8.43 gpio");
    file_write(USER_BUTTON_DIR_FILE, "in");
    file_write(LED0_TRIGGER_FILE, "none");
    file_write(LED1_TRIGGER_FILE, "none");
    file_write(LED2_TRIGGER_FILE, "none");
    file_write(LED3_TRIGGER_FILE, "none");
}

bool is_user_button_pushed(void)
{
    FILE *user_button_file = fopen(USER_BUTTON_INPUT_FILE, "r");
    if(user_button_file == NULL)
    {
        printf("Error opening button file\n");
        exit(1);
    }
    char buff[1024];
    if(!fgets((buff), sizeof(buff), user_button_file))
    {
        printf("Error reading from file\n");
        exit(1);
    }
    fclose(user_button_file);
    return !atoi(buff);  
    }

void wait_random_time(void)
{
    srand(time(NULL));
    uint32_t wait_time = rand() % 5000;
    sleepForMs(wait_time);

}

int main(int argc, char* args[])
{
    printf("Hello Embedded World\n");

    button_game_init();
    printf("When LED3 lights up press the USER button!\n");
    long long elapsedTime = 0;
    long long startTime = 0;
    long long best_time = 5000;
    bool cheaterDetectedFlag = 0;
    while(1)
    {
        while(is_user_button_pushed()); // wait for user to let go of button
        
        file_write(LED1_BRIGHTNESS_FILE, "0");
        file_write(LED2_BRIGHTNESS_FILE, "0");
        file_write(LED3_BRIGHTNESS_FILE , "0");

        wait_random_time();
        
        elapsedTime = 0;
        cheaterDetectedFlag = 0;
        if(is_user_button_pushed()) // detect cheater
        {
            printf("Cheater Detected!!\n");
            cheaterDetectedFlag = 1;
            elapsedTime = 5000;
        }
        
        file_write(LED0_BRIGHTNESS_FILE, "0");
        file_write(LED3_BRIGHTNESS_FILE, "1");

        startTime = getTimeInMs(); //start timer
        while(elapsedTime < 5000)
        {
            elapsedTime = getTimeInMs() - startTime;
            if(is_user_button_pushed()) // exit while loop if button is pushed
            {   
                break;
            }
        }

        //turn all leds on
        file_write(LED0_BRIGHTNESS_FILE, "1"); 
        file_write(LED1_BRIGHTNESS_FILE, "1");
        file_write(LED2_BRIGHTNESS_FILE, "1");
        
        if(elapsedTime >= 5000 && !cheaterDetectedFlag) //check if timeout condition occured
        {
            printf("No input detected, quitting\n");
            break;
        }
        //save time if it is the best time so far
        if(elapsedTime < best_time)
        {
            best_time = elapsedTime;
            printf("You beat your best time!\n");
        }
        printf("You took %lld milliseconds!\n", elapsedTime);
        printf("Best time so far is %lld\n", best_time);
    }
    file_write(LED0_BRIGHTNESS_FILE, "0");
    file_write(LED1_BRIGHTNESS_FILE, "0");
    file_write(LED2_BRIGHTNESS_FILE, "0");
    file_write(LED3_BRIGHTNESS_FILE, "0");
    return 0;
}