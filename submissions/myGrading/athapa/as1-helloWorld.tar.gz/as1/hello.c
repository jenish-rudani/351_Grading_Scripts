#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define usr0_led_trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
static const int MAX_LENGTH = 1024;

static void runCommand(char* command);
static long long getTimeInMs(); 
static void sleepForMs(long long delayInMs);
int readFromFileToScreen(char *fileName);

void turn_led0_on();
void turn_led1_on();
void turn_led2_on();
void turn_led3_on();

void turn_led0_off();
void turn_led1_off();
void turn_led2_off();
void turn_led3_off();

int main(void) 
{
	runCommand("config-pin p8.43 gpio");

	turn_led0_off();
	turn_led1_off();
	turn_led2_off();
 	turn_led3_off();

	printf("Hello embedded world!\n\n");
	
	// part 2- LIGHT UP ONLY LED 0
	turn_led0_on();

	// waits for 4 (s)
	//sleepForMs(4000);

	long long init_time = getTimeInMs();
	long long user_button_press_time = 0;
	long long reaction_time = 0;
	long long timer_time = 0;
	long long best_time = 99999;
	long long random_time = 0;
	//CHANGE TO RANDOM TIME
	srand(time(NULL));
	int flag = 0;

	while (1==1) {
		reaction_time = 0;
		random_time = rand()%2500 + 500;
		init_time = getTimeInMs();
		timer_time = getTimeInMs();
		// printf("%i", buff);
		printf("When LED3 lights up, press the USER button!\n");
		sleepForMs(200);
		flag = 0;
		timer_time = getTimeInMs();
		while((timer_time - init_time) < random_time){
			timer_time = getTimeInMs();
			if (readFromFileToScreen("/sys/class/gpio/gpio72/value") == 1){
				printf("Pressed too early!\n");
				reaction_time = 5000;
				flag = 1;
				break;
			}
		}

		turn_led3_on();
		init_time = getTimeInMs();
		timer_time = getTimeInMs();
		if (flag == 0){
			while((timer_time - init_time) < 5000){
				timer_time = getTimeInMs();
				if(readFromFileToScreen("/sys/class/gpio/gpio72/value") == 1){
					user_button_press_time = getTimeInMs();
					reaction_time = user_button_press_time - init_time;
					break;
				}
			}

			if((timer_time - init_time) >= 5000)
			{
				printf("took longer than 5 seconds!\n");
				reaction_time = 5000;
				if (reaction_time < best_time)
					best_time = reaction_time;
				printf("Your reaction time was %lldms, and your record is %lldms\n", reaction_time, best_time);
				turn_led3_off();
				break;
			}
				
		// while(readFromFileToScreen("/sys/class/gpio/gpio72/value")) 
		// {
		// 	printf("1");
		// 	user_button_press_time = getTimeInMs();
		// 	reaction_time = user_button_press_time - init_time;
		// }
		}
		if (reaction_time < best_time)
			best_time = reaction_time;
		printf("Your reaction time was %lldms, and your record is %lldms\n", reaction_time, best_time);
		turn_led3_off();
	
	}
	return (0);
}

void turn_led0_off(){
	runCommand("echo none > /sys/class/leds/beaglebone:green:usr0/trigger");
}

void turn_led1_off(){
	runCommand("echo none > /sys/class/leds/beaglebone:green:usr1/trigger");
}

void turn_led2_off(){
	runCommand("echo none > /sys/class/leds/beaglebone:green:usr2/trigger");
}

void turn_led3_off(){
	runCommand("echo none > /sys/class/leds/beaglebone:green:usr3/trigger");
}

void turn_led0_on(){
	runCommand("echo default-on > /sys/class/leds/beaglebone:green:usr0/trigger");
}

void turn_led1_on(){
	runCommand("echo default-on > /sys/class/leds/beaglebone:green:usr1/trigger");
}

void turn_led2_on(){
	runCommand("echo default-on > /sys/class/leds/beaglebone:green:usr2/trigger");
}

void turn_led3_on(){
	runCommand("echo default-on > /sys/class/leds/beaglebone:green:usr3/trigger");
}

static void runCommand(char* command)
{
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	
	// Ignore output of the command; but consume it 
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
			break;
		// printf("--> %s", buffer); // Uncomment for debugging
	}

	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) {
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
 	}
}


static void sleepForMs(long long delayInMs)
{
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;

	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
}


static long long getTimeInMs() 
{
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
 	long long milliSeconds = seconds * 1000 
				+ nanoSeconds / 1000000;
 	return milliSeconds;
}

int readFromFileToScreen(char *fileName)
{
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
		printf("ERROR: Unable to open file (%s) for read\n", fileName);
		exit(-1);
	}	

	// Read string (line)
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	
	// Close
	fclose(pFile);
	if(buff[0] == '1')
		return 0;
	else
		return 1;
	
	// printf("Read: '%s'\n", buff); // Uncomment for debugging
	//return (buff[0]);
}