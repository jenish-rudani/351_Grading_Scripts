//This program runs a reaction time game using the user button and LED array on the BBG
//written by Dante Umpherville-Choy on October 6, 2021

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define LED_0_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED_0_TRIGGER "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED_1_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED_1_TRIGGER "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED_2_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED_2_TRIGGER "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED_3_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr3/brightness"
#define LED_3_TRIGGER "/sys/class/leds/beaglebone:green:usr3/trigger"
#define USER_BUTTON "/sys/class/gpio/gpio72/direction"
#define BUTTON_INPUT "/sys/class/gpio/gpio72/value"
#define GPIO_CONFIG "config-pin p8.43 gpio"
#define MAX_RESPONSE_TIME 5000
#define MIN_WAIT_TIME 500
#define MAX_WAIT_TIME 3000


static void sleepForMS(long long delayInMs){
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
    
}

//gets the current state of the USER button from file
static int getGPIOInput(){
    FILE* readFile = fopen(BUTTON_INPUT, "r");
    if(!readFile){
        printf("error: could not open input file\n");
        exit(1);
    }
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, readFile);
    int value = atoi(buff);
    if(value == 1){
        return 0;
    }else{
        return 1;
    }
}

//isOn 0-> off, 1-> on
static void setLEDState(char* path, char* isOn){
    FILE* brightnessFile = fopen(path, "w");
    if(!brightnessFile){
        printf("error: could not open brightness file\n");
        exit(1);
    }
    int writeSuccess = fprintf(brightnessFile, isOn);
    if(writeSuccess <= 0){
        printf("error: failed to write data");
        exit(1);
    }
    fclose(brightnessFile);
}

//set the state of the led triggers off
static void setTrigger(char* path){
    FILE* triggerFile = fopen(path, "w");
    if(!triggerFile){
        printf("error: could not open trigger file\n");
        exit(1);
    }
    int writeSuccess = fprintf(triggerFile, "none");
    if(writeSuccess <= 0){
        printf("error: failed to write data");
        exit(1);
    }
    fclose(triggerFile);
}

//set the gpio pin 72 to in 
static void setGPIOIn(){
     FILE* directionFile = fopen(USER_BUTTON, "w");
    if(!directionFile){
        printf("error: could not open direction file\n");
        exit(1);
    }
    int writeSuccess = fprintf(directionFile, "in");
    if(writeSuccess <= 0){
        printf("error: failed to write data");
        exit(1);
    }
    fclose(directionFile);
}

//retrieve a random int between 500 and 3000 (ms)
static int getRandTimeMS(){
    //code for getting rand number between two values from https://www.geeksforgeeks.org/generating-random-number-range-c/
    int time = (rand() % (MAX_WAIT_TIME-MIN_WAIT_TIME+1))+MIN_WAIT_TIME;
    return time;
}

//get time in ms since the epoch
static long long getTimeInMs(void){
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}



int main(int args, char* argv[]){
    //set up user button to be gpio
    //end game flag to keep track of exit coondition
    int endGame = 0;
    //default fastest time set to 1 ms longer than the longest possible time
    int fastestTime = 5001;
    //reaction time measures user speed
    int reactionTime;
    //first game flag to not print fastest time in the first round
    int firstGame = 1;

    runCommand(GPIO_CONFIG);
    sleepForMS(300);

    printf("Hello embedded world, from Dante!\n");

    setTrigger(LED_0_TRIGGER);
    setTrigger(LED_1_TRIGGER);
    setTrigger(LED_2_TRIGGER);
    setTrigger(LED_3_TRIGGER);
 
    setGPIOIn(USER_BUTTON);

    setLEDState(LED_0_BRIGHTNESS, "0");
    setLEDState(LED_1_BRIGHTNESS, "0");
    setLEDState(LED_2_BRIGHTNESS, "0");
    setLEDState(LED_3_BRIGHTNESS, "0");
    
    //outer game loop
    while(endGame == 0){
        setLEDState(LED_0_BRIGHTNESS, "0");
        setLEDState(LED_1_BRIGHTNESS, "0");
        setLEDState(LED_2_BRIGHTNESS, "0");
        setLEDState(LED_3_BRIGHTNESS, "0");
        int falseStartFlag = 0;
        int fastestTimeFlag = 0;
        //while button on, do not continue

        while(getGPIOInput() == 1){
            //sleep because otherwise it loops too fast and results in a file read error
            sleepForMS(20);
        }

        int waitPeriod = getRandTimeMS();
        long long initialTime = getTimeInMs();

        //waiting section, if user presses button, flag to skip to 7
        setLEDState(LED_0_BRIGHTNESS, "1");
        while((getTimeInMs() - initialTime) < waitPeriod && falseStartFlag == 0){
            if(getGPIOInput() == 1){
                falseStartFlag = 1;
                reactionTime = MAX_RESPONSE_TIME;
            }
            //sleep because otherwise it loops too fast and results in a file read error
            sleepForMS(20);
        }

        //if no false start, turn on light and wait for reaction
        
        if(falseStartFlag != 1){
            long long reactStartTime = getTimeInMs();
            setLEDState(LED_3_BRIGHTNESS, "1");
            while((getTimeInMs() - reactStartTime < MAX_RESPONSE_TIME) && (getGPIOInput() == 0)){
                sleepForMS(20);
            }

            //exit with input 
            if(getGPIOInput() == 1){
                reactionTime = getTimeInMs()-reactStartTime;
                if(reactionTime<fastestTime){
                    fastestTime = reactionTime;
                    fastestTimeFlag = 1;
                }
            }else{
                endGame = 1;
                printf("No input within 5000 ms; quitting!\n");
                return 0;
            }
        }

    //cleanup
    setLEDState(LED_0_BRIGHTNESS, "1");
    setLEDState(LED_1_BRIGHTNESS, "1");
    setLEDState(LED_2_BRIGHTNESS, "1");
    setLEDState(LED_3_BRIGHTNESS, "1");

    //don't want to print a best score to screen in the first round
    if(firstGame == 1){
        printf("Your reaction time was %i.\n", reactionTime);
        //turn off first game flag
        firstGame = 0; 
    }else{
        printf("Your reaction time was %i; best so far in game is %i\n", reactionTime, fastestTime);
    }
    
    if(fastestTimeFlag == 1){
        printf("New Best Time!\n");
    }

    //wait for a few seconds before starting the next game to let user read the results
    sleepForMS(3000); 

    }

    return 0;
}
