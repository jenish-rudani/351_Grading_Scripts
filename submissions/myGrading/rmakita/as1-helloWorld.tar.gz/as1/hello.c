#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h> 
#include <time.h>

#define USER "/sys/class/gpio/gpio72/value"
#define brightness_led0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define brightness_led1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define brightness_led2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define brightness_led3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define trigger_led0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define trigger_led1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define trigger_led2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define trigger_led3 "/sys/class/leds/beaglebone:green:usr3/trigger"


void trigger_control(char* fileName, char* triggerVal)
{
    FILE *pLedTriggerFile_led0 = fopen(fileName, "w");
    if (pLedTriggerFile_led0 == NULL) {
        printf("ERROR OPENING %s.", fileName);
}
    int charWritten0 = fprintf(pLedTriggerFile_led0, triggerVal);
    if (charWritten0 <= 0) {
        printf("ERROR WRITING DATA");
}
fclose(pLedTriggerFile_led0);
}
    

static void brightness_control(char* fileName, char* brightnessVal)
{
    FILE *pLedBrightnessFile_led0 = fopen(fileName, "w");
    if(pLedBrightnessFile_led0 == NULL) {
        printf("ERROR OPENING %s.", fileName);
    }
    int brightness0 = fprintf(pLedBrightnessFile_led0, brightnessVal);
    if (brightness0 <= 0) {
        printf("ERROR WRITING DATA");
    }
fclose(pLedBrightnessFile_led0);
}


static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}


static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}


static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
 // printf("--> %s", buffer); // Uncomment for debugging
    }
 // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}


char readFromFileToScreen(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
    printf("ERROR: Unable to open file (%s) for read\n", fileName);
    exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
return buff[0] - '0';
}

int main()
{
    printf("Hello embedded world, from Riku! When LED 3 lights up, press the USER button!\n");
    trigger_control(trigger_led0, "none");
    trigger_control(trigger_led1, "none");
    trigger_control(trigger_led2, "none");
    trigger_control(trigger_led3, "none");
    brightness_control(brightness_led0, "0");
    brightness_control(brightness_led1, "0");
    brightness_control(brightness_led2, "0");
    brightness_control(brightness_led3, "0");
    runCommand("config-pin p8.43 gpio");
    readFromFileToScreen(USER);

    //Initializing Variables 
        long long response_time = 0;
        long long start_time = 0;
        long long response_time_2 = 0;
        long long start_time_2 = 0;
        long long best_time = 5000;
        long long compare_time = 0;
        int num_times_pushed = 0;
        bool time_limit_exceeded = false;

    //Starting LED Game 
    while(1) {
        int button_is_pressed = readFromFileToScreen(USER);
        if (button_is_pressed == 1){ 
            if (num_times_pushed == 0){ 
                brightness_control(brightness_led0, "1"); //Lighting up LED 0
                sleepForMs(1000);
                brightness_control(brightness_led3, "1"); //Lighting up LED 3 & starting timer
                start_time = getTimeInMs();
                brightness_control(brightness_led0, "0"); 
                num_times_pushed++;
            } 
            else {
                brightness_control(brightness_led3, "0");
                response_time = getTimeInMs() - start_time;
                    if (response_time < best_time){
                        printf("New Best Time!\n");
                        best_time = response_time;
                    } 
                printf("Your recation time was %lldms; best so far in game is %lldms.\n", response_time, best_time);
                sleepForMs(1000);
                brightness_control(brightness_led3, "1");
                start_time = getTimeInMs();
            }
            
        }        
        else { // Enter here when USER is not pressed 
            start_time_2 = getTimeInMs();
            response_time_2 = 0;
            compare_time = response_time_2 - start_time_2;
            while (compare_time < 5000){
                int button_is_pressed_2 = readFromFileToScreen(USER);
                if (!button_is_pressed_2 && time_limit_exceeded){
                    printf("No input within 5000ms; quitting!\n");
                    //Setting all LED's to on
                    brightness_control(brightness_led0, "1");
                    brightness_control(brightness_led1, "1");
                    brightness_control(brightness_led2, "1");
                    brightness_control(brightness_led3, "1");
                    return 0;
                } else if (button_is_pressed_2){
                    break;
                }
                compare_time = getTimeInMs() - start_time_2;
                if (compare_time >= 5000){
                    time_limit_exceeded = true;
                }
            }     
        }
    }
    return 0;
}