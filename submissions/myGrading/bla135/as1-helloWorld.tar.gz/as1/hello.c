//hello.c program with LED button game//
//Bryce Leung, bla135@sfu.ca
//This program was created to do the following:
//1. Print out a welcome message to the user
//2. Start up an LED button game where:
//  - A LED will light up and the player will press the USER button when seen
//  - Goal: To have the fastest reaction time possible
//  - The game will end once there has been no activity for more than 5 seconds durring the playing phase of the game

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/wait.h>

//Defined locations for onboard LEDs and GPIO button files
#define buttonUSERConfigLocation "/sys/class/gpio/gpio72/direction"
#define buttonUSERValueLocation "/sys/class/gpio/gpio72/value"
#define triggerLocation0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define triggerLocation1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define triggerLocation2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define triggerLocation3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define brightnessLocation0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define brightnessLocation1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define brightnessLocation2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define brightnessLocation3 "/sys/class/leds/beaglebone:green:usr3/brightness"

//Defined current state status activity
#define active 1
#define inActive 0

//Defined button press state 
#define buttonPressed 0
#define buttonNotPressed 1


//Copied function getTimeInMs from hints in assignment 1 document
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}


//Copied function sleepForMs from hints in assignment 1 document
static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_Per_SECOND = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_Per_SECOND;
    int nanoseconds = delayNs % NS_Per_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}


//Copied function runCommand from hints in assignment 1 document
static void runCommand(char *command)
{
    FILE *pipe = popen(command, "r");

    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        {
            break;
        }
    }

    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("unable to execute command:");
        printf("    command:    %s\n", command);
        printf("    exit code:  %d\n", exitCode);
    }
}

//Function that Initializes and configures the USER button as a GPIO input 
static void initialize_USERButton_BBG(void)
{
    runCommand("config-pin p8.43 gpio");

    FILE *buttonUSERConfigFile = fopen(buttonUSERConfigLocation, "w");
        if (buttonUSERConfigFile == NULL){
        printf("ERROR Opening %s", buttonUSERConfigLocation);
        exit(1);
        }
    fprintf(buttonUSERConfigFile,"in");
    fclose(buttonUSERConfigFile);
}

//Function that reads the value for the USER button and returns a value that states whether it has been pressed
static int readValue_USERButton_BBG(void)
{
    int maxStringLength = 2;
    int buttonState;
    char buttonValue[maxStringLength];
    char referenceString[2];
    snprintf(referenceString, 2, "1");
    FILE *buttonUSERValueFile = fopen(buttonUSERValueLocation, "r");
    fgets(buttonValue, maxStringLength ,buttonUSERValueFile);
    fclose(buttonUSERValueFile);

    if(strcmp(buttonValue, referenceString) == 0){
        buttonState = buttonNotPressed;
    }
    else{
        buttonState = buttonPressed;
    }
    return buttonState;
}


//Function that initializes the LED triggers as none
static void initialize_LEDTriggers_BBG(void)
{
    FILE *LEDTriggerFile0 = fopen(triggerLocation0, "w");
    if (LEDTriggerFile0 == NULL){
        printf("ERROR Opening %s", triggerLocation0);
        exit(1);
        }
    fprintf(LEDTriggerFile0,"none");
    fclose(LEDTriggerFile0);

    FILE *LEDTriggerFile1 = fopen(triggerLocation1, "w");
        if (LEDTriggerFile1 == NULL){
        printf("ERROR Opening %s", triggerLocation1);
        exit(1);
        }
    fprintf(LEDTriggerFile1,"none");
    fclose(LEDTriggerFile1);

    FILE *LEDTriggerFile2 = fopen(triggerLocation2, "w");
        if (LEDTriggerFile2 == NULL){
        printf("ERROR Opening %s", triggerLocation2);
        exit(1);
        }
    fprintf(LEDTriggerFile2,"none");
    fclose(LEDTriggerFile2);

    FILE *LEDTriggerFile3 = fopen(triggerLocation3, "w");
        if (LEDTriggerFile3 == NULL){
        printf("ERROR Opening %s", triggerLocation3);
        exit(1);
        }
    fprintf(LEDTriggerFile3,"none");
    fclose(LEDTriggerFile3);
}

//Function that allows for specified LEDs to be switched on and off
static void controlLEDs_BBG(int usr0LED, int usr1LED, int usr2LED, int usr3LED) 
{
    FILE *LEDBrightnessFile0 = fopen(brightnessLocation0, "w");
        if (LEDBrightnessFile0 == NULL){
        printf("ERROR Opening %s", brightnessLocation0);
        exit(1);
        }
    fprintf(LEDBrightnessFile0, "%d", usr0LED);
    fclose(LEDBrightnessFile0);
    
    FILE *LEDBrightnessFile1 = fopen(brightnessLocation1, "w");
        if (LEDBrightnessFile1 == NULL){
        printf("ERROR Opening %s", brightnessLocation1);
        exit(1);
        }
    fprintf(LEDBrightnessFile1, "%d", usr1LED);
    fclose(LEDBrightnessFile1);
    
    FILE *LEDBrightnessFile2 = fopen(brightnessLocation2, "w");
        if (LEDBrightnessFile2 == NULL){
        printf("ERROR Opening %s", brightnessLocation2);
        exit(1);
        }
    fprintf(LEDBrightnessFile2, "%d", usr2LED);
    fclose(LEDBrightnessFile2);
    
    FILE *LEDBrightnessFile3 = fopen(brightnessLocation3,"w");
        if (LEDBrightnessFile3 == NULL){
        printf("ERROR Opening %s", brightnessLocation3);
        exit(1);
        }
    fprintf(LEDBrightnessFile3, "%d", usr3LED);
    fclose(LEDBrightnessFile3);
}


int main() {

    //Initialization of LEDs and buttons
    initialize_USERButton_BBG();
    initialize_LEDTriggers_BBG();

    //Initialization of variables
    int quittingState = inActive;
    int earlyBtnPressState = inActive;
    int maximumTime = 3000;
    int minimumTime = 500;
    long long randomizedTimeDelay;
    long long startTime = 0;
    long long currentTime = 0;
    long long reactionTime = 0;
    long long bestReactionTime = 0;

    
    printf("Hello embedded world, from Bryce Leung \n\n");
    printf("When LED3 lights up, press the USER button! \n");
    
    //LED button game loop
    while(quittingState == inActive) {
        //1. Waits while user holds down the USER button before continuing the game
        while(readValue_USERButton_BBG() == buttonPressed) {
            //Do nothing 
        }

        //2. Light up LED 0 and leave the rest off
        controlLEDs_BBG(1,0,0,0);

        //3. Wait a random time between 0.5 - 3.0 seconds before lighting up LED 3
        randomizedTimeDelay = rand() %(maximumTime-minimumTime + 1) + minimumTime;
        sleepForMs(randomizedTimeDelay);
        
        //4. If the user presses the button too soon, record as 5000 seconds and proceed to 7 by activating the earlyBtnPressState
        earlyBtnPressState = inActive;
        if(readValue_USERButton_BBG() == buttonPressed) {
            reactionTime = 5000;
            earlyBtnPressState = active;
        }

        //5. Light up LED 3 and start timer
        if(earlyBtnPressState == inActive) {
            controlLEDs_BBG(1,0,0,1);
            startTime = getTimeInMs();
        }

        //6. If user presses USER button stop timer or exit if longer than 5 seconds
        while(readValue_USERButton_BBG() == buttonNotPressed && earlyBtnPressState == inActive) {
            currentTime = getTimeInMs();
            reactionTime = (currentTime - startTime); //Keeping track of the current ellapsed amount of time

            if(reactionTime > 5000) { //If the reaction time is greater than 5 seconds the LEDs are turned off and the quittingstate is activated
                printf("No input within 5000ms; quitting!\n\n");
                controlLEDs_BBG(0,0,0,0);
                quittingState = active;
                break;
            }
        }

        //7. Light up all LEDs
        //8. Display summary
        if(quittingState == inActive) {
            controlLEDs_BBG(1,1,1,1);

            if(earlyBtnPressState == active){ //If the button was pressed early it will output a message to user
                printf("Early button press detected!\n");
            }
            else if ((reactionTime < bestReactionTime) || (bestReactionTime == 0)) { //If a new best time has been achieved, a message will be displayed to user
                bestReactionTime = reactionTime;
                printf("New best time!\n");
            }
            printf("Your reaction time was %4lldms; best so far in game is %lldms\n", reactionTime, bestReactionTime);
        }
    }  
    return 0;
}