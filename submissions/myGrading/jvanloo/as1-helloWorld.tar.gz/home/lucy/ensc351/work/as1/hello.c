  #include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

char readFromFileToScreen(char *fileName);
float float_rand(float min, float max);
static void sleepForMs(long long delayInMs);
static long long getTimeInMs(void);
// I tried but couldnt get second input button to work
int main()
{
    /*struct timespec tim,tim2;
    tim.tv_sec = 0;
    tim.tv_nsec= 500;*/
    int test = 1; 
    sleepForMs(500);
    const int MAX_LENGTH = 1024;
    char read[MAX_LENGTH];
    float randomtime;
    float idleresponsetime;
    static long long startingtime;
    static long long responsetime;
    static long long scoretime;
    //static long long randstartingtime;
    //static long long endtime;
    read[0]=1;

     FILE *File2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
        if (File2 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
        }
    //printf("hello");
    // Write to data to the file using fprintf():
    fprintf(File2, "%d", 0);
    // Close the file using fclose():
    fclose(File2);

    sleepForMs(300);

    printf("Hello embedded world, from Jaydon!\n");
    //readFromFileToScreen("/sys/class/gpio/gpio72/value");
    // Use fopen() to open the file for write access.
    FILE *pFile = fopen("/sys/class/gpio/export", "w");
    if (pFile == NULL) {
    printf("ERROR: Unable to open export file.\n");
    exit(1);
    }
    //printf("hello");
    // Write to data to the file using fprintf():
    fprintf(pFile, "%d", 72);
    // Close the file using fclose():
    //fclose(pFile);
    // Call nanosleep() to sleep for ~300ms before use.
    //sleepForMs(300);

    //randomtime = float_rand(0.5,3);
    //printf("%f",randomtime);

    sleepForMs(500);
    while(test == 1)
    {
        /*FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
        char buff[MAX_LENGTH];
        for (int i = 0; i < MAX_LENGTH; ++i) {
            buff[i] = '\0';
        }
        fgets(buff, MAX_LENGTH, pFile);
        printf("got button value: %c\n", buff[0]);
        fclose(pFile);*/
        // set all leds to zero
        pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
        fprintf(pFile, "0");
        fclose(pFile);

        pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
        fprintf(pFile, "0");
        fclose(pFile);

        pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
        fprintf(pFile, "0");
        fclose(pFile);

        pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
        fprintf(pFile, "0");
        fclose(pFile);


        read[0]=readFromFileToScreen("/sys/class/gpio/gpio72/value");
        sleepForMs(300);

        // calculate random timeout
        // if button has already been pressed:
        //      exit
        // turn the light on
        // else, if button has not already been pressed:
        //      wait for the random timeout
        //      if button was not pressed:
        //          exit
        //      else, if button was pressed during timeout:
        //          turn on all the LEDs
        //          calculate how long they took to press the button
        //          print how long it took to press the button

        if(read[0] == '0')
        {
            FILE *pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
            if (pFile == NULL) 
            {   printf("ERROR: Unable to open export file.\n");
                exit(1);
            }
            //printf("hello");
            // Write to data to the file using fprintf():
            fprintf(pFile, "%d", 1);
            // Close the file using fclose():
            fclose(pFile);
            // Call nanosleep() to sleep for ~300ms before use.
            randomtime = float_rand(0.5,3);
            printf("sleeping for %0.3f\n", randomtime);
            //randstartingtime = getTimeInMs();
            //sleepForMs(randomtime*1000);

            //  time_t endwait;
             
            
            //  endwait = randomtime;
       
            //  while(time (NULL)< endwait)
            //  {
            //     if(read[0] == '0');
            //     {
            //         printf("pressed to early\n");
            //         return 1;
            //     }
            //  }
               
            if(read[0] == '0')
                    {    
                           sleepForMs(randomtime*1000);
                            FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
                            if (pFile1 == NULL) 
                            {    printf("ERROR: Unable to open export file.\n");
                                exit(1);
                            }
                            
                            fprintf(pFile1, "%d", 1);
                            // Close the file using fclose():
                            fclose(pFile1);
                            sleepForMs(500);
                            
                            startingtime = getTimeInMs();
                            startingtime = startingtime - 1665096605000;
                            printf("Starting time: %lld\n",startingtime);
                            if(read[0] == '0')
                                {responsetime = getTimeInMs() ;
                                responsetime = responsetime-1665096605000;
                                scoretime = responsetime-startingtime;
                                
                                printf("Response time: %lld ms\n",responsetime);
                                printf("button pressed\n");
                                printf("score time: %lld ms\n",scoretime);
                                pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
                                fprintf(pFile, "%d",1);
                                fclose(pFile);

                                pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
                                fprintf(pFile, "%d",1);
                                fclose(pFile);

                                pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
                                fprintf(pFile, "%d",1);
                                fclose(pFile);

                                pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
                                fprintf(pFile, "%d",1);
                                fclose(pFile);
                                sleepForMs(500);
                                }
                    }
                        else
                        {
                            idleresponsetime = 5; //milliseconds
                            printf("The response time was %f\n",idleresponsetime);
                            return 2;
                        }
              
        }
    }
    fclose(pFile);
    return 0;
}

char readFromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    printf("Read: '%s'\n", buff);
    return buff[0];
}

static long long getTimeInMs(void)
{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

float float_rand(float min, float max)
{
    srand(time(NULL));
    float scale = rand () / (float) RAND_MAX;
    return min + scale * (max-min);
}
     
// /*#include <stdio.h>
// #include <time.h>
// #include <stdlib.h>
// #include <unistd.h>

// char readFromFileToScreen(char *fileName);
// float float_rand(float min, float max);
// static void sleepForMs(long long delayInMs);
// static long long getTimeInMs(void);

// int main()
// {
//     int test = 1; 
//     sleepForMs( 500 );
//     const int MAX_LENGTH = 1024;
//     char read[MAX_LENGTH];
//     char temp[MAX_LENGTH];
//     float randomtime;
//     float idleresponsetime;
//     static long long startingtime;
//     static long long currenttime;
//     static long long responsetime;
//     static long long scoretime;
//     int buttonpressed = 0;
//     enum {
//         START,
//         FIRST_BUTTON_PRESSED,
//         LIGHT_ON,
//         TIME_EXPIRED,
//         SecondButton_PRESSED,
//     };
//     printf("Hello embedded world, from Jaydon!\n");
   
//     int state = START;

//     while (test == 1) {

//         switch(state) {
//             case START:
//                 printf("Start case\n");
   
//                 // turn off the leds
//                 FILE* pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 fprintf(pFile, "0");
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
//                 fprintf(pFile, "0");
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//                 fprintf(pFile, "0");
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
//                 fprintf(pFile, "0");
//                 fclose(pFile);

//                 // wait for button to be pressed
//                 sleepForMs(300);

//                 char button = readFromFileToScreen("/sys/class/gpio/gpio72/value");
//                 printf("asfdasfeasefasdfasdfaef%c, %d\n", button, (char)button == (char)0);

//                 if (button == 0) {
//                     state = FIRST_BUTTON_PRESSED;
//                 }
//                 // Use fopen() to open the file for write access.2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 // if (File2 == NULL) {
//                 //     printf("ERROR: Unable to open export file.\n");
//                 //     exit(1);
//                 // }

//                 // FILE *File2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 // if (File2 == NULL) {
//                 //     printf("ERROR: Unable to open export file.\n");
//                 //     exit(1);
//                 // }
//                 //printf("hello");
//                 // Write to data to the file using fprintf():
//                 // fprintf(File2, "%d", 0);
//                 // Close the file using fclose():
//                 // fclose(File2);

//                 //readFromFileToScreen("/sys/class/gpio/gpio72/value");
//                 // Use fopen() to open the file for write access.2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 // if (File2 == NULL) {
//                 //     printf("ERROR: Unable to open export file.\n");
//                 //     exit(1);
//                 // }
//                 // sleepForMs(300);

//                 break;

//             case FIRST_BUTTON_PRESSED:
//                 // start the first LED
//                 // get your random amount of time
//                 // start the timer
//                 // turn on the second LED

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 if (pFile == NULL) 
//                 {   printf("ERROR: Unable to open export file.\n");
//                     exit(1);
//                 }
//                 fprintf(pFile, "%d", 1);
//                 fclose(pFile);

//                 randomtime = float_rand(0.5,3);
//                 printf("sleeping for %0.3f\n", randomtime);

//                 startingtime = getTimeInMs();

//                 state = LIGHT_ON;

//                 // if(read[0] == '0')
//                 // {
                    
//                 //     FILE *pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 //     if (pFile == NULL) 
//                 //     {   printf("ERROR: Unable to open export file.\n");
//                 //         exit(1);
//                 //     }
//                 //     //printf("hello");
//                 //     // Write to data to the file using fprintf():
//                 //     fprintf(pFile, "%d", 1);
//                 //     // Close the file using fclose():
//                 //     fclose(pFile);
//                 //     // Call nanosleep() to sleep for ~300ms before use.
//                 //     randomtime = float_rand(0.5,3);
//                 //     printf("sleeping for %0.3f\n", randomtime);

//                 //     state = LIGHT_ON;
//                 //     break;
//                 // }

//                 break;

//             case LIGHT_ON:
//                 // if (random amount of time has expired)
//                 //      state = TIME_EXPIRED;
//                 // if (button was pressed)
//                 //      state = BUTTON_PRESSED;

//                 currenttime = getTimeInMs();

//                 if (startingtime + randomtime*1000 < currenttime) {
//                     state = TIME_EXPIRED;
//                     continue;
//                 }

//                  button = readFromFileToScreen("/sys/class/gpio/gpio72/value");

//                 if (button == 0) {
//                     state = SecondButton_PRESSED;
//                 }

//             //     printf("Light on case\n");
//             //     if(read[0] == '0')
//             // {    
//             //         buttonpressed = 1;
//             //         sleepForMs(randomtime*1000);
//             //         FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//             //         if (pFile1 == NULL) 
//             //         {    printf("ERROR: Unable to open export file.\n");
//             //             exit(1);
//             //         }
//             //         printf("led 2 on");
//             //         fprintf(pFile1, "%d", 1);
//             //         // Close the file using fclose():
//             //         fclose(pFile1);
//             //         sleepForMs(500);
//             //         // set flag
//             //         startingtime = getTimeInMs();
//             //         printf("Starting time: %lld\n",startingtime);
//             //         state = BUTTON_PRESSED;
//             // } 
//             /*else if(read[0] == '1')         
//             {
//                 buttonpressed = 0;
//                 printf("button not pressed\n");

//             }
        
//                 break;
//             case TIME_EXPIRED:
//                 // turn on all LEDs
//                 // return 0;
//                 printf("time expired case\n");
//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);
//                 printf("too long exiting!");
//                 sleepForMs(500);
//                 return 1;
//                 break;
//             case SecondButton_PRESSED:
//                 // store the time
//                 // state = START;
                
//                 printf("Button pressed\n");
//                 //if(temp[0] == '0')
//                     button = readFromFileToScreen("/sys/class/gpio/gpio72/value");
//                      if (button == 0) 
//                      {

//                         responsetime = getTimeInMs();
//                         scoretime =   responsetime - startingtime;
//                         printf("Response time: %lld ms\n",responsetime);
//                         printf("button pressed\n");
//                         printf("score time: %lld ms\n",scoretime);
                    
//                      }
//                 state = START;
//                 break;


//             /*struct timespec tim,tim2;
//             tim.tv_sec = 0;
//             tim.tv_nsec= 500;*/
        
//             //static long long randstartingtime;
//             //static long long endtime;
    

//             // calculate random timeout
//             // if button has already been pressed:
//             //      exit
//             // turn the light on
//             // else, if button has not already been pressed:
//             //      wait for the random timeout
//             //      if button was not pressed:
//             //          exit
//             //      else, if button was pressed during timeout:
//             //          turn on all the LEDs
//             //          calculate how long they took to press the button
//             //          print how long it took to press the button

//             //randstartingtime = getTimeInMs();
//             //sleepForMs(randomtime*1000);

//             //  time_t endwait;
             
            
//             //  endwait = randomtime;
       
//             //  while(time (NULL)< endwait)
//             //  {
//             //     if(read[0] == '0');
//             //     {
//             //         printf("pressed to early\n");
//             //         return 1;
//             //     }
//             //  }
             

//             /*buttonpressed = 0; // clear flag
//             else
//             {
//                 idleresponsetime = 5; //milliseconds
//                 printf("The response time was %f\n",idleresponsetime);
//                 return 2;
//             }
//         }

//         //fclose(pFile);
//     }

// return 0;
// }

// char readFromFileToScreen(char *fileName)
// {
// FILE *pFile = fopen(fileName, "r");
// if (pFile == NULL) {
// printf("ERROR: Unable to open file (%s) for read\n", fileName);
// exit(-1);
// }
// // Read string (line)
// const int MAX_LENGTH = 1024;
// char buff[MAX_LENGTH];
// fgets(buff, MAX_LENGTH, pFile);
// // Close
// fclose(pFile);
// printf("Read: '%s'\n", buff);
// return buff[0];
// }

// static long long getTimeInMs(void)
// {
// struct timespec spec;
// clock_gettime(CLOCK_REALTIME, &spec);
// long long seconds = spec.tv_sec;
// long long nanoSeconds = spec.tv_nsec;
// long long milliSeconds = seconds * 1000
// + nanoSeconds / 1000000;
// return milliSeconds;
// }

// static void sleepForMs(long long delayInMs)
// {
// const long long NS_PER_MS = 1000 * 1000;
// const long long NS_PER_SECOND = 1000000000;
// long long delayNs = delayInMs * NS_PER_MS;
// int seconds = delayNs / NS_PER_SECOND;
// int nanoseconds = delayNs % NS_PER_SECOND;
// struct timespec reqDelay = {seconds, nanoseconds};
// nanosleep(&reqDelay, (struct timespec *) NULL);
// }

// float float_rand(float min, float max)
// {
// srand(time(NULL));
// float scale = rand () / (float) RAND_MAX;
// return min + scale * (max-min);
// }

// static void runCommand(char* command)
// {
// // Execute the shell command (output into pipe)
// FILE *pipe = popen(command, "r");
// // Ignore output of the command; but consume it
// // so we don't get an error when closing the pipe.
// char buffer[1024];
// while (!feof(pipe) && !ferror(pipe)) {
// if (fgets(buffer, sizeof(buffer), pipe) == NULL)
// break;
// // printf("--> %s", buffer); // Uncomment for debugging
// }
// }
// // Get the exit code from the pipe; non-zero is an error:
// /*int exitCode = WEXITSTATUS(pclose(pipe));
// if (exitCode != 0) {
// perror("Unable to execute command:");
// printf(" command: %s\n", command);
// printf(" exit code: %d\n", exitCode);
// }
// */

// // #include <stdio.h>
// // #include <time.h>
// // #include <stdlib.h>
// // #include <unistd.h>

// // char readFromFileToScreen(char *fileName);
// // float float_rand(float min, float max);
// // static void sleepForMs(long long delayInMs);
// // static long long getTimeInMs(void);

// // int main()
// // {
// //     int test = 1; 
// //     sleepForMs( 500 );
// //     const int MAX_LENGTH = 1024;
// //     char read[MAX_LENGTH];
// //     char temp[MAX_LENGTH];
// //     float randomtime;
// //     float idleresponsetime;
// //     static long long startingtime;
// //     static long long currenttime;
// //     static long long responsetime;
// //     static long long scoretime;
// //     int buttonpressed = 0;
// //     enum {
// //         START,
// //         FIRST_BUTTON_PRESSED,
// //         LIGHT_ON,
// //         TIME_EXPIRED,
// //         SecondButton_PRESSED,
// //     };
// //     printf("Hello embedded world, from Jaydon!\n");
   
// //     int state = START;

// //     while (test == 1) {

// //         switch(state) {
// //             case START:
// //                 printf("Start case\n");
   
// //                 // turn off the leds
// //                 FILE* pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 // wait for button to be pressed
// //                 sleepForMs(300);

// //                 char button = readFromFileToScreen("/sys/class/gpio/gpio72/value");
// //                 printf("asfdasfeasefasdfasdfaef%c, %d\n", button, (char)button == (char)0);

// //                 if (button == 0) {
// //                     state = FIRST_BUTTON_PRESSED;
// //                 }
// //                 // Use fopen() to open the file for write access.2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 // if (File2 == NULL) {
// //                 //     printf("ERROR: Unable to open export file.\n");
// //                 //     exit(1);
// //                 // }

// //                 // FILE *File2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 // if (File2 == NULL) {
// //                 //     printf("ERROR: Unable to open export file.\n");
// //                 //     exit(1);
// //                 // }
// //                 //printf("hello");
// //                 // Write to data to the file using fprintf():
// //                 // fprintf(File2, "%d", 0);
// //                 // Close the file using fclose():
// //                 // fclose(File2);

// //                 //readFromFileToScreen("/sys/class/gpio/gpio72/value");
// //                 // Use fopen() to open the file for write access.2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 // if (File2 == NULL) {
// //                 //     printf("ERROR: Unable to open export file.\n");
// //                 //     exit(1);
// //                 // }
// //                 // sleepForMs(300);

// //                 break;

// //             case FIRST_BUTTON_PRESSED:
// //                 // start the first LED
// //                 // get your random amount of time
// //                 // start the timer
// //                 // turn on the second LED

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 if (pFile == NULL) 
// //                 {   printf("ERROR: Unable to open export file.\n");
// //                     exit(1);
// //                 }
// //                 fprintf(pFile, "%d", 1);
// //                 fclose(pFile);

// //                 randomtime = float_rand(0.5,3);
// //                 printf("sleeping for %0.3f\n", randomtime);

// //                 startingtime = getTimeInMs();

// //                 state = LIGHT_ON;

// //                 // if(read[0] == '0')
// //                 // {
                    
// //                 //     FILE *pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 //     if (pFile == NULL) 
// //                 //     {   printf("ERROR: Unable to open export file.\n");
// //                 //         exit(1);
// //                 //     }
// //                 //     //printf("hello");
// //                 //     // Write to data to the file using fprintf():
// //                 //     fprintf(pFile, "%d", 1);
// //                 //     // Close the file using fclose():
// //                 //     fclose(pFile);
// //                 //     // Call nanosleep() to sleep for ~300ms before use.
// //                 //     randomtime = float_rand(0.5,3);
// //                 //     printf("sleeping for %0.3f\n", randomtime);

// //                 //     state = LIGHT_ON;
// //                 //     break;
// //                 // }

// //                 break;

// //             case LIGHT_ON:
// //                 // if (random amount of time has expired)
// //                 //      state = TIME_EXPIRED;
// //                 // if (button was pressed)
// //                 //      state = BUTTON_PRESSED;

// //                 currenttime = getTimeInMs();

// //                 if (startingtime + randomtime*1000 < currenttime) {
// //                     state = TIME_EXPIRED;
// //                     continue;
// //                 }

// //                  button = readFromFileToScreen("/sys/class/gpio/gpio72/value");

// //                 if (button == 0) {
// //                     state = SecondButton_PRESSED;
// //                 }

// //             //     printf("Light on case\n");
// //             //     if(read[0] == '0')
// //             // {    
// //             //         buttonpressed = 1;
// //             //         sleepForMs(randomtime*1000);
// //             //         FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// //             //         if (pFile1 == NULL) 
// //             //         {    printf("ERROR: Unable to open export file.\n");
// //             //             exit(1);
// //             //         }
// //             //         printf("led 2 on");
// //             //         fprintf(pFile1, "%d", 1);
// //             //         // Close the file using fclose():
// //             //         fclose(pFile1);
// //             //         sleepForMs(500);
// //             //         // set flag
// //             //         startingtime = getTimeInMs();
// //             //         printf("Starting time: %lld\n",startingtime);
// //             //         state = BUTTON_PRESSED;
// //             // } 
// //             /*else if(read[0] == '1')         
// //             {
// //                 buttonpressed = 0;
// //                 printf("button not pressed\n");

// //             }*/
        
// //                 break;
// //             case TIME_EXPIRED:
// //                 // turn on all LEDs
// //                 // return 0;
// //                 printf("time expired case\n");
// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 fprintf(pFile, "%d",1);
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
// //                 fprintf(pFile, "%d",1);
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// //                 fprintf(pFile, "%d",1);
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
// //                 fprintf(pFile, "%d",1);
// //                 fclose(pFile);
// //                 printf("too long exiting!");
// //                 sleepForMs(500);
// //                 return 1;
// //                 break;
// //             case SecondButton_PRESSED:
// //                 // store the time
// //                 // state = START;
                
// //                 printf("Button pressed\n");
// //                 //if(temp[0] == '0')
// //                     button = readFromFileToScreen("/sys/class/gpio/gpio72/value");
// //                      if (button == 0) 
// //                      {

// //                         responsetime = getTimeInMs();
// //                         scoretime =   responsetime - startingtime;
// //                         printf("Response time: %lld ms\n",responsetime);
// //                         printf("button pressed\n");
// //                         printf("score time: %lld ms\n",scoretime);
                    
// //                      }
// //                 state = START;
// //                 break;


// //             /*struct timespec tim,tim2;
// //             tim.tv_sec = 0;
// //             tim.tv_nsec= 500;*/
        
// //             //static long long randstartingtime;
// //             //static long long endtime;
    

// //             // calculate random timeout
// //             // if button has already been pressed:
// //             //      exit
// //             // turn the light on
// //             // else, if button has not already been pressed:
// //             //      wait for the random timeout
// //             //      if button was not pressed:
// //             //          exit
// //             //      else, if button was pressed during timeout:
// //             //          turn on all the LEDs
// //             //          calculate how long they took to press the button
// //             //          print how long it took to press the button

// //             //randstartingtime = getTimeInMs();
// //             //sleepForMs(randomtime*1000);

// //             //  time_t endwait;
             
            
// //             //  endwait = randomtime;
       
// //             //  while(time (NULL)< endwait)
// //             //  {
// //             //     if(read[0] == '0');
// //             //     {
// //             //         printf("pressed to early\n");
// //             //         return 1;
// //             //     }
// //             //  }
             

// //             /*buttonpressed = 0; // clear flag
// //             else
// //             {
// //                 idleresponsetime = 5; //milliseconds
// //                 printf("The response time was %f\n",idleresponsetime);
// //                 return 2;
// //             }*/
// //         }

// //         //fclose(pFile);
// //     }

// // return 0;
// // }

// // char readFromFileToScreen(char *fileName)
// // {
// // FILE *pFile = fopen(fileName, "r");
// // if (pFile == NULL) {
// // printf("ERROR: Unable to open file (%s) for read\n", fileName);
// // exit(-1);
// // }
// // // Read string (line)
// // const int MAX_LENGTH = 1024;
// // char buff[MAX_LENGTH];
// // fgets(buff, MAX_LENGTH, pFile);
// // // Close
// // fclose(pFile);
// // printf("Read: '%s'\n", buff);
// // return buff[0];
// // }

// // static long long getTimeInMs(void)
// // {
// // struct timespec spec;
// // clock_gettime(CLOCK_REALTIME, &spec);
// // long long seconds = spec.tv_sec;
// // long long nanoSeconds = spec.tv_nsec;
// // long long milliSeconds = seconds * 1000
// // + nanoSeconds / 1000000;
// // return milliSeconds;
// // }

// // static void sleepForMs(long long delayInMs)
// // {
// // const long long NS_PER_MS = 1000 * 1000;
// // const long long NS_PER_SECOND = 1000000000;
// // long long delayNs = delayInMs * NS_PER_MS;
// // int seconds = delayNs / NS_PER_SECOND;
// // int nanoseconds = delayNs % NS_PER_SECOND;
// // struct timespec reqDelay = {seconds, nanoseconds};
// // nanosleep(&reqDelay, (struct timespec *) NULL);
// // }

// // float float_rand(float min, float max)
// // {
// // srand(time(NULL));
// // float scale = rand () / (float) RAND_MAX;
// // return min + scale * (max-min);
// // }

// // static void runCommand(char* command)
// // {
// // // Execute the shell command (output into pipe)
// // FILE *pipe = popen(command, "r");
// // // Ignore output of the command; but consume it
// // // so we don't get an error when closing the pipe.
// // char buffer[1024];
// // while (!feof(pipe) && !ferror(pipe)) {
// // if (fgets(buffer, sizeof(buffer), pipe) == NULL)
// // break;
// // // printf("--> %s", buffer); // Uncomment for debugging
// // }
// // }
// // // Get the exit code from the pipe; non-zero is an error:
// // /*int exitCode = WEXITSTATUS(pclose(pipe));
// // if (exitCode != 0) {
// // perror("Unable to execute command:");
// // printf(" command: %s\n", command);
// // printf(" exit code: %d\n", exitCode);
// // }*/

// // // #include <stdio.h>
// // // #include <time.h>
// // // #include <stdlib.h>
// // // #include <unistd.h>

// // // char readFromFileToScreen(char *fileName);
// // // float float_rand(float min, float max);
// // // static void sleepForMs(long long delayInMs);
// // // static long long getTimeInMs(void);

// // // int main()
// // // {
// // //     /*struct timespec tim,tim2;
// // //     tim.tv_sec = 0;
// // //     tim.tv_nsec= 500;*/
// // //     int test = 1; 
// // //     sleepForMs(500);
// // //     const int MAX_LENGTH = 1024;
// // //     char read[MAX_LENGTH];
// // //     float randomtime;
// // //     float idleresponsetime;
// // //     static long long startingtime;
// // //     static long long responsetime;
// // //     static long long scoretime;
// // //     //static long long randstartingtime;
// // //     //static long long endtime;
// // //     read[0]=1;

// // //      FILE *File2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// // //         if (File2 == NULL) {
// // //         printf("ERROR: Unable to open export file.\n");
// // //         exit(1);
// // //         }
// // //     //printf("hello");
// // //     // Write to data to the file using fprintf():
// // //     fprintf(File2, "%d", 0);
// // //     // Close the file using fclose():
// // //     fclose(File2);

// // //     sleepForMs(300);

// // //     printf("Hello embedded world, from Jaydon!\n");
// // //     //readFromFileToScreen("/sys/class/gpio/gpio72/value");
// // //     // Use fopen() to open the file for write access.
// // //     FILE *pFile = fopen("/sys/class/gpio/export", "w");
// // //     if (pFile == NULL) {
// // //     printf("ERROR: Unable to open export file.\n");
// // //     exit(1);
// // //     }
// // //     //printf("hello");
// // //     // Write to data to the file using fprintf():
// // //     fprintf(pFile, "%d", 72);
// // //     // Close the file using fclose():
// // //     //fclose(pFile);
// // //     // Call nanosleep() to sleep for ~300ms before use.
// // //     //sleepForMs(300);

// // //     //randomtime = float_rand(0.5,3);
// // //     //printf("%f",randomtime);

// // //     sleepForMs(500);
// // //     while(test == 1)
// // //     {
// // //         /*FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
// // //         char buff[MAX_LENGTH];
// // //         for (int i = 0; i < MAX_LENGTH; ++i) {
// // //             buff[i] = '\0';
// // //         }
// // //         fgets(buff, MAX_LENGTH, pFile);
// // //         printf("got button value: %c\n", buff[0]);
// // //         fclose(pFile);*/
// // //         // set all leds to zero
// // //         pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// // //         fprintf(pFile, "0");
// // //         fclose(pFile);

// // //         pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
// // //         fprintf(pFile, "0");
// // //         fclose(pFile);

// // //         pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// // //         fprintf(pFile, "0");
// // //         fclose(pFile);

// // //         pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
// // //         fprintf(pFile, "0");
// // //         fclose(pFile);


// // //         read[0]=readFromFileToScreen("/sys/class/gpio/gpio72/value");
// // //         sleepForMs(300);

// // //         // calculate random timeout
// // //         // if button has already been pressed:
// // //         //      exit
// // //         // turn the light on
// // //         // else, if button has not already been pressed:
// // //         //      wait for the random timeout
// // //         //      if button was not pressed:
// // //         //          exit
// // //         //      else, if button was pressed during timeout:
// // //         //          turn on all the LEDs
// // //         //          calculate how long they took to press the button
// // //         //          print how long it took to press the button

// // //         if(read[0] == '0')
// // //         {
// // //             FILE *pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// // //             if (pFile == NULL) 
// // //             {   printf("ERROR: Unable to open export file.\n");
// // //                 exit(1);
// // //             }
// // //             //printf("hello");
// // //             // Write to data to the file using fprintf():
// // //             fprintf(pFile, "%d", 1);
// // //             // Close the file using fclose():
// // //             fclose(pFile);
// // //             // Call nanosleep() to sleep for ~300ms before use.
// // //             randomtime = float_rand(0.5,3);
// // //             printf("sleeping for %0.3f\n", randomtime);
// // //             //randstartingtime = getTimeInMs();
// // //             //sleepForMs(randomtime*1000);

// // //              time_t endwait;
             
            
// // //              endwait = randomtime;
       
// // //              while(time (NULL)< endwait)
// // //              {
// // //                 if(read[0] == '0');
// // //                 {
// // //                     printf("pressed to early\n");
// // //                     return 1;
// // //                 }
// // //              }
               
// // //             if(read[0] == '0')
// // //                     {    
// // //                            sleepForMs(randomtime*1000);
// // //                             FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// // //                             if (pFile1 == NULL) 
// // //                             {    printf("ERROR: Unable to open export file.\n");
// // //                                 exit(1);
// // //                             }
                            
// // //                             fprintf(pFile1, "%d", 1);
// // //                             // Close the file using fclose():
// // //                             fclose(pFile1);
// // //                             sleepForMs(500);
                            
// // //                             startingtime = getTimeInMs();
// // //                             startingtime = startingtime - 1665096605000;
// // //                             printf("Starting time: %lld\n",startingtime);
// // //                             if(read[0] == '0')
// // //                                 {responsetime = getTimeInMs() ;
// // //                                 responsetime = responsetime-1665096605000;
// // //                                 scoretime = responsetime-startingtime;
                                
// // //                                 printf("Response time: %lld ms\n",responsetime);
// // //                                 printf("button pressed\n");
// // //                                 printf("score time: %lld ms\n",scoretime);
// // //                                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// // //                                 fprintf(pFile, "%d",1);
// // //                                 fclose(pFile);

// // //                                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
// // //                                 fprintf(pFile, "%d",1);
// // //                                 fclose(pFile);

// // //                                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// // //                                 fprintf(pFile, "%d",1);
// // //                                 fclose(pFile);

// // //                                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
// // //                                 fprintf(pFile, "%d",1);
// // //                                 fclose(pFile);
// // //                                 sleepForMs(500);
// // //                                 }
// // //                     }
// // //                         else
// // //                         {
// // //                             idleresponsetime = 5; //milliseconds
// // //                             printf("The response time was %f\n",idleresponsetime);
// // //                             return 2;
// // //                         }
              
// // //         }
// // //     }
// // //     fclose(pFile);
// // //     return 0;
// // // }

// // // char readFromFileToScreen(char *fileName)
// // // {
// // //     FILE *pFile = fopen(fileName, "r");
// // //     if (pFile == NULL) {
// // //         printf("ERROR: Unable to open file (%s) for read\n", fileName);
// // //         exit(-1);
// // //     }
// // //     // Read string (line)
// // //     const int MAX_LENGTH = 1024;
// // //     char buff[MAX_LENGTH];
// // //     fgets(buff, MAX_LENGTH, pFile);
// // //     // Close
// // //     fclose(pFile);
// // //     printf("Read: '%s'\n", buff);
// // //     return buff[0];
// // // }

// // // static long long getTimeInMs(void)
// // // {
// // // struct timespec spec;
// // // clock_gettime(CLOCK_REALTIME, &spec);
// // // long long seconds = spec.tv_sec;
// // // long long nanoSeconds = spec.tv_nsec;
// // // long long milliSeconds = seconds * 1000
// // // + nanoSeconds / 1000000;
// // // return milliSeconds;
// // // }

// // // static void sleepForMs(long long delayInMs)
// // // {
// // // const long long NS_PER_MS = 1000 * 1000;
// // // const long long NS_PER_SECOND = 1000000000;
// // // long long delayNs = delayInMs * NS_PER_MS;
// // // int seconds = delayNs / NS_PER_SECOND;
// // // int nanoseconds = delayNs % NS_PER_SECOND;
// // // struct timespec reqDelay = {seconds, nanoseconds};
// // // nanosleep(&reqDelay, (struct timespec *) NULL);
// // // }

// // // float float_rand(float min, float max)
// // // {
// // //     srand(time(NULL));
// // //     float scale = rand () / (float) RAND_MAX;
// // //     return min + scale * (max-min);
// // // }
// #include <stdio.h>
// #include <time.h>
// #include <stdlib.h>
// #include <unistd.h>

// char readFromFileToScreen(char *fileName);
// float float_rand(float min, float max);
// static void sleepForMs(long long delayInMs);
// static long long getTimeInMs(void);

// int main()
// {
//     /*struct timespec tim,tim2;
//     tim.tv_sec = 0;
//     tim.tv_nsec= 500;*/
//     int test = 1; 
//     sleepForMs(500);
//     const int MAX_LENGTH = 1024;
//     char read[MAX_LENGTH];
//     float randomtime;
//     float idleresponsetime;
//     static long long startingtime;
//     static long long responsetime;
//     static long long scoretime;
//       static long long currenttime;
//         int button = 0;
//     enum {
//         START,
//         FIRST_BUTTON_PRESSED,
//         BUTTON_PRESSED,
//         LIGHT_ON,
//         TIME_EXPIRED,
//         SecondButton_PRESSED,
//     };
//     //static long long randstartingtime;
//     //static long long endtime;
//     read[0]=1;

//      FILE *File2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//         if (File2 == NULL) {
//         printf("ERROR: Unable to open export file.\n");
//         exit(1);
//         }
//     //printf("hello");
//     // Write to data to the file using fprintf():
//     fprintf(File2, "%d", 0);
//     // Close the file using fclose():
//     fclose(File2);

//     sleepForMs(300);

//     printf("Hello embedded world, from Jaydon!\n");
//     //readFromFileToScreen("/sys/class/gpio/gpio72/value");
//     // Use fopen() to open the file for write access.
//     FILE *pFile = fopen("/sys/class/gpio/export", "w");
//     if (pFile == NULL) {
//     printf("ERROR: Unable to open export file.\n");
//     exit(1);
//     }
//     //printf("hello");
//     // Write to data to the file using fprintf():
//     fprintf(pFile, "%d", 72);
//     // Close the file using fclose():
//     //fclose(pFile);
//     // Call nanosleep() to sleep for ~300ms before use.
//     //sleepForMs(300);

//     //randomtime = float_rand(0.5,3);
//     //printf("%f",randomtime);
//      int state = START;
//     sleepForMs(500);
//     while(test == 1)
//     {
//         switch(state) 
//       {  /*FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
//         char buff[MAX_LENGTH];
//         for (int i = 0; i < MAX_LENGTH; ++i) {
//             buff[i] = '\0';
//         }
//         fgets(buff, MAX_LENGTH, pFile);
//         printf("got button value: %c\n", buff[0]);
//         fclose(pFile);*/

//          case START:
//         printf("Start case\n");
//         //set all leds to zero
//         pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//         fprintf(pFile, "0");
//         fclose(pFile);

//         pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
//         fprintf(pFile, "0");
//         fclose(pFile);

//         pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//         fprintf(pFile, "0");
//         fclose(pFile);

//         pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
//         fprintf(pFile, "0");
//         fclose(pFile);


//          button=readFromFileToScreen("/sys/class/gpio/gpio72/value");
//         sleepForMs(300);
//          if (button == 0) {
//                     state = FIRST_BUTTON_PRESSED;
//                }

//         // calculate random timeout
//         // if button has already been pressed:
//         //      exit
//         // turn the light on
//         // else, if button has not already been pressed:
//         //      wait for the random timeout
//         //      if button was not pressed:
//         //          exit
//         //      else, if button was pressed during timeout:
//         //          turn on all the LEDs
//         //          calculate how long they took to press the button
//         //          print how long it took to press the button
//         case FIRST_BUTTON_PRESSED:
// //                 // start the first LED
// //                 // get your random amount of time
// //                 // start the timer
// //                 // turn on the second LED

      
        
//             pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//             if (pFile == NULL) 
//             {   printf("ERROR: Unable to open export file.\n");
//                 exit(1);
//             }
//             //printf("hello");
//             // Write to data to the file using fprintf():
//             fprintf(pFile, "%d", 1);
//             // Close the file using fclose():
//             fclose(pFile);
//             // Call nanosleep() to sleep for ~300ms before use.
//             randomtime = float_rand(0.5,3);
//             printf("sleeping for %0.3f\n", randomtime);
//             startingtime = getTimeInMs();
//             //randstartingtime = getTimeInMs();
//             //sleepForMs(randomtime*1000);
//             state = LIGHT_ON;
//             //  time_t endwait;
             
            
//             //  endwait = randomtime;
       
//             //  while(time (NULL)< endwait)
//             //  {
//             //     if(read[0] == '0');
//             //     {
//             //         printf("pressed to early\n");
//             //         return 1;
//             //     }
//             //  }
//             case LIGHT_ON:
//              //if (random amount of time has expired)
//                      // state = TIME_EXPIRED;
//                // if (button was pressed)
//                      // state = BUTTON_PRESSED;

//                 currenttime = getTimeInMs();

//                 if (startingtime + randomtime*1000 < currenttime) {
//                     state = TIME_EXPIRED;
//                     continue;
//                 }

                 

//                printf("Light on case\n");
                
               
//                    sleepForMs(randomtime*1000);
//                    FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//                   if (pFile1 == NULL) 
//                     {    printf("ERROR: Unable to open export file.\n");
//                         exit(1);
//                     }
//                      printf("led 2 on");
//                      fprintf(pFile1, "%d", 1);
//                      // Close the file using fclose():
//                     fclose(pFile1);
//                      sleepForMs(500);
//                      // set flag
//                      startingtime = getTimeInMs();
//                     printf("Starting time: %lld\n",startingtime);
//                   state = SecondButton_PRESSED;
             
//             /*else if(read[0] == '1')         
//             {
//                 buttonpressed = 0;
//                 printf("button not pressed\n");

//             }*/
        
//                 break;   

//                  case SecondButton_PRESSED:
//                 // store the time
//                 // state = START;
                
//                 printf("Button pressed\n");
//                 //if(temp[0] == '0')
//                     button = readFromFileToScreen("/sys/class/gpio/gpio72/value");
//                      if (button == 0) 
//                      {

//                         responsetime = getTimeInMs();
//                         scoretime =   responsetime - startingtime;
//                         printf("Response time: %lld ms\n",responsetime);
//                         printf("button pressed\n");
//                         printf("score time: %lld ms\n",scoretime);
                    
//                      }
//                 state = START;
//                 break;
//                             case TIME_EXPIRED:
//                 // turn on all LEDs
//                 // return 0;
//                 printf("time expired case\n");
//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);

//                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
//                 fprintf(pFile, "%d",1);
//                 fclose(pFile);
//                 printf("too long exiting!");
//                 sleepForMs(500);
//                 return 1;
//                 break;
//             // if(read[0] == '0')
//             //         {    
//             //                sleepForMs(randomtime*1000);
//             //                 FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
//             //                 if (pFile1 == NULL) 
//             //                 {    printf("ERROR: Unable to open export file.\n");
//             //                     exit(1);
//             //                 }
                            
//             //                 fprintf(pFile1, "%d", 1);
//             //                 // Close the file using fclose():
//             //                 fclose(pFile1);
//             //                 sleepForMs(500);
                            
//             //                 startingtime = getTimeInMs();
//             //                 startingtime = startingtime - 1665096605000;
//             //                 printf("Starting time: %lld\n",startingtime);
//             //                 if(read[0] == '0')
//             //                     {responsetime = getTimeInMs() ;
//             //                     responsetime = responsetime-1665096605000;
//             //                     scoretime = responsetime-startingtime;
                                
//             //                     printf("Response time: %lld ms\n",responsetime);
//             //                     printf("button pressed\n");
//             //                     printf("score time: %lld ms\n",scoretime);
                             
//             //                     }
//             //         }
//             //             else
//             //             {
//             //                 idleresponsetime = 5; //milliseconds
//             //                 printf("The response time was %f\n",idleresponsetime);
//             //                 return 2;
//             //             }
//       }       
        
//     }
//     fclose(pFile);
//     return 0;
// }

// char readFromFileToScreen(char *fileName)
// {
//     FILE *pFile = fopen(fileName, "r");
//     if (pFile == NULL) {
//         printf("ERROR: Unable to open file (%s) for read\n", fileName);
//         exit(-1);
//     }
//     // Read string (line)
//     const int MAX_LENGTH = 1024;
//     char buff[MAX_LENGTH];
//     fgets(buff, MAX_LENGTH, pFile);
//     // Close
//     fclose(pFile);
//     printf("Read: '%s'\n", buff);
//     return buff[0];
// }

// static long long getTimeInMs(void)
// {
// struct timespec spec;
// clock_gettime(CLOCK_REALTIME, &spec);
// long long seconds = spec.tv_sec;
// long long nanoSeconds = spec.tv_nsec;
// long long milliSeconds = seconds * 1000
// + nanoSeconds / 1000000;
// return milliSeconds;
// }

// static void sleepForMs(long long delayInMs)
// {
// const long long NS_PER_MS = 1000 * 1000;
// const long long NS_PER_SECOND = 1000000000;
// long long delayNs = delayInMs * NS_PER_MS;
// int seconds = delayNs / NS_PER_SECOND;
// int nanoseconds = delayNs % NS_PER_SECOND;
// struct timespec reqDelay = {seconds, nanoseconds};
// nanosleep(&reqDelay, (struct timespec *) NULL);
// }

// float float_rand(float min, float max)
// {
//     srand(time(NULL));
//     float scale = rand () / (float) RAND_MAX;
//     return min + scale * (max-min);
// }

// //            
   
// //                 // turn off the leds
// //                 FILE* pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
// //                 fprintf(pFile, "0");
// //                 fclose(pFile);

// //                 // wait for button to be pressed
// //                 sleepForMs(300);

// //                 char button = readFromFileToScreen("/sys/class/gpio/gpio72/value");
// //                 printf("asfdasfeasefasdfasdfaef%c, %d\n", button, (char)button == (char)0);

// //                 if (button == 0) {
// //                     state = FIRST_BUTTON_PRESSED;
// //                 }
// //                 // Use fopen() to open the file for write access.2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 // if (File2 == NULL) {
// //                 //     printf("ERROR: Unable to open export file.\n");
// //                 //     exit(1);
// //                 // }

// //                 // FILE *File2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 // if (File2 == NULL) {
// //                 //     printf("ERROR: Unable to open export file.\n");
// //                 //     exit(1);
// //                 // }
// //                 //printf("hello");
// //                 // Write to data to the file using fprintf():
// //                 // fprintf(File2, "%d", 0);
// //                 // Close the file using fclose():
// //                 // fclose(File2);

// //                 //readFromFileToScreen("/sys/class/gpio/gpio72/value");
// //                 // Use fopen() to open the file for write access.2 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 // if (File2 == NULL) {
// //                 //     printf("ERROR: Unable to open export file.\n");
// //                 //     exit(1);
// //                 // }
// //                 // sleepForMs(300);

// //                 break;

// //             case FIRST_BUTTON_PRESSED:
// //                 // start the first LED
// //                 // get your random amount of time
// //                 // start the timer
// //                 // turn on the second LED

// //                 pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 if (pFile == NULL) 
// //                 {   printf("ERROR: Unable to open export file.\n");
// //                     exit(1);
// //                 }
// //                 fprintf(pFile, "%d", 1);
// //                 fclose(pFile);

// //                 randomtime = float_rand(0.5,3);
// //                 printf("sleeping for %0.3f\n", randomtime);

// //                 startingtime = getTimeInMs();

// //                 state = LIGHT_ON;

// //                 // if(read[0] == '0')
// //                 // {
                    
// //                 //     FILE *pFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
// //                 //     if (pFile == NULL) 
// //                 //     {   printf("ERROR: Unable to open export file.\n");
// //                 //         exit(1);
// //                 //     }
// //                 //     //printf("hello");
// //                 //     // Write to data to the file using fprintf():
// //                 //     fprintf(pFile, "%d", 1);
// //                 //     // Close the file using fclose():
// //                 //     fclose(pFile);
// //                 //     // Call nanosleep() to sleep for ~300ms before use.
// //                 //     randomtime = float_rand(0.5,3);
// //                 //     printf("sleeping for %0.3f\n", randomtime);

// //                 //     state = LIGHT_ON;
// //                 //     break;
// //                 // }

// //                 break;

// //             case LIGHT_ON:
// //                 // if (random amount of time has expired)
// //                 //      state = TIME_EXPIRED;
// //                 // if (button was pressed)
// //                 //      state = BUTTON_PRESSED;

// //                 currenttime = getTimeInMs();

// //                 if (startingtime + randomtime*1000 < currenttime) {
// //                     state = TIME_EXPIRED;
// //                     continue;
// //                 }

// //                  button = readFromFileToScreen("/sys/class/gpio/gpio72/value");

// //                 if (button == 0) {
// //                     state = SecondButton_PRESSED;
// //                 }

// //             //     printf("Light on case\n");
// //             //     if(read[0] == '0')
// //             // {    
// //             //         buttonpressed = 1;
// //             //         sleepForMs(randomtime*1000);
// //             //         FILE *pFile1 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
// //             //         if (pFile1 == NULL) 
// //             //         {    printf("ERROR: Unable to open export file.\n");
// //             //             exit(1);
// //             //         }
// //             //         printf("led 2 on");
// //             //         fprintf(pFile1, "%d", 1);
// //             //         // Close the file using fclose():
// //             //         fclose(pFile1);
// //             //         sleepForMs(500);
// //             //         // set flag
// //             //         startingtime = getTimeInMs();
// //             //         printf("Starting time: %lld\n",startingtime);
// //             //         state = BUTTON_PRESSED;
// //             // } 
// //             /*else if(read[0] == '1')         
// //             {
// //                 buttonpressed = 0;
// //                 printf("button not pressed\n");

// //             }*/
        
// //                 break;

    
