#ifndef HEADER_FILE
# define HEADER_FILE
void configureLED0on();
void configureLED0off();

void configureLED3on();
void configureLED3off();
void triggerLED3Off();

void allLEDoff();
void allLEDon();

int randomWait();
int setWait();
int tryAgain();

static long long getTimeInMs();

int readButtonValue();

int reactionTime();
void gameflow();

#endif