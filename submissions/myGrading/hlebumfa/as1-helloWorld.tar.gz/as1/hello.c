#include <stdio.h>
#include "stdlib.h"
#include "hello.h"
#include <time.h>

#define BUTTON_PATH "/sys/class/gpio/gpio72/value"

#define LED0_PATH "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_PATH "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_PATH "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_PATH "/sys/class/leds/beaglebone:green:usr3/brightness"

#define LED3_PATH_TRIGGER "/sys/class/leds/beaglebone:green:usr3/trigger"
int main(int argc, char* args[])
{
printf("Hello embedded world, from Hazelle!\n");


printf("GAME START: When LED3 lights up, press the USER button! \n");
gameflow();
return 0;
}


void triggerLED3Off(){
    FILE *pLedTriggerFile = fopen(LED3_PATH_TRIGGER, "w");
    if (pLedTriggerFile == NULL) {
    printf("ERROR OPENING %s.", LED3_PATH_TRIGGER);
    exit(1);
    }   
    int charWritten = fprintf(pLedTriggerFile, "none");
    if (charWritten <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }
    fclose(pLedTriggerFile);
}

void configureLED0on(){
FILE *pLED0Brightness = fopen(LED0_PATH, "w");

if(pLED0Brightness == NULL){
    printf("ERROR OPENING %s.", LED0_PATH); 
    exit(1);
}

int charBrightness = fprintf(pLED0Brightness, "1");

if (charBrightness <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}

fclose(pLED0Brightness);
}


void configureLED0off(){
FILE *pLED0Brightness = fopen(LED0_PATH, "w");

if(pLED0Brightness == NULL){
    printf("ERROR OPENING %s.", LED0_PATH); 
    exit(1);
}

int charBrightness = fprintf(pLED0Brightness, "0");

if (charBrightness <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}

fclose(pLED0Brightness);
}


void configureLED3on(){
FILE *pLED3Brightness = fopen(LED3_PATH, "w");

if(pLED3Brightness == NULL){
    printf("ERROR OPENING %s.", LED3_PATH); 
    exit(1);
}

int charBrightness = fprintf(pLED3Brightness, "1");

    if (charBrightness <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }
fclose(pLED3Brightness);

}

void configureLED3off(){
FILE *pLED3Brightness = fopen(LED3_PATH, "w");

if(pLED3Brightness == NULL){
    printf("ERROR OPENING %s.", LED3_PATH); 
    exit(1);
}

int charBrightness = fprintf(pLED3Brightness, "0");

if (charBrightness <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}

fclose(pLED3Brightness);
}


int randomWait(){
    int maxTimeSec = 3000;
    int currTime = 1;
    
    float randTime;
    randTime= ((float)rand()/RAND_MAX)*(float)(maxTimeSec);

    if (randTime < 1500){
        randTime = 1500;
    }
    
    long long startTime = getTimeInMs();

    while(currTime < randTime){
        int checkTime = getTimeInMs();
        if(readButtonValue() == 0)
        {
            return 1;
        }
        currTime = checkTime - startTime;
    }
    
    configureLED3on();
    configureLED0off();
    return 0;
}


int setWait(){
    long long startTime;
    long long currTime;
    long long reactionTime = 1;
    startTime = getTimeInMs();

    while(reactionTime < 5000){
    int buttonVal = readButtonValue();
    currTime = getTimeInMs();
    if(buttonVal == 0) {//active low -> button is pressed
        return 1;
    } 

    reactionTime = currTime - startTime;

    }
    printf("Timeout. Thank you for playing!\n");
    return 0;

}

int tryAgain(){
    long long startTime;
    long long currTime;
    long long reactionTime = 1;
    startTime = getTimeInMs();
    
    while(reactionTime < 5000){
    int buttonVal = readButtonValue();
    currTime = getTimeInMs();
    if(buttonVal == 0) {//active low -> button is pressed
        return 1;
    } 

    reactionTime = currTime - startTime;

    }
    printf("REACTION TIME: 5000 ms. try again? (wait for LED0 again) \n");
    return 0;

}


void allLEDoff(){

    configureLED0off();
    triggerLED3Off();
    FILE *pLED1Brightness = fopen(LED1_PATH, "w");
    FILE *pLED2Brightness = fopen(LED2_PATH, "w");


    if(pLED1Brightness == NULL){
    printf("ERROR OPENING %s.", LED1_PATH); 
    exit(1);
    }   

    if(pLED2Brightness == NULL){
    printf("ERROR OPENING %s.", LED2_PATH); 
    exit(1);
    }   

    int charBrightness1 = fprintf(pLED1Brightness, "0");
    int charBrightness2 = fprintf(pLED2Brightness, "0");

    if (charBrightness1 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }   

    if (charBrightness2 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }   

    fclose(pLED1Brightness);
    fclose(pLED2Brightness);

}

void allLEDon(){

    configureLED0on();
    configureLED3on();
    FILE *pLED1Brightness = fopen(LED1_PATH, "w");
    FILE *pLED2Brightness = fopen(LED2_PATH, "w");


    if(pLED1Brightness == NULL){
    printf("ERROR OPENING %s.", LED1_PATH); 
    exit(1);
    }   

    if(pLED2Brightness == NULL){
    printf("ERROR OPENING %s.", LED2_PATH); 
    exit(1);
    }   

    int charBrightness1 = fprintf(pLED1Brightness, "1");
    int charBrightness2 = fprintf(pLED2Brightness, "1");

    if (charBrightness1 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }   

    if (charBrightness2 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }   

    fclose(pLED1Brightness);
    fclose(pLED2Brightness);

}

static long long getTimeInMs(){
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
 return milliSeconds;
}

//button is active low
//return value
int readButtonValue(){

    FILE *pButtonValue= fopen(BUTTON_PATH, "r");

if(pButtonValue== NULL){
    printf("ERROR OPENING %s.", BUTTON_PATH); 
    exit(1);
}

const int MAX_LENGTH  = 1024;
char val[MAX_LENGTH];
fgets(val, MAX_LENGTH, pButtonValue);


fclose(pButtonValue);

if(val[0] == 48){
    return 0;
}
return 1;
}

int reactionTime(){
    long long startTime;
    long long currTime;
    long long endTime;
    long long reactionTime = 1;
    startTime = getTimeInMs();
    

    while(reactionTime < 5000){
    int buttonVal = readButtonValue();
    currTime = getTimeInMs();

    if(buttonVal == 0) {//active low -> button is pressed
        endTime = getTimeInMs();
        reactionTime = endTime - startTime;
        printf("REACTION TIME: %llu ms ", reactionTime);
        return reactionTime;
    } 

    reactionTime = currTime - startTime;

    }
    printf("too slow :,( \ntry again? (press USER button)\n");
    return 5000;
}

void gameflow(){
int flag = 1;
int bestTime = 5000;

while(flag == 1){
int recentTime;
allLEDoff();
configureLED3off();
configureLED0on();
int early = randomWait();

if(early == 1){
    recentTime = 5000;
    allLEDon();
    tryAgain();
}else{

recentTime = reactionTime();

if(recentTime<bestTime){
    bestTime = recentTime;
}
printf("BEST TIME: %d ms \n", bestTime);
flag = setWait();
}

}

}

