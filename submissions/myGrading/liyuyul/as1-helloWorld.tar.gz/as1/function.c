#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "function.h"

//this is the .c file for all the functions

#define LED_BRIGHTNESS "/brightness"
#define ECHO           "echo "
#define LED_PATH       " > /sys/class/leds/beaglebone:green:usr"

int getBestTime(int inputTime, int smallestTime){
    if (smallestTime == 0){
        smallestTime = smallestTime + inputTime;
            return smallestTime;
        }else{
            if (smallestTime > inputTime){
                smallestTime = inputTime;
                printf("New best time!\n");
            }
        }
        return smallestTime;  
}

// took this function from Dr. Brian Fraser's notes
int readFromFileToScreen(char *fileName){
    FILE *pFIle = fopen(fileName, "r");
    if (pFIle == NULL){
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    const int MAX_LENGHT = 1024;
    char buff[MAX_LENGHT];
    char *result = fgets(buff, MAX_LENGHT, pFIle);
    int isSame = strcmp(result,"1");
    //printf("%d \n", isSame);
    fclose(pFIle);
    //printf("Read: %s \n", buff);
    return isSame;
}

//run the command that pass to the function,
// took this function from Dr. Brian Fraser's notes
static void runCommand (char* command){
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {

        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
    // printf("--> %s", buffer); // Uncomment for debugging
        }
    // Get the exit code from the pipe; non-zero is an error:
        int exitCode = WEXITSTATUS(pclose(pipe));

        if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
        }
}

//for the sake of configuring pin
void pinConfig (void){
    runCommand("config-pin p8.43 gpio");
}

//turn off all the LEDs
void initLedsBeginning(void){
    LedOperation("0", "0");
    LedOperation("1", "0");
    LedOperation("2", "0");
    LedOperation("3", "0");
}

//turn on all the LEDs
void quitting (void){
    LedOperation("0", "1");
    LedOperation("1", "1");
    LedOperation("2", "1");
    LedOperation("3", "1");
    printf("qutting the program!\n");
}

//function for a single LED operation
void LedOperation (char whichLED[1], char input[1]){
    char command[100];
    strcpy (command, ECHO);
    strcat(command, input);
    strcat(command, LED_PATH);
    strcat(command, whichLED);
    strcat(command, LED_BRIGHTNESS);
    runCommand(command);
}




