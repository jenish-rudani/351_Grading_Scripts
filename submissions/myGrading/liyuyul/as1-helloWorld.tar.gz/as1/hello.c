#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "function.h"
#include <stdbool.h>

static void sleepForMs(long long delayInMs){
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void){
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000+ nanoSeconds / 1000000;
    return milliSeconds;
}


int main(int argc, char* args[]){
    //welcoming message
    printf("Hello embedded world!, from Joanna (yuyu)!\n");
    sleepForMs(500);

    //start the loop
        pinConfig();
        initLedsBeginning();
        //init for the timer
        long long start = getTimeInMs();
        long long end = 0;
        long long idleTime = end - start;
        long long time1 = 0;
        long long time0 = 0;
        long long waitTime = 0;
        long long timeDiff;
        int bestTime;
        int smallestTime = 0;
        bool readyForGame = false;
        bool cheater = false;

        printf("When LED0 lights up, press the USER button\n");

        while(readyForGame == false){

            while (waitTime <= 2000){
                int pressedTooEarly = readFromFileToScreen("/sys/class/gpio/gpio72/value");
                end = getTimeInMs();
                waitTime = end - start;
                sleepForMs(50);
                    if (pressedTooEarly < 1){
                        cheater = true;
                        break;
                    }
            }
                
                if (cheater == true){
                    readyForGame = false;
                    printf("cheater!\n");
                    printf("You pressed too early, please make sure you press after the LED0 lights up\n");
                    bestTime = 5000;
                    timeDiff = 5000;
                    break;
                }
            readyForGame = true;
        }

        if (readyForGame == true){
            LedOperation("0","1");
            time0 = getTimeInMs(); 
        }
        
        //loop for time within 5s 
        while (idleTime <= 5000 && readyForGame == true){
            int result = readFromFileToScreen("/sys/class/gpio/gpio72/value");
        
            end = getTimeInMs();
            idleTime = end - start;
        
                if (result < 1){
                    LedOperation("3", "1");
                    time1 = getTimeInMs();
                    timeDiff = time1-time0;
                    bestTime = getBestTime(timeDiff, smallestTime);
                    smallestTime = bestTime;

                        printf("Your reaction time: %lld\n", timeDiff);
                        printf ("The best time so far: %d\n", bestTime);

                    time0 = time0 + timeDiff;
                    start = start + idleTime;
                    sleepForMs(10);
                }
            LedOperation("3","0");
            sleepForMs(20);
        }

        //ending the round
        sleepForMs(50);
        quitting();
        printf("Summary of this around:\n");
        printf("Your current reaction time is %lld ms\n", timeDiff);
        printf("Your best time is: %d ms\n\n", bestTime);
        sleepForMs(500);
    return 0;
}