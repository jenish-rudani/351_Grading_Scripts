#ifndef FUNCTION_H
#define FUNCTION_H
//sleepForMs function refernecing Dr. Brian Fraser's assignment 1 note
//runcommand function refernecing Dr. Brian Fraser's assignment 1 note

//get the best time out of the round 
int getBestTime(int inputTime, int smallestTime);
//referencing Dr. Brian Fraser's notes, with minor changes
//read file context and print it to screen
int readFromFileToScreen(char *fileName);
//config-pin p8.43 gpio
void pinConfig (void);
//init for LEDs
void initLedsBeginning (void);
//high level control for the LEDs
void LedOperation (char whichLED[1], char input[1]);
//turn on all the LEDs for quitting
void quitting (void);


#endif