#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#define ButtonPath "/sys/class/gpio/gpio72/value"
#define LED0Trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1Trigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2Trigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3Trigger "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED0brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3brightness "/sys/class/leds/beaglebone:green:usr3/brightness"



void turnOFFLED0()
{
    FILE *Bright = fopen(LED0brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "00");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED0Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}

void turnOFFLED1()
{
    FILE *Bright = fopen(LED1brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "00");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED1Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}

void turnOFFLED2()
{
    FILE *Bright = fopen(LED2brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "00");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED2Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}

void turnOFFLED3()
{
    FILE *Bright = fopen(LED3brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "00");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED3Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}


static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}

static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
    }
    // printf("--> %s", buffer); // Uncomment for debugging
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

bool buttonIsPressed()
{
    FILE *readUserButton = fopen(ButtonPath, "r");
    if (readUserButton == NULL)
    {
        printf("Read Button : error unable to open file for read \n");
        printf("Error %d \n", errno);
        exit(-1);
    }

    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, readUserButton);
    int iValue = atoi(buff);

    fclose(readUserButton);
    if (iValue == 0)
    {
        return true;
    }
    return false;
}

void turnLED0On()
{
    FILE *Bright = fopen(LED0brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "1");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED0Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}

void turnLED1On()
{   
    FILE *Bright = fopen(LED1brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "1");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED1Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}
void turnLED2On()
{
    FILE *Bright = fopen(LED2brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "1");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED2Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}

void turnLED3On()
{
    FILE *Bright = fopen(LED3brightness, "w");
    if (Bright == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int charWritten = fprintf(Bright, "1");
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(Bright);

    FILE *t = fopen(LED3Trigger, "w");
    if (t == NULL)
    {
        printf("ERROR OPENING.");
        exit(1);
    }
    int x = fprintf(t, "none");
    if (x <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(t);
}

void turnAllLedsOn()
{
     turnLED0On();
     turnLED1On();
     turnLED2On();
     turnLED3On();
}

void turnAllLedsOff()
{
    turnOFFLED1();
    turnOFFLED0();
    turnOFFLED2();
    turnOFFLED3();
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

int main()
{
    printf("Hello Embedded World! from Honeypal \n\n");
    printf("When LED3 lights up please press the USER Button\n");
    printf("New Best time!\n");
    runCommand("config-pin p8.43 gpio");
    runCommand("echo 72 > export");
    long long responseTime = 5000;
    long long bestResponseTime = 5000;
    while (true)
    {
        turnAllLedsOff();
        sleepForMs(1000);
        turnLED0On();
        long long randomWaitingTime = (rand() % (3000 - 500) + 500);
        long long triggerTime = 0;
        long long startTime = getTimeInMs();
        bool Flag = true;
        do
        {

            if (buttonIsPressed())
            {
                // printf("bttonpressed 1\n");
                // printf("Response Time %lld\n", startTime);
                sleepForMs(500);
                Flag = false;
                break;
            }
            long long currentTime = getTimeInMs();
            triggerTime = currentTime - startTime;
            // printf("%lld\n",triggerTime);
        } while (triggerTime < randomWaitingTime);

        if (Flag)
        {
            // printf("second if \n");
            turnLED3On();
            long long startUserTimer = getTimeInMs();
            long long stopUserTimer;
            do
            {
                if (buttonIsPressed())
                {
                    // printf("bttonpressed 2\n");
                    // printf("StartTime: (%lld)\n",startUserTimer);
                    stopUserTimer = getTimeInMs() - startUserTimer;
                    responseTime = stopUserTimer;
                    sleepForMs(500);
                    break;
                }
                else
                {
                    stopUserTimer = getTimeInMs() - startUserTimer;
                }
            } while (stopUserTimer <= 5000);

            // printf("%lld\n", stopUserTimer);

            // printf("afer no button press\n");
            if (stopUserTimer > 5000)
            {
                turnAllLedsOn();
                printf("No input within 5 seconds; quitting\n");
                sleepForMs(1000);
                turnAllLedsOff();
                
                exit(-1);
            }
        }

        turnAllLedsOn();
        if (responseTime < bestResponseTime)
        {
            bestResponseTime = responseTime;
            printf("New Best time!\n");
        }
        if (Flag == false)
        {
            printf("Your reaction time was 5000;");
            printf("Best so far in game is (%lld) \n", bestResponseTime);
        }
        else
        {
            printf("Your reaction time was (%lld);", responseTime);
            printf("Best so far in game is (%lld) \n", bestResponseTime);
        }
        sleepForMs(1000);

    }
    return 0;
}
