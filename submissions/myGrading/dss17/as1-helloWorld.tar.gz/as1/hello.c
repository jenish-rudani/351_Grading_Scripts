#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <time.h>


//protos
static long long getTimeInMs(void); //get time
static void sleepForMs(long long delayInMs); //wait a # of ms
static void runCommand(char* command); //run a linuz command
int readFromFileToScreen(char *fileName);
int userPressedOrNo(void);
void writeToAFile(char *filename, char *command);
void Led0Trig(void);
void Led0on(void);
void Led0off(void);
void Led1Trig(void);
void Led1on(void);
void Led1off(void);
void Led2Trig(void);
void Led2on(void);
void Led2off(void);
void Led3Trig(void);
void Led3on(void);
void Led3off(void);

int main(int argc, char* args[])
{
Led0Trig();
Led1Trig();
Led2Trig();
Led3Trig();
runCommand("config-pin p8.43 gpio");
writeToAFile("/sys/class/gpio/gpio72/direction", "in"); //makes User an input

Led0off();
Led1off();
Led2off();
Led3off();

long long best;
long long start;
long long end;
long long reactionTime;
long long delayCompare = 0;

printf("Hello embedded world, from Devon Sandhu!\n");
printf("When LED3 lights up, press the USER button.\n");

    while(1)
    {

        Led0on();
        srand(time(0));
        long long delay = (rand() % (3000 - 500 + 1)) + 500;   //got this from https://www.geeksforgeeks.org/generating-random-number-range-c/
        while(delayCompare < delay)
        {
            sleepForMs(100);
            if(userPressedOrNo() == 0)
            {
                printf("Too soon!\n");
                Led1on();
                Led2on();
                Led3on();
                break;
            }
            else
            {
                delayCompare = delayCompare + 100;
            }
        }
        sleepForMs(delay);
        Led3on();

        start = getTimeInMs();
        //checks if user pressed early, if so skips to end and loops again
        if(readFromFileToScreen("/sys/class/leds/beaglebone:green:usr2/brightness") == 0)
        {
            if(readFromFileToScreen("/sys/class/leds/beaglebone:green:usr3/brightness") == 1)
            {
                while(userPressedOrNo() == 1)   //checking for longer than 5 seconds
                {
                    if((abs(getTimeInMs() - start))> 5000)
                    {
                        printf("Took too long (5 seconds), quitting!\n");
                        Led0off();
                        Led1off();
                        Led2off();
                        Led3off();
                        exit(0);

                    }
                }
                if(userPressedOrNo() == 0)  //pressed
                {
                        end = getTimeInMs();
                        reactionTime = abs(end - start);
                        if(reactionTime<best)
                        {
                            best = reactionTime;
                        }
                        else
                        {
                            best = best;
                        }
                }
                printf("Your reaction time was %lld ms\n", reactionTime);
                printf("Best time so far is %lld ms\n", best);
                Led1on();
                Led2on();

                sleepForMs(2000);
            }
        }
        Led0off();
        Led1off();
        Led2off();
        Led3off();
        delayCompare =0;
        sleepForMs(2000);
        
    }

return 0;
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
    // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

int readFromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    int YorN;
    YorN = strtol(buff, NULL,10);
    return YorN; //0 = pushed
}

int userPressedOrNo(void)
{
    FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", "/sys/class/gpio/gpio72/value");
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    //int YorN = printf("Read: '%s'\n", buff);
    //int YorN = printf("%s\n", buff);
    int YorN;
    YorN = strtol(buff, NULL, 10);
    return YorN; //0 = pushed
}

void writeToAFile(char *filename, char *command)
{
    // Use fopen() to open the file for write access.
    FILE *pFile = fopen(filename, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    fprintf(pFile, command);
    // Close the file using fclose():
    fclose(pFile);
}

void Led0Trig(void)
{
    #define Trig "/sys/class/leds/beaglebone:green:usr0/trigger"
    FILE *pFile = fopen(Trig, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    int charWritten = fprintf(pFile, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    // Close the file using fclose():
    fclose(pFile);
}

void Led1Trig(void)
{
    #define Trig1 "/sys/class/leds/beaglebone:green:usr1/trigger"
    FILE *pFile = fopen(Trig, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    int charWritten = fprintf(pFile, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    // Close the file using fclose():
    fclose(pFile);
}

void Led2Trig(void)
{
    #define Trig2 "/sys/class/leds/beaglebone:green:usr2/trigger"
    FILE *pFile = fopen(Trig, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    int charWritten = fprintf(pFile, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    // Close the file using fclose():
    fclose(pFile);
}


void Led3Trig(void)
{
    #define Trig3 "/sys/class/leds/beaglebone:green:usr3/trigger"
    FILE *pFile = fopen(Trig, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    int charWritten = fprintf(pFile, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    // Close the file using fclose():
    fclose(pFile);
}

void Led0on(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr0/brightness", "1");
}
void Led0off(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr0/brightness", "0");
}

void Led1on(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr1/brightness", "1");
}
void Led1off(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr1/brightness", "0");
}

void Led2on(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr2/brightness", "1");
}
void Led2off(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr2/brightness", "0");
}

void Led3on(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr3/brightness", "1");
}
void Led3off(void)
{
    writeToAFile("/sys/class/leds/beaglebone:green:usr3/brightness", "0");
}



