#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <dirent.h>
#include <errno.h>
#define JOYSTICK_IN "/sys/class/gpio/gpio72/value"
#define JOYSTICK_DIRECTION "/sys/class/gpio/gpio72/direction"
#define GPIO_EXPORT "/sys/class/gpio/export"
#define GPIO_UNEXPORT "/sys/class/gpio/unexport"
#define BRIGHTNESS0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define BRIGHTNESS1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define BRIGHTNESS2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define BRIGHTNESS3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define TRIGGER0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define TRIGGER1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define TRIGGER2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define TRIGGER3 "/sys/class/leds/beaglebone:green:usr3/trigger"

static void sleepForMs(long long delayInMs);

static void runCommand(char* command);

static void sleepForMs(long long delayInMs);

static void writeToFile(const char* directory, const char* value);

int readFromFileToScreen(char *fileName);

static long long getTimeInMs(void);

int main() {
    printf("Hello embedded world, from Colin!\n");

    //configure user button
    runCommand("config-pin p8.43 gpio");

    //check if gpio72 directory exists
    DIR* dir = opendir(JOYSTICK_IN);
    if (ENOENT == errno)
    {
        //exports gpio72 if not already exported
        writeToFile(GPIO_EXPORT, "72");
    }
    closedir(dir);
    
    sleepForMs(500);
    
    //set all leds to off
    writeToFile(BRIGHTNESS0, "0");
    writeToFile(BRIGHTNESS1, "0");
    writeToFile(BRIGHTNESS2, "0");
    writeToFile(BRIGHTNESS3, "0");
    writeToFile(JOYSTICK_DIRECTION, "in");
    writeToFile(TRIGGER0, "none");
    writeToFile(TRIGGER1, "none");
    writeToFile(TRIGGER2, "none");
    writeToFile(TRIGGER3, "none");
    sleepForMs(500);


    int bestTime = 0;
    int score = 0;
    bool gameEnded = 0;
    long long time0 = 0; //time when led0 turns on
    long long time1 = 0; //time when timer starts
    long long time2 = 0; //time when button is pressed
    printf("When LED3 lights up, press the USER button!\n");

    while (!gameEnded)
    {
        bool early = 0;
        bool late = 0;
        if (readFromFileToScreen(JOYSTICK_IN) == 1)
        {
            writeToFile(BRIGHTNESS0, "1");
            writeToFile(BRIGHTNESS1, "0");
            writeToFile(BRIGHTNESS2, "0");
            writeToFile(BRIGHTNESS3, "0");
            time0 = getTimeInMs();

            //generate random delay from 0.5 to 3 seconds
            long long randomTime = (rand() % 2501) + 500;

            //check if user button is pushed early
            while(getTimeInMs() < (time0 + randomTime))
            {
                if (readFromFileToScreen(JOYSTICK_IN) == 0)
                {
                    early = 1;
                    score = 5000;
                    break;
                }

            }

            //if button is not pressed early
            if (early == 0)
            {
                //led3 turns on and timer starts
                writeToFile(BRIGHTNESS3, "1");
                time1 = getTimeInMs();
                while (readFromFileToScreen(JOYSTICK_IN) == 1)
                {
                    if (getTimeInMs() > (time1 + 5000)) {
                        late = 1;
                        break;
                    }
                }
                time2 = getTimeInMs();
                score = time2 - time1;
            }

            writeToFile(BRIGHTNESS0, "1");
            writeToFile(BRIGHTNESS1, "1");
            writeToFile(BRIGHTNESS2, "1");
            writeToFile(BRIGHTNESS3, "1");


            if (late == 0)
            {               
                if ((score < bestTime || bestTime == 0) && early == 0) 
                {
                    bestTime = score;
                    printf("New best time!\n");
                }
                printf("Your reaction time was %d", score);
                printf("ms; best so far in the game is %d", bestTime);
                printf("ms.\n");
            }

            if (late == 1 )
            {
                printf("No input within 5000ms; quitting!\n");
                writeToFile(BRIGHTNESS0, "0");
                writeToFile(BRIGHTNESS1, "0");
                writeToFile(BRIGHTNESS2, "0");
                writeToFile(BRIGHTNESS3, "0");
                gameEnded = 1;
            }

        }

    }


    writeToFile(GPIO_UNEXPORT, "72");

    return 0;
}

static void writeToFile(const char* directory, const char* value)
{
    // Use fopen() to open the file for write access.
    FILE *pFile = fopen(directory, "w");

    if (pFile == NULL) {
    printf("ERROR: Unable to open export file.\n");
    exit(1);
    }
    // Write to data to the file using fprintf():
    fprintf(pFile, "%s", value);
    // Close the file using fclose():
    fclose(pFile);
    // Call nanosleep() to sleep for ~300ms before use.
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}

int readFromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);


    // Close
    fclose(pFile);

    return atoi(buff);
}

static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}
