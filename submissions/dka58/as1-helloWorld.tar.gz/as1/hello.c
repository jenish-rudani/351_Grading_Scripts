#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//#define TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED0_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr3/brightness"
#define EXPORT_DIR "/sys/class/gpio/export"
#define VALUE_FILE "/sys/class/gpio/gpio72/value"

static void runCommand(char* command);
void readFromFileToScreen(char *fileName);
static void sleepForMs(long long delayInMs);
static long long getTimeInMs(void);
int readButtonStatus(char *fileName);
void TurnOnLED_n(char *Led_n_Name);
void TurnOffLED_n(char *Led_n_Name);
void TurnOnAllLED(void);
void TurnOffAllLED(void);

int main(void)
{
    
///////////CONFIGURING USER BUTTON ///////////
    char* pin_config = "config-pin p8.43 gpio";
    runCommand(pin_config);
    char* config_2_input = "echo in > /sys/class/gpio/gpio72/direction";
    runCommand(config_2_input);
    char* active_low_invert = "echo 1 > /sys/class/gpio/gpio72/active_low";
    runCommand(active_low_invert);
        //while button !press , value = 0
        //while button is pressed, value = 1
//////////END OF USER BUTTON CONFIGURATION////////
    

    printf("Hello embedded world, from Daniel! :D :D\n\n");
    printf("When LED3 lights up, press the USER button\n");

    //wait while user holds down USER button

    TurnOffAllLED();

    long long response_time, best_time = 5000;
    time_t t;
    
    srand((unsigned) time(&t));
    while(1){

        //wait while user holds down USER button
        while(readButtonStatus(VALUE_FILE))
        {
            sleepForMs(50);
        }
        
        /////enable up LED 0//////
        TurnOnLED_n(LED0_BRIGHTNESS_FILE);

        long long wait_rand_time = ((rand() % 3) + 1)*1000;
        //generates a random number between 1 and 3 
        sleepForMs(wait_rand_time);

        //if the button is already pressed after the wait then default message
        if(readButtonStatus(VALUE_FILE)) 
            response_time = 5000;

        while(!readButtonStatus(VALUE_FILE)){
            TurnOnLED_n(LED3_BRIGHTNESS_FILE);
            long long start_time, current_time;
            start_time = getTimeInMs();
            current_time = start_time;

            while((current_time-start_time) < 5001){
                current_time = getTimeInMs();
                if ( (current_time - start_time ) > 5000){
                    printf("No input within 5000 ms; quitting!\n");
                    exit(1);
                }
                if (readButtonStatus(VALUE_FILE)){
                    response_time = current_time - start_time;
                    break;
                }
            }
        }
        
        TurnOnAllLED();

        if(response_time < best_time){
            best_time = response_time;
            printf("New best time!\n");
        }
        printf("Your reaction time was %4lldms; ", response_time);
        printf("best so far in game is %4lldms.\n", best_time);
    
        TurnOffAllLED();
    
    }
    return 0;
}

static void runCommand(char* command)
{
// Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
// Ignore output of the command; but consume it
// so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
// printf("--> %s", buffer); // Uncomment for debugging
        }
// Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
        if (exitCode != 0) {
            perror("Unable to execute command:");
            printf(" command: %s\n", command);
            printf(" exit code: %d\n", exitCode);
    }
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

void readFromFileToScreen(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
printf("Read: '%s'\n", buff);
}

int readButtonStatus(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
    printf("ERROR: Unable to open file (%s) for read\n", fileName);
    exit(-1);
    }
    int isButtonPressed;
    fscanf(pFile, "%d", &isButtonPressed);
    fclose(pFile);
    return isButtonPressed;
}

void TurnOnLED_n(char *Led_n_Name)
{
    FILE *LedBrightnessFile = fopen(Led_n_Name, "w");
    if (LedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", Led_n_Name);
        exit(1);
        }

    int charWritten = fprintf(LedBrightnessFile, "1");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
        }
    fclose(LedBrightnessFile);
}

void TurnOffLED_n(char *Led_n_Name)
{
    FILE *LedBrightnessFile = fopen(Led_n_Name, "w");
    if (LedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", Led_n_Name);
        exit(1);
        }

    int charWritten = fprintf(LedBrightnessFile, "0");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
        }
    fclose(LedBrightnessFile);
}

void TurnOffAllLED(void)
{
        TurnOffLED_n(LED0_BRIGHTNESS_FILE);
        TurnOffLED_n(LED1_BRIGHTNESS_FILE);
        TurnOffLED_n(LED2_BRIGHTNESS_FILE);
        TurnOffLED_n(LED3_BRIGHTNESS_FILE);
}

void TurnOnAllLED(void)
{
        TurnOnLED_n(LED0_BRIGHTNESS_FILE);
        TurnOnLED_n(LED1_BRIGHTNESS_FILE);
        TurnOnLED_n(LED2_BRIGHTNESS_FILE);
        TurnOnLED_n(LED3_BRIGHTNESS_FILE);
}