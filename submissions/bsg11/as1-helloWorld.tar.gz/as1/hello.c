
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define trigger_file0 "/sys/devices/platform/leds/leds/beaglebone:green:usr0/trigger"
#define trigger_file1 "/sys/devices/platform/leds/leds/beaglebone:green:usr1/trigger"
#define trigger_file2 "/sys/devices/platform/leds/leds/beaglebone:green:usr2/trigger"
#define trigger_file3 "/sys/devices/platform/leds/leds/beaglebone:green:usr3/trigger"
#define brightnessled0 "/sys/devices/platform/leds/leds/beaglebone:green:usr0/brightness"
#define brightnessled1 "/sys/devices/platform/leds/leds/beaglebone:green:usr1/brightness"
#define brightnessled2 "/sys/devices/platform/leds/leds/beaglebone:green:usr2/brightness"
#define brightnessled3 "/sys/devices/platform/leds/leds/beaglebone:green:usr3/brightness"
#define inputFile "/sys/class/gpio/gpio72/value"

static long long getTimeInMS(void)
    {
        struct timespec spec;
        clock_gettime(CLOCK_REALTIME, &spec);
        long long seconds = spec.tv_sec;
        long long nanoseconds = spec.tv_nsec;
        long long milliseconds = seconds * 1000 + nanoseconds / 1000000;
        return milliseconds;    
    }

    static void sleepForMs(long long delayInMs)
    {

        const long long NS_PER_MS = 1000*1000;
        const long long NS_PER_SECOND = 1000000000;

        long long delayNs = delayInMs * NS_PER_MS;
        int seconds = delayNs / NS_PER_SECOND;
        int nanoseconds = delayNs % NS_PER_SECOND;

        struct timespec reqDelay = {seconds, nanoseconds};
        nanosleep(&reqDelay, (struct timespec *) NULL);


    }


void turnOffLED(char *filename){

    FILE *brightnessfile = fopen(filename,"w");

    if (brightnessfile == NULL){

        printf("ERROR OPENING file in turn off led function\n");
        exit(1);
    }

    int charWritten = fprintf(brightnessfile,"0");
    if (charWritten<=0){

        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(brightnessfile);

    //printf("LED was successfully turned off\n");

}
void turnOnLED(char *filename){

    FILE *brightnessfile = fopen(filename,"w");

    if (brightnessfile == NULL){

        printf("ERROR OPENING file in turn on led function\n");
        exit(1);
    }

    int charWritten = fprintf(brightnessfile,"1");
    if (charWritten<=0){

        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(brightnessfile);


    }



void setTriggertoNone(char *fileName){

    FILE *triggerFile = fopen(fileName, "w");
    if (triggerFile == NULL){

        printf("ERROR OPENING file in set trigger to none function\n");
        exit(1);
    }

    int charWritten = fprintf(triggerFile,"none");
    if (charWritten<=0){

        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(triggerFile);
    //printf("LED trigger was set to none\n");
        
    }

void setTriggertoTimer(char *fileName){

    FILE *triggerFile = fopen(fileName, "w");
    if (triggerFile == NULL){

        printf("ERROR OPENING file in set trigger to timer function \n");
        exit(1);
    }

    int charWritten = fprintf(triggerFile,"timer");
    if (charWritten<=0){

        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(triggerFile);
    }






static int readFromPinValueFile(const char *fileName){

    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {

        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
            }

    int valueOfButton;

    fscanf (pFile, "%d", &valueOfButton);
    
    
    fclose(pFile);

    if (valueOfButton == 1){

        return 1; // it is not being pressed
    }
    
    else if (valueOfButton == 0)
    {
        return 0; // 0 means it is being pressed
    }
    
    else {

        printf("error reading input\n");
        return -1;
    }

}

static void runCommand (char* command){


    FILE *pipe = popen(command, "r");
    char buffer[1024];

    while (!feof(pipe) && !ferror(pipe)) {

        if (fgets(buffer,sizeof(buffer),pipe)==NULL)
            break;
        //printf("--> %s", buffer);
    }

    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode!=0){

        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }

}

void turnonAllLEDs(void){
    turnOnLED(brightnessled0);
    turnOnLED(brightnessled1);
    turnOnLED(brightnessled2);
    turnOnLED(brightnessled3);
}

void turnOffAllLEDs(void){
    turnOffLED(brightnessled0);
    turnOffLED(brightnessled1);
    turnOffLED(brightnessled2);
    turnOffLED(brightnessled3);
}

/************************************************************************************************************************************************************/
/************************************************************************************************************************************************************/
/************************************************************************************************************************************************************/
/************************************************************************************************************************************************************/
/************************************************************************************************************************************************************/



int main(){
    static long long startTime, time2, time3, time_elapsed1, time_elapsed2;
    static long long best_time = 5000;

    printf("Hello embedded world, from Bobby!\n");


    // turnOffLED(brightnessled0);
    // turnOffLED(brightnessled1);
    // turnOffLED(brightnessled2);
    // turnOffLED(brightnessled3);

    // setTriggertoNone(trigger_file0);
    // setTriggertoNone(trigger_file1);
    // setTriggertoNone(trigger_file2);
    // setTriggertoNone(trigger_file3);

    //config-pin

runCommand("config-pin p8.43 gpio");


///////////////////////////////////

// set pin to be input (not specified in instructions)
    FILE *pFile = fopen("/sys/class/gpio/gpio72/direction","w");
    if (pFile == NULL){
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }

    fprintf(pFile, "%s", "in");
    
   

printf("when LED3 lights up, press the USER button!\n");

while (time_elapsed1<5000){

    turnOffAllLEDs();

    setTriggertoNone(trigger_file0);
    setTriggertoNone(trigger_file1);
    setTriggertoNone(trigger_file2);
    setTriggertoNone(trigger_file3);

        if(readFromPinValueFile(inputFile) == 1){
            turnOnLED(brightnessled0);
            srand (time(NULL));
            float randomNumberinSeconds =  ((float)rand()) / ((float)RAND_MAX) * 2.5 + 0.5;
            //printf("Random Number in seconds: %f \n", randomNumberinSeconds);
            long long randomNumberinMs = randomNumberinSeconds*1000;
            sleepForMs(randomNumberinMs);

            turnOffLED(brightnessled0);
            turnOnLED(brightnessled3);
            startTime = getTimeInMS();
            if (readFromPinValueFile(inputFile) == 0){
                printf("The button was pushed before the led was lit up! Response time is recorded as 5 seconds.\n");
                turnonAllLEDs();
    
            }
            else {
            while (readFromPinValueFile(inputFile)==1)
            {
                turnOnLED(brightnessled3);
                readFromPinValueFile(inputFile);
               
                
                if (readFromPinValueFile(inputFile)==0){

                    //turnOffLED(brightnessled3);
                    turnonAllLEDs();
                    time3 = getTimeInMS();
                    time_elapsed2 = time3 - startTime;
                    if (time_elapsed2 < best_time){
                        best_time = time_elapsed2;
                        printf("New high score!\n");
                        
                    }
                        
                    
                    printf("Your reaction time was: %lldms; The best reaction time so far in this game is: %lldms\n", time_elapsed2, best_time);
                        
                       
                    
                }
                else {
                    time2 = getTimeInMS();
                    time_elapsed1 = time2 - startTime;

                    if (time_elapsed1 > 5000){
                        turnOffAllLEDs();
                        printf("No input within 5000ms, terminating...\n\n\n");
                        break;
                    }

                }
                }
            }
        }
                
            
            }
        printf("Program ended. \n");
        
        
        turnOffAllLEDs();
        return 0;
}