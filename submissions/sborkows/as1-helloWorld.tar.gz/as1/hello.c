#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "leds.h"
#include "button.h"

static long long getTimeInMs(void);

int main()
{
    printf("Hello embedded world, from Steve!\n");
    printf("\nWhen LED3 lights up, press the user button.\n");
    setLEDState("0000");
    setLEDTriggers("none", "none", "none", "none");
    configureUSRButton();

    static long long start_time = 0;
    static long long running_time = 0;
    static long long random_time = 0;
    static long long my_time = 0;
    static long long record_time = 0;
    bool not_idle = true;

    record_time = getTimeInMs();
    srand(time(NULL));

    while(not_idle){ // Repeats until game times out
        random_time = (rand() % (3000 - 500 +1)) + 500;
        setLEDState("1000");
        start_time = getTimeInMs();

        while(true){ // Repeats until user presses button or running time exceeds 5s (game times out)
            running_time = getTimeInMs() - start_time;
            if(running_time >= random_time){
                setLEDState("1010");
                my_time = running_time - random_time;
                if(my_time >= 5000){
                    not_idle = false;
                    break;
                }
                if(buttonPressed()){
                    break;
                }
            }
            if(running_time < random_time){
                if(buttonPressed()){
                    my_time = 5000;
                    break;
                }
            }
        }

        if(not_idle){
            if(my_time < record_time){
                printf("New best time!\n");
                record_time = my_time;
            }
            printf("Your reaction time: %lli ms, Current record is: %lli ms\n", my_time, record_time);
            setLEDState("1111");
            while(!buttonPressed()){}
            while(buttonPressed()){}
        }
    }
    setLEDState("0000");
    printf("Idle for 5000ms; quitting now...\n");
    return 0;
}

// The below function was taken from the Assignment 1 document
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}