/*
 *  The button module contains methods to configure the user button on
 *  the BBG and see if it is pressed down.
 */

#ifndef BUTTON_H_
#define BUTTON_H_
#include <stdbool.h>

#define BUTTON_PATH "/sys/class/gpio/gpio72"

// The following method draws from the Assignment 1 document.
void configureUSRButton()
{
    FILE *pipe = popen("config-pin p8.43 gpio", "r");
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)){
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        {
            break;
        }
    }
    
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0){
        perror("Unable to execute command:");
        printf(" command: %s\n", "config-pin p8.43 gpio");
        printf(" exit code: %d\n", exitCode);
    }

    FILE *button_file;
    button_file = fopen(BUTTON_PATH "/direction", "w");
    fprintf(button_file, "1");
    fclose(button_file);

    return;
}

bool buttonPressed()
{
    FILE *button_file;
    int val[1];
    button_file = fopen(BUTTON_PATH "/value", "r");
    fread(val, 1, 1, button_file); // the char in the file is read as an int to convert to boolean
    fclose(button_file);
    return !(val[0] - 48); 
}

#endif