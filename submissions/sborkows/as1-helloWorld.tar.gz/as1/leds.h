/*
 *  The leds module contains methods to set the state (on/off) and triggers
 *  of each of the LEDs on the BBG.
 */

#ifndef LEDS_H_
#define LEDS_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define LED_PATH "/sys/class/leds/beaglebone:green:usr"

int setLEDState(char* in_bits)
{
    FILE *bright_file;
    for(int i = 0; i <= 3; i++){
        switch(i){
            case 0:
                bright_file = fopen(LED_PATH "0/brightness", "w");
                break;
            case 1:
                bright_file = fopen(LED_PATH "1/brightness", "w");
                break;
            case 2:
                bright_file = fopen(LED_PATH "2/brightness", "w");
                break;
            case 3:
                bright_file = fopen(LED_PATH "3/brightness", "w");
                break;
        }
        fprintf(bright_file, "%c",in_bits[i]);
        fclose(bright_file);
    }
    return 1;
}

int setLEDTriggers(char* trig0, char* trig1, char* trig2, char* trig3)
{
    FILE *trig_file;
    for(int i = 0; i <= 3; i++){
        switch(i){
            case 0:
                trig_file = fopen(LED_PATH "0/trigger", "w");
                fprintf(trig_file, trig0);
                break;
            case 1:
                trig_file = fopen(LED_PATH "1/trigger", "w");
                fprintf(trig_file, trig1);
                break;
            case 2:
                trig_file = fopen(LED_PATH "2/trigger", "w");
                fprintf(trig_file, trig2);
                break;
            case 3:
                trig_file = fopen(LED_PATH "3/trigger", "w");
                fprintf(trig_file, trig3);
                break;
        }
        fclose(trig_file);
    }
    return 1;
}

#endif