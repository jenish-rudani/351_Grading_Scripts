#include <stdio.h>
#include <time.h>

#define LED0T "/sys/class/leds/beaglebone:green:usr0/trigger" 
#define LED0B "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1B "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2B "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3B "/sys/class/leds/beaglebone:green:usr3/brightness"
#define BUTT "/sys/class/gpio/gpio72/value"


//displaysum displays all the info, current and best reraction time in ms

//rtsf is the reaction time variable for the fuction "display summary summary", similarly hssf
//is high score summary function
void displaysum(long long rtsf, long long hssf)
{
	printf("Your reaction time was %lld ms; best so far in the game is %lld ms\n", rtsf, hssf);
}

int readFromFile(char *fileName)
{
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL)
	{
		printf("ERROR to open file (%s) for read\n", fileName);
		exit(-1);
	}
	// Read string (line)
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	// Close
	fclose(pFile);
	int i = buff[0] - '0';
	return i;
}

void LEDon(char *a)
{
		FILE *LED0FileOn = fopen(a, "w");
		if (LED0FileOn == NULL)
		{
			printf("ERROR OPENING LED0 brightness file to turn on %s.", a);
			exit(1);
		}
		int charWritten2 = fprintf(LED0FileOn, "1");
		if (charWritten2 <= 0) 
		{
			printf("ERROR WRITING DATA to LED0 brightness fileto turn on\n");
			exit(1);
		}
		fclose(LED0FileOn);
}

void LEDoff(char *a)
{
		FILE *LED0FileOn = fopen(a, "w");
		if (LED0FileOn == NULL)
		{
			printf("ERROR OPENING LED brightness file to turn off %s.", a);
			exit(1);
		}
		int charWritten2 = fprintf(LED0FileOn, "0");
		if (charWritten2 <= 0) 
		{
			printf("ERROR WRITING DATA to LED brightness file to turn off\n");
			exit(1);
		}
		fclose(LED0FileOn);
}

void writeToFile(char *fileName)
{
	FILE *pFile = fopen("/sys/class/gpio/export", "w");
	if (pFile == NULL) {
		printf("ERROR: Unable to open export file.\n");
		exit(1);
	}
	// Write to data to the file using fprintf():
	fprintf(pFile, "%d", 30);
	// Close the file using fclose():
	fclose(pFile);
}

static long long getTimeInMs(void)
{
 	struct timespec spec;
 	clock_gettime(CLOCK_REALTIME, &spec);
 	long long seconds = spec.tv_sec;
 	long long nanoSeconds = spec.tv_nsec;
 	long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
 	return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
 	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;
	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
 	int nanoseconds = delayNs % NS_PER_SECOND;
 	struct timespec reqDelay = {seconds, nanoseconds};
 	nanosleep(&reqDelay, (struct timespec *) NULL);
}




//rt is the reaction time variable, hs is the high score variable
//userb is the variable that holds the status of the user button

int main(int argc, char* args[])
{
	
	
	//SETUP /////////////////////////////////////////////////////////////////////
	
	
	//config user button pin as input
	FILE *pFile = fopen("/sys/class/gpio/gpio72/direction", "w");
	if (pFile == NULL) {
		printf("ERROR: Unable to open export file.\n");
		exit(1);
	}
	fprintf(pFile, "%s", "in");
	fclose(pFile);
	
	
	//turn off LED0 and wait for user button to be pressed
	LEDoff(LED0B);
	LEDoff(LED1B);
	LEDoff(LED2B);
	LEDoff(LED3B);
	
	
	//GAME BEGIN ////////////////////////////////////////////////////////////////////////////////////////
	printf("Hello embedded world, from Georgiy\n");
	
	//wait for the user to bress the user button
	int userb = 1;
	while (userb == 1){
		userb = readFromFile(BUTT);
	}
	
	long long rt = 4999;
	long long hs = 5001;
	printf("When LED3 lights up, press the USER button!\n");
	while(rt < 5000)
		{


		//turn on LED0 indicating game is about to begin, and off all the others
		LEDon(LED0B);
		LEDoff(LED1B);
		LEDoff(LED2B);
		LEDoff(LED3B);
		
		
		//wait 2.5 seconds for the game to begin
		long long x = 2500;
		sleepForMs(x);
		
		/*/check if user was pressing the button too early
		if(userb == 1)
		{
			rt = 5000;
		}
		*/
		
		//Reaction time itself, turn on LED3 and wait for user button
		
		FILE *LED3FileOn = fopen(LED3B, "w");
		if (LED3FileOn == NULL)
		{
			printf("ERROR OPENING LED0 brightness file %s.", LED3B);
			exit(1);
		}
		int charWritten3 = fprintf(LED3FileOn, "1");
		if (charWritten3 <= 0) 
		{
			printf("ERROR WRITING DATA to LED0 brightness file\n");
			exit(1);
		}
		fclose(LED3FileOn);
		long long initial;
		initial = getTimeInMs();
		
		int userb = 1;
		while (userb == 1){
			userb = readFromFile(BUTT);
			long long toolong;
			toolong = getTimeInMs();
			long long ex = toolong - initial;
			if(ex > 5000){
				printf("No input within 5000ms; Quitting\n");
				LEDoff(LED0B);
				LEDoff(LED1B);
				LEDoff(LED2B);
				LEDoff(LED3B);
				exit(1);
			}
		}
		
		long long final;
		final = getTimeInMs();
		
		rt = final - initial;
		if(rt < hs){
			printf("New best time!\n");
			hs = rt;
		}
		//trun on all LEDS
		LEDon(LED0B);
		LEDon(LED1B);
		LEDon(LED2B);
		LEDon(LED3B);
		displaysum(rt,hs);
		long long y = 50;
		sleepForMs(x);
		userb = 1;
		while (userb == 1){
			userb = readFromFile(BUTT);
		}
		
	}
	LEDoff(LED0B);
	LEDoff(LED1B);
	LEDoff(LED2B);
	LEDoff(LED3B);
	

	return 0;
}




