#define LED0Path "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1Path "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2Path "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3Path "/sys/class/leds/beaglebone:green:usr3/brightness"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

static long long getTimeInMs(void)
{
	 struct timespec spec;
	 clock_gettime(CLOCK_REALTIME, &spec);
	 long long seconds = spec.tv_sec;
	 long long nanoSeconds = spec.tv_nsec;
	 long long milliSeconds = (seconds * 1000) + (nanoSeconds / 1000000);
	 return milliSeconds;
}


int main()
{
	char x[50];
	printf("Enter name : ");
	scanf("%[^\n]%*c", x);
	printf("Hello embedded world, from %s\n", x);
	
	FILE *LED0=fopen(LED0Path, "w");
        FILE *LED1=fopen(LED1Path, "w");
        FILE *LED2=fopen(LED2Path, "w");
        FILE *LED3=fopen(LED3Path, "w");
        long long start;
        long long stop;
        long long current=0;
        long long best=0;
        
      
	
	//LED0 - on
	fprintf(LED0, "%d", 1);
	fclose(LED0);

	printf("When LED3 lights up, press the USER button!\n");
	printf("3 sec count - 1 2 3!\n");
	
	//sleep for 3s
	long seconds = 3;
	long nanoseconds = 0;
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
	
	//Reading USER pin input
	FILE *value = fopen("/sys/class/gpio/gpio72/value", "r");
	int val;
	fscanf(value, "%d", &val);
	fclose(value);
	
	//LED0 - off
	fopen(LED0Path,"w");
	fprintf(LED0, "%d", 0);
	fclose(LED0);
	
	if(val == 0)
	{
		printf("USER input before LED-3 is on.\n");
		fopen(LED0Path,"w");
		fprintf(LED0, "%d", 1);
	  	fprintf(LED1, "%d", 1);
	  	fprintf(LED2, "%d", 1);
	  	fprintf(LED3, "%d", 1);
	  	fclose(LED0);
   		fclose(LED1);
      		fclose(LED2);
   		fclose(LED3);
		current = 5000LL;
		printf("Your reaction time was  is %lld ms right!", current);
		printf("; best so far in game is  is %lld ms right!\n\n", current);
		fopen(LED0Path,"w");
		fopen(LED1Path,"w");
		fopen(LED2Path,"w");
		fopen(LED3Path,"w");
		fprintf(LED0, "%d", 0);
		fprintf(LED1, "%d", 0);
		fprintf(LED2, "%d", 0);	
		fprintf(LED3, "%d", 0);	
	   	fclose(LED0);
	   	fclose(LED1);
	      	fclose(LED2);
	   	fclose(LED3);
	}
		
	else {

	//LED3 - on
	fprintf(LED3, "%d", 1);
	fclose(LED3);
	
	start = getTimeInMs();
	
	long long var = 5000LL;
	
	while( current<var )
	  {
		if(val == 0) 
		{	
			stop = getTimeInMs();	
			
			fopen(LED0Path,"w");
			fopen(LED1Path,"w");
			fopen(LED2Path,"w");
			fprintf(LED0, "%d", 1);
			fprintf(LED1, "%d", 1);
			fprintf(LED2, "%d", 1);
			fclose(LED0);
		   	fclose(LED1);
		      	fclose(LED2);
			
			current = stop - start;
			if(current<best) 
			{
				best=current;
				printf("New Best!!!");		
			}
			
			printf("Your reaction time was  is %lld ms right!", current);
			printf("; best so far in game is  is %lld ms right!\n", best);

			//sleep for 1 -- To show all LED is ON
			long seconds = 1;
			long nanoseconds = 0;
			struct timespec reqDelay = {seconds, nanoseconds};
			nanosleep(&reqDelay, (struct timespec *) NULL);
			
			fopen(LED0Path,"w");
			fopen(LED1Path,"w");
			fopen(LED2Path,"w");
			fprintf(LED0, "%d", 0);
			fprintf(LED1, "%d", 0);
			fprintf(LED2, "%d", 0);
			fclose(LED0);
		   	fclose(LED1);
		      	fclose(LED2);
		      	
		      	//sleep for 1s  -- Next pin input
		      	long seconds_1 = 1;
			long nanoseconds_1 = 0;
			struct timespec reqDelay_1 = {seconds_1, nanoseconds_1};
			nanosleep(&reqDelay_1, (struct timespec *) NULL);
			
		      	start = getTimeInMs();
		}
		else {	current=getTimeInMs()-start;	}

		fopen("/sys/class/gpio/gpio72/value", "r");
		fscanf(value, "%d", &val);
		fclose(value);
	  }
	  
	  fopen(LED0Path,"w");
	  fopen(LED1Path,"w");
	  fopen(LED2Path,"w");
	  fprintf(LED0, "%d", 1);
	  fprintf(LED1, "%d", 1);
	  fprintf(LED2, "%d", 1);
	  fclose(LED0);
   	  fclose(LED1);
      	  fclose(LED2);
	  printf("No input within 5 s; quitting!\n\n");
	  
	  fopen(LED3Path,"w");
	  fprintf(LED3, "%d", 0);
	  fclose(LED3);
	  
	  fopen(LED0Path,"w");
	  fopen(LED1Path,"w");
	  fopen(LED2Path,"w");
	  fopen(LED3Path,"w");
	  fprintf(LED0, "%d", 0);
	  fprintf(LED1, "%d", 0);
	  fprintf(LED2, "%d", 0);	
	  fprintf(LED3, "%d", 0);	
   	  fclose(LED0);
   	  fclose(LED1);
      	  fclose(LED2);
   	  fclose(LED3);
	}
	
	
	return 0;
}
