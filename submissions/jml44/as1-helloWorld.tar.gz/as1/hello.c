#include <stdio.h>
#include <time.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdbool.h>
//paths to trigger
#define LED0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3 "/sys/class/leds/beaglebone:green:usr3/trigger"
//paths to LED on off
#define LED0_B "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_B "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_B "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_B "/sys/class/leds/beaglebone:green:usr3/brightness"

#define USR_Button_State "/sys/class/gpio/gpio72/value"
#define USR_Button_Input "/sys/class/gpio/gpio72/direction"

void initialize_LEDs(){
FILE *LED0_Trigger=fopen(LED0,"r+");
FILE *LED1_Trigger=fopen(LED1,"r+");
FILE *LED2_Trigger=fopen(LED2,"r+");
FILE *LED3_Trigger=fopen(LED3,"r+");

//writes "none" to all the LED trigger files
fprintf(LED0_Trigger,"none");
fprintf(LED1_Trigger,"none");
fprintf(LED2_Trigger,"none");
fprintf(LED3_Trigger,"none");


fclose(LED0_Trigger);
fclose(LED1_Trigger);
fclose(LED2_Trigger);
fclose(LED3_Trigger);
}

void turn_on_LED (char *brightness_path){
FILE *LED_ON=fopen(brightness_path,"r+");
if (LED_ON == NULL){
    printf("ERROR OPENING %s.", brightness_path);
    exit(1);
}
int charWritten=fprintf(LED_ON,"1");
if (charWritten <= 0)
{
    printf("ERROR WRITING DATA");
    exit (1);
}
fclose(LED_ON);
}

void turn_off_LED (char *brightness_path){
FILE *LED_OFF=fopen(brightness_path,"r+");
if (LED_OFF == NULL){
    printf("ERROR OPENING %s.", brightness_path);
    exit(1);
}
int charWritten=fprintf(LED_OFF,"0");
if (charWritten <= 0)
{
    printf("ERROR WRITING DATA");
    exit (1);
}
fclose(LED_OFF);
}

long long generateRandomTime()
{
    srand(time(NULL));
    const long long upper=3000;
    const long long lower=500;
    long long num = (rand()%(upper-lower+1)+lower);
    return num;
} 

static void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}




static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
        // printf("--> %s", buffer); // Uncomment for debugging
        }
        // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

char readFromFileToScreen(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
return *buff;
}


int main(int argc, char*args[]) 
{
bool start_button_pressed=false;
bool button_released=false;
bool exit_condition=false;
long long best_time=0;
long long reaction_time=0;


initialize_LEDs();


printf("Hello embedded world, from James Li!\n");
printf("Press the USR button to start the game\n");
char *pin_config = "config-pin p8.43 gpio";
runCommand(pin_config);

//waiting for the button press to be released to start the counter

while (exit_condition==false){


while (start_button_pressed==false)
{
 char state=readFromFileToScreen(USR_Button_State);
 turn_off_LED(LED0_B);
 turn_off_LED(LED1_B);
 turn_off_LED(LED2_B);
 turn_off_LED(LED3_B);
    if (state=='0'){
        
        while (button_released==false)
        {
            char pressed_down=readFromFileToScreen(USR_Button_State);
            if (pressed_down=='1'){
                turn_on_LED(LED0_B);
                button_released=true;
                start_button_pressed=true;
            }
            else
            {
                button_released=false;
            }
        }
    }
    else 
    {
        start_button_pressed=false;
    }
}
//give an extra 100ms for user to be ready to press the button again
sleepForMs(100);

char reaction_press=readFromFileToScreen(USR_Button_State);
long long start_time=getTimeInMs();
long long timer=getTimeInMs();
long long elapsed_time=generateRandomTime();
long long LED_on_time=start_time+elapsed_time;

//loop check the switch before the light turns on, sets reaction time to 5000ms if it's pressed before the light turns on.
while (timer <= LED_on_time){
    timer=getTimeInMs();
    reaction_press=readFromFileToScreen(USR_Button_State);
    if (reaction_press=='0')
    {
        reaction_time=5000;
        break;
    }
}
turn_on_LED(LED3_B);

while(timer >= LED_on_time){
    timer=getTimeInMs();
    reaction_press=readFromFileToScreen(USR_Button_State);
    if(reaction_press=='0'){
        reaction_time=timer-LED_on_time;
        turn_on_LED(LED0_B);
        turn_on_LED(LED1_B);
        turn_on_LED(LED2_B);
        turn_on_LED(LED3_B);
        break;
    }
    //if input been inactive for longer than 5000 exits program
    if(timer >= LED_on_time+5000 && reaction_press=='1'){
        printf("No input within 5000ms; quitting!\n");
        turn_off_LED(LED0_B);
        turn_off_LED(LED1_B);
        turn_off_LED(LED2_B);
        turn_off_LED(LED3_B);
        exit (2);
    }



}

if (best_time == 0 || best_time > reaction_time)
    {
        best_time=reaction_time;
        }

        printf("Your reaction time was %lldms; your best time is %lldms.\n",reaction_time,best_time);
//resets loop flag 
    start_button_pressed=false;
    button_released=false;

    
}





return 0;

}

