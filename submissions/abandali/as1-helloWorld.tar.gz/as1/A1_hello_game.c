//Written by Armaan Bandali


#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include <sys/wait.h> //https://www.ibm.com/docs/en/ztpf/1.1.0.15?topic=apis-wexitstatusobtain-exit-status-child-process

#define USER_BUTTON_VALUE_FILE "/sys/class/gpio/gpio72/value"
#define CMD_CONFIG_BUTTON_GPIO "cd /sys/class/gpio/\nconfig-pin p8.43 gpio"
#define CMD_CONFIG_BUTTON_INPUT "cd /sys/class/gpio/gpio72/\n echo in > direction"
#define TRIGGER_FILE_LED_0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define TRIGGER_FILE_LED_1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define TRIGGER_FILE_LED_2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define TRIGGER_FILE_LED_3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define BRIGHTNESS_FILE_LED_0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define BRIGHTNESS_FILE_LED_1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define BRIGHTNESS_FILE_LED_2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define BRIGHTNESS_FILE_LED_3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define DESIRED_TRIGGER "none"
#define DEFAULT_TRIGGER_0 "heartbeat"
#define DEFAULT_TRIGGER_1 "mmc0"
#define DEFAULT_TRIGGER_2 "cpu0"
#define DEFAULT_TRIGGER_3 "mmc1"
#define MAX_REACTION_TIME 5000


#define DEFAULT_SLEEP_TIME 100

enum LED_ID {LED_0, LED_1, LED_2, LED_3};

//Dr. Brian's function
//Return current Unix time in ms
static long long getTimeInMs(void)
{
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000
	+ nanoSeconds / 1000000;
	return milliSeconds;
}

//Dr. Brian's function
//Program sleeps for specified time in ms
static void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

//Dr. Brian's function
//Execute terminal command specified by "command"
static void runCommand(char* command)
{
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) 
	{
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
			break;
		//printf("--> %s", buffer); // Uncomment for debugging
	}
	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) 
	{
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
	}
}

//Follows Dr. Brian's notes from LED Guide
//Write parameter setting (trigger, brightness, etc.) to LED file
static void setLEDParam(char *fileName, char *paramValue)
{
	FILE *pFile = fopen(fileName, "w");
	if (pFile == NULL) 
	{
		printf("ERROR: Unable to open file (%s) for read\n", USER_BUTTON_VALUE_FILE);
		exit(-1);
	}

	//Write to file
	int charWritten = fprintf(pFile, paramValue);
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	// Close
	fclose(pFile);
}

//Set LEDs to trigger "none"
static void configureLEDs()
{
	setLEDParam(TRIGGER_FILE_LED_0, DESIRED_TRIGGER);
	setLEDParam(TRIGGER_FILE_LED_1, DESIRED_TRIGGER);
	setLEDParam(TRIGGER_FILE_LED_2, DESIRED_TRIGGER);
	setLEDParam(TRIGGER_FILE_LED_3, DESIRED_TRIGGER);
}

// static void restoreLEDs()
// {
// 	setLEDParam(TRIGGER_FILE_LED_0, DEFAULT_TRIGGER_0);
// 		setLEDParam(TRIGGER_FILE_LED_1, DEFAULT_TRIGGER_1);
// 		setLEDParam(TRIGGER_FILE_LED_2, DEFAULT_TRIGGER_2);
// 		setLEDParam(TRIGGER_FILE_LED_3, DEFAULT_TRIGGER_3);
// }

//Configure USER button for GPIO input reading
static void configureButton()
{
	runCommand(CMD_CONFIG_BUTTON_GPIO);
	runCommand(CMD_CONFIG_BUTTON_INPUT);
}

//Follows Dr. Brian's notes from GPIO guide
//Read button value from file and return true if pushed down
static bool userButtonPushed()
{
	FILE *pFile = fopen(USER_BUTTON_VALUE_FILE, "r");
	if (pFile == NULL) 
	{
		printf("ERROR: Unable to open file (%s) for read\n", USER_BUTTON_VALUE_FILE);
		exit(-1);
	}

	// Read string (line)
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);

	// Close
	fclose(pFile);

	if (buff[0] == '1') //Button is active_low
	{
		return false;
	}
	else
	{
		return true;
	}
}

//Turn on or off specific LED
//Setting == 1 turns light on
static void lightLED(enum LED_ID LEDToLight, int setting)
{
	if(setting == 1)
	{
		switch (LEDToLight)
		{
		case LED_0:
			setLEDParam(BRIGHTNESS_FILE_LED_0, "1");
			break;
		case LED_1:
			setLEDParam(BRIGHTNESS_FILE_LED_1, "1");
			break;
		case LED_2:
			setLEDParam(BRIGHTNESS_FILE_LED_2, "1");
			break;
		case LED_3:
			setLEDParam(BRIGHTNESS_FILE_LED_3, "1");
			break;
		default:
			break;
		}
	}
	else
	{
		switch (LEDToLight)
		{
		case LED_0:
			setLEDParam(BRIGHTNESS_FILE_LED_0, "0");
			break;
		case LED_1:
			setLEDParam(BRIGHTNESS_FILE_LED_1, "0");
			break;
		case LED_2:
			setLEDParam(BRIGHTNESS_FILE_LED_2, "0");
			break;
		case LED_3:
			setLEDParam(BRIGHTNESS_FILE_LED_3, "0");
			break;
		default:
			break;
		}
	}
}

//Turn off all LEDs
static void turnOffAllLEDs()
{
	lightLED(LED_0,0);
	lightLED(LED_1,0);
	lightLED(LED_2,0);
	lightLED(LED_3,0);
}

//Turn on all LEDs
static void turnOnAllLEDs()
{
	lightLED(LED_0,1);
	lightLED(LED_1,1);
	lightLED(LED_2,1);
	lightLED(LED_3,1);
}


//Return a random number between 500 and 3000 to sleep program
static long long randomSleepTime()
{
	//Return a random number bwtween 500 and 3000
	srand(time(NULL));
	return (long long)(rand()%2500 + 500); //https://cplusplus.com/reference/cstdlib/srand/
}

int main(int argc, char* args[])
{
	bool gameOver = false;
	long long bestReactionTime = MAX_REACTION_TIME;
	long long startTime = 0;
	long long reactionTime = 0;

	printf("Hello embedded world, from Armaan!\n\n");
	printf("When LED3 lights up, press the USER button\n");

	configureButton();
	configureLEDs();

	while(!gameOver)
	{
		reactionTime = 0;
		while(userButtonPushed()) //wait for player to release USER button before starting next round
		{
			continue;
		}
		turnOffAllLEDs();
		lightLED(LED_0, 1); //indicates start of game
		sleepForMs(randomSleepTime());
		lightLED(LED_0, 0);
		lightLED(LED_3, 1); //indicates game state change
		startTime = getTimeInMs();
		if(userButtonPushed())
		{
			reactionTime = MAX_REACTION_TIME; //set reaction time to 5000ms and turn on LEDs if button prematurely pressed
			turnOnAllLEDs();
		}
		else{
			while (!userButtonPushed()) //wait for user to press button, end game if wait > 5000ms
			{
				if((getTimeInMs()-startTime) > MAX_REACTION_TIME)
				{
					gameOver = true;
					reactionTime = MAX_REACTION_TIME+1; //differentiates from premature press
					printf("No input within 5000ms; quitting!\n");
					break;
				}
			}
		}
		if(reactionTime <= MAX_REACTION_TIME)
		{
			if(reactionTime != MAX_REACTION_TIME) //not a premature press
				reactionTime = getTimeInMs()-startTime;
			turnOnAllLEDs();
			if (reactionTime < bestReactionTime)
			{
				bestReactionTime = reactionTime;
				printf("New best time!\n");
			}
			printf("Your reaction time was %dms; best so far in game is %dms.\n", (int)reactionTime, (int)bestReactionTime);
		}
		sleepForMs(DEFAULT_SLEEP_TIME); //smoother transition for LEDs all lit
	}

	turnOffAllLEDs();
	return 0;
}

