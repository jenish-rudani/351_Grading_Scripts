#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/wait.h>

#define Led0_trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define Led1_trigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define Led2_trigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define Led3_trigger "/sys/class/leds/beaglebone:green:usr3/trigger"

#define Led0_brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define Led1_brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define Led2_brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define Led3_brightness "/sys/class/leds/beaglebone:green:usr3/brightness"

#define userButton "/sys/class/gpio/gpio72/value"

int readFromFileToScreen(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
//printf("Read: '%s'\n", buff);
return atoi(buff);
}

static void runCommand(char* command)
{
// Execute the shell command (output into pipe)
FILE *pipe = popen(command, "r");
// Ignore output of the command; but consume it
// so we don't get an error when closing the pipe.
char buffer[1024];
while (!feof(pipe) && !ferror(pipe)) {
if (fgets(buffer, sizeof(buffer), pipe) == NULL)
break;
// printf("--> %s", buffer); // Uncomment for debugging
}
// Get the exit code from the pipe; non-zero is an error:
int exitCode = WEXITSTATUS(pclose(pipe));
if (exitCode != 0) {
perror("Unable to execute command:");
printf(" command: %s\n", command);
printf(" exit code: %d\n", exitCode);
}}

void setTrigger (char *LED)
{
FILE *pLed_triggerFile = fopen(LED, "w");
if (pLed_triggerFile == NULL) {
printf("ERROR OPENING %s.", LED);
exit(1);
}
int charWritten = fprintf(pLed_triggerFile, "none");
if (charWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLed_triggerFile );
}


void turnOffLeds (char *LED)
{
FILE *pLed_brightnessFile = fopen(LED, "w");
if (pLed_brightnessFile == NULL) {
printf("ERROR OPENING %s.", LED);
exit(1);
}
int charWritten = fprintf(pLed_brightnessFile, "0");
if (charWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLed_brightnessFile );
}

void turnOnLeds (char *LED)
{
FILE *pLed_brightnessFile = fopen(LED, "w");
if (pLed_brightnessFile == NULL) {
printf("ERROR OPENING %s.", LED);
exit(1);
}
int charWritten = fprintf(pLed_brightnessFile, "1");
if (charWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLed_brightnessFile );
}

static long long getTimeInMs(void)
{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

int main(){

    runCommand("config-pin p8.43 gpio");

    printf("Hello embedded world, from Aneet!\n");
    printf("Press the USER button to start playing!\n");

    setTrigger(Led0_trigger);
    setTrigger(Led1_trigger);
    setTrigger(Led2_trigger);
    setTrigger(Led3_trigger);

    long long bestTime = 100000;

    setTrigger(Led0_trigger);
    turnOnLeds(Led0_brightness);

    while(1) {
        turnOffLeds(Led0_brightness);
        turnOffLeds(Led1_brightness);
        turnOffLeds(Led2_brightness);
        turnOffLeds(Led3_brightness);

        /*while(readFromFileToScreen(userButton) == 0)
        {
            printf("To start the game, let go off the User button \n");
            sleepForMs(1000);
        }*/

        turnOnLeds(Led0_brightness);
         
         printf("When LED3 lights up, press the USER button!\n");
         sleepForMs(3000);

          if(readFromFileToScreen(userButton) == 0)
          {
            turnOnLeds(Led0_brightness);
            turnOnLeds(Led1_brightness);
            turnOnLeds(Led2_brightness);
            turnOnLeds(Led3_brightness);  
            printf("user is cheating\n");
            printf("Your reaction time was 5000ms\n");

          }
          else if(readFromFileToScreen(userButton) == 1) {
            turnOnLeds(Led3_brightness);
            //long long bestTime = 5000;
            //long long currentTime = 0;
            long long startTime = getTimeInMs();
            

            while (readFromFileToScreen(userButton) == 1) {
                long long newEndTime = getTimeInMs();
    
                if((newEndTime - startTime) > 5000) {
                    printf("That's too slow, exiting the game :(\n");
                    sleepForMs(3000);
                }
                else if(readFromFileToScreen(userButton) == 0) {
                     long long endTime = getTimeInMs();
                     long long totalTime = endTime - startTime;
                     long long currentTime = totalTime;
                    turnOnLeds(Led0_brightness);
                    turnOnLeds(Led1_brightness);
                    turnOnLeds(Led2_brightness);
                    turnOnLeds(Led3_brightness);  

                    printf("Your reaction time was %lld", bestTime);
                    printf(" ms.\n");

                     if (bestTime > currentTime) {
                        printf("New best time!\n");
                        bestTime = currentTime;
                    
                    }
                    else{
                        printf("best time so far in game is %lld \n", bestTime);
                    }
                }
            }
          }
        
    }
    
    return 0;
}





