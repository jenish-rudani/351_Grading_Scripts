
#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include<string.h>

#define trigger0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define trigger1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define trigger2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define trigger3 "/sys/class/leds/beaglebone:green:usr3/trigger"

#define bright0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define bright1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define bright2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define bright3 "/sys/class/leds/beaglebone:green:usr3/brightness"

#define value "/sys/class/gpio/gpio72/value"

void turnOff(char *pathName)
{
    FILE *LedBrightFile = fopen(pathName, "w");
    if (LedBrightFile == NULL) 
    {
        printf("ERROR OPENING %s.", pathName);
        exit(1);
    }
   
    int charWrittenBright = fprintf(LedBrightFile, "0");
    if (charWrittenBright <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }

    fclose(LedBrightFile);
    //printf("executed bright \n");
}
void turnOn(char *pathName)
{
    FILE *LedBrightFile = fopen(pathName, "w");
    if (LedBrightFile == NULL) 
    {
        printf("ERROR OPENING %s.", pathName);
        exit(1);
    }

    int charWrittenBright = fprintf(LedBrightFile, "1");
    if (charWrittenBright <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }

    fclose(LedBrightFile);
    //printf("executed bright \n");
}

void triggerNone(char *pathName)
{
    FILE *LedTriggerFile = fopen(pathName, "w");
    if (LedTriggerFile == NULL) 
    {
        printf("ERROR OPENING %s.", bright0);
        exit(1);
    }
    
    int charWrittenTrigger = fprintf(LedTriggerFile, "none");
    if (charWrittenTrigger <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }

    fclose(LedTriggerFile);
    //printf("executed bright \n");
}

void startMessage()//intro message that can be modified
{
    printf("Hello embedded world, from Jerome!\n\n");
    printf("When the LED 3 Lights up, Press the USER button!\n");
}

void allOff()//turn all LEDS off
{
    turnOff(bright0);
    turnOff(bright1);
    turnOff(bright2);
    turnOff(bright3);
}
void allTriggerNone()//turn all triggers to none
{
    triggerNone(trigger0);
    triggerNone(trigger1);
    triggerNone(trigger2);
    triggerNone(trigger3);
}
void allOn()//turn all LEDS on
{
    turnOn(bright0);
    turnOn(bright1);
    turnOn(bright2);
    turnOn(bright3);
}

static long long getTimeInMs(void) ///getTime source code provided in "Assignment 1" -Professor Brian 
{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}

void sleepForMs(long long delayInMs)///delay time source code provided in "Assignment 1" -Professor Brian 
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;

long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;

struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

int randDelay(int delay)// //find a random time between int delay and 500 ms
{ 
    int upper_bound = delay;//3000 ms -> 3 sec
    int lower_bound = 500;//500 ms ->.5sec
    delay = (rand() % (upper_bound - lower_bound +1))+lower_bound;
    // printf("%d is the delay generated in ms \n",delay);    /used for testing
    return delay;
}

void gameComplete() // make LEDS flicker when game finishes -> turns off all LEDs and sets all their triggers to NONE
{   
    sleepForMs(40);
    allOff();
    sleepForMs(40);
    allOn();
    sleepForMs(40);
    allOff();
    sleepForMs(40);
    allOn();
    sleepForMs(40);
    allOff();
    sleepForMs(40);
    allOn();
    sleepForMs(40);
    allOff();
    allTriggerNone();
    printf("No input within 5000 ms ; quitting!\n");
}

int main(){

    FILE *wFile;
    wFile=fopen(value, "w+");
        if (wFile == NULL) {
            printf("ERROR: Unable to open file (%s) for write\n", value);
            exit(-1);
        }

    //////////////////variables 
    const int MAX_LENGTH = 4;
    char buff[MAX_LENGTH];
    int valuecheck=1; 
    
    srand(time(NULL));

    long long best_time=0;
    long long current_time;
    long long Upper;
    long long lower;

    
    startMessage();//deploy our hello world starting message
    allOff(); //fresh start -turn off all LEDS

    while(1){   //start of nested while loop
        
        //sleepForMs(500); - loops after the button press so I set a waiting period of .5 seconds, however i moved this to when the button actually gets pressed further down the code.
        turnOn(bright0);//turn on only LED0
        sleepForMs(randDelay(3000)); //wait a random amount of time between 3000 ms to 500 ms, lower bound can be changed in function

        wFile=fopen(value, "w+"); //write , detects if the button is pressed before the LED 3 turns on
        if (wFile == NULL) {
            printf("ERROR: Unable to open file (%s) for write\n", value);
            exit(-1);
        }
        fgets(buff,MAX_LENGTH,wFile);

        if((valuecheck=strncmp(buff,"0",1))==0)// display reaction time = 5000 ms because button was pressed too early
        {
            printf("Your reaction time was  %i ms; your Best time is %lli\n",5000,best_time);
            goto skip;//since we already have a time of 5000 ms for this attempt, skip to the end and start a new attempt.
        }

        // GAME STARTS//
        turnOn(bright3); 
        lower = getTimeInMs(); // store time for game START.
        while(1) //loops for keypress
        {   
            wFile=fopen(value, "w+"); 
            if (wFile == NULL) {
                printf("ERROR: Unable to open file (%s) for write\n", value);
                exit(-1);
            }
            fgets(buff,MAX_LENGTH,wFile);

            long long tracker = getTimeInMs();
            long long elapsedTime = tracker-lower ; //calculates elapse time used to check for game completion

            if (elapsedTime>5000) 
            {
                gameComplete();
                exit(1);//exit program - all LEDS of all LEDS trigger set to none
            }

            if((valuecheck=strncmp(buff,"0",1))==0){//if we detect buttonpress
                Upper = getTimeInMs();// store time for game END
                current_time = Upper-lower ;

                    //special messages, for uniquie times
                    if(best_time ==0){ //first attempt, best_time = 0 therefore it is our first try , should set current_time to best time
                        best_time = current_time;
                        printf("New best time!\n");
                    }
                    else if(current_time == best_time){ // best time = current time
                        printf("You matched your best time!\n");
                    }
                    else if(current_time < best_time){// got a new best
                        best_time = current_time;
                        printf("New best time!\n");
                    }
                
                printf("Your reaction time was  %lli ms; your Best time is %lli\n",current_time,best_time); //default display 
                allOn(); //light up all LEDs
                sleepForMs(500);// give a chance for user to wait before going to the next attempt.
                break;// break out of this attempt loop, go back to a fresh attempt -> only LED0 is on -> sleepForMS(randDelay(3000))
            }
            fclose(wFile);
        }
        skip:
        allOff();
    }
    return 0;

}