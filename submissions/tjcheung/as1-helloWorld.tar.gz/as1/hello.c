#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
//Definitions
#define LED0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define BUTTON "/sys/class/gpio/gpio72/value"
#define CONFIG_USER "config-pin p8.43 gpio"
#define USER_INPUT "echo in > /sys/class/gpio/gpio72/direction"

static void runCommand(char* command);


static long long getTimeInMs();
static void sleepForMs(long long delayInMs);

int readFile(char *fileName);
void turnOn(char *led);
void turnOff(char *led);
void turnOnAll();
void turnOffAll();


int main() {
    //3.1
    printf("Hello embedded world, from Tim! \n");


    runCommand(CONFIG_USER); //configures button
    runCommand(USER_INPUT); //sets button as input
    //3.2

    long long reactionTime, randomTime;
    long long bestTime = 5000;
    
    printf("\nWhen the LED3 lights up, press the button!\n");

    while(1){

        turnOffAll();
        //Button - 1 = Unpressed | Button - 0 = Pressed
        //While button is pressed
        while(!readFile(BUTTON)) {
            sleepForMs(25);
        }

        turnOn(LED0);

        randomTime = (rand()% 6 + 1) * 500;
        sleepForMs(randomTime);

        if(!readFile(BUTTON)) {
            reactionTime = 5000;
        }

        long long elapsedTime = 0;
        while(readFile(BUTTON)) {
            turnOn(LED3);
            long long startTime = getTimeInMs();

            while(elapsedTime <= 5000) {
                elapsedTime = getTimeInMs() - startTime;
                if(elapsedTime > 5000) {
                    printf("No response within 5000ms. Exiting...\n");
                    exit(1);
                }
                if(!readFile(BUTTON)) {
                    reactionTime = elapsedTime;
                    break;
                }
            }
            
        }
        turnOnAll();

        if(reactionTime < bestTime) {
            printf("New best time!\n");
            bestTime = reactionTime;
        }

        printf("Reaction time: %4lld ms | ", reactionTime);

        printf("Best time: %4lld ms\n", bestTime);
        printf("\n");
        
    }

    return 0;
}

//To run a Linux command from in your C program
static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
    break;
    // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
    perror("Unable to execute command:");
    printf(" command: %s\n", command);
    printf(" exit code: %d\n", exitCode);
    }
}

//Wait a number of milliseconds
static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

//Get current time
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

//Read
int readFile(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
    printf("ERROR: Unable to open file (%s) for read\n", fileName);
    exit(-1);
    }
    // Read string (line)
    int value;
    fscanf(pFile, "%d", &value);
    // Close
    fclose(pFile);
    return value;
}

//Turn on LED
void turnOn(char *led) {
    FILE *pLedBrightnessFile = fopen(led, "w");
    if (pLedBrightnessFile == NULL) {
    printf("ERROR OPENING %s.", led);
    exit(1);
    }
    int charWritten = fprintf(pLedBrightnessFile, "1");
    if (charWritten <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }
    fclose(pLedBrightnessFile);
}
//Turn off LED
void turnOff(char *led) {
    FILE *pLedBrightnessFile = fopen(led, "w");
    if (pLedBrightnessFile == NULL) {
    printf("ERROR OPENING %s.", led);
    exit(1);
    }
    int charWritten = fprintf(pLedBrightnessFile, "0");
    if (charWritten <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
    }
    fclose(pLedBrightnessFile);
}

void turnOnAll() {
    turnOn(LED0);
    turnOn(LED1);
    turnOn(LED2);
    turnOn(LED3);
}
void turnOffAll() {
    turnOff(LED0);
    turnOff(LED1);
    turnOff(LED2);
    turnOff(LED3);
} 
