
#ifndef GENERALTOOLS_H
#define GENERALTOOLS_H

static const char LED_BRIGHTNESS_ON[] = "1";
static const char LED_BRIGHTNESS_OFF[] = "0";

static const char LED0_TRIGGER_DEFAULT[] = "heartbeat";
static const char LED1_TRIGGER_DEFAULT[] = "mmc0";
static const char LED2_TRIGGER_DEFAULT[] = "cpu0";
static const char LED3_TRIGGER_DEFAULT[] = "mmc1";

// getTimeInMs was copied from Assignment Document
long long getTimeInMs(void);

// sleepForMs was copied from Assignment Document
void sleepForMs(long long delayInMs);

// Attempts to open file fileName and checks if it succeeded.
// Exits with exitcode 1 if it fails.
FILE* openFileWithCheck(const char* fileName, const char* accessType);


void configurePinForGPIO(const char* pin);


int readGPIOValue(int gpioNum);


void setLEDAttribute(const int LEDNum, const char* attribute, const char* value);


#endif