
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#include "generalTools.h"

#include "timeGame.h"

// USER button Constants
// P8/P9 Pin: 8 #43
static const char USER_BUTTON_PIN[] = "p8.43";
// Linux GPIO Number: 72
static const int USER_BUTTON_GPIO_NUM = 72;
static const int USER_BUTTON_VALUE_PRESSED = 0;


static const int GAME_TIMEOUT_MS = 5000;    

static const int MIN_RAND_WAIT_TIME_MS = 500;
static const int MAX_RAND_WAIT_TIME_MS = 3000;


static void exitGameSequence()
{
    

    // Reset LEDs to off and all triggers to defaults
    setLEDAttribute(0, "brightness", LED_BRIGHTNESS_OFF);
    setLEDAttribute(1, "brightness", LED_BRIGHTNESS_OFF);
    setLEDAttribute(2, "brightness", LED_BRIGHTNESS_OFF);
    setLEDAttribute(3, "brightness", LED_BRIGHTNESS_OFF);

    setLEDAttribute(0, "trigger", LED0_TRIGGER_DEFAULT);
    setLEDAttribute(1, "trigger", LED1_TRIGGER_DEFAULT);
    setLEDAttribute(2, "trigger", LED2_TRIGGER_DEFAULT);
    setLEDAttribute(3, "trigger", LED3_TRIGGER_DEFAULT);

    printf("No input within %d ms: Quitting\n", GAME_TIMEOUT_MS);
    exit(0);
}


static void mainGameLoop(void)
{
    int fastestTimeMs = GAME_TIMEOUT_MS;

    // Reset all LED triggers to none
    setLEDAttribute(0, "trigger", "none");
    setLEDAttribute(1, "trigger", "none");
    setLEDAttribute(2, "trigger", "none");
    setLEDAttribute(3, "trigger", "none");


    // Game loop
    while(true) {

        // Wait while User button is pressed
        while(readGPIOValue(USER_BUTTON_GPIO_NUM) == USER_BUTTON_VALUE_PRESSED);

        // Turn on LED0 and all others off
        setLEDAttribute(0, "brightness", LED_BRIGHTNESS_ON);
        setLEDAttribute(1, "brightness", LED_BRIGHTNESS_OFF);
        setLEDAttribute(2, "brightness", LED_BRIGHTNESS_OFF);
        setLEDAttribute(3, "brightness", LED_BRIGHTNESS_OFF);

        // Wait random time from 0.5 to 3 seconds
        int randWaitTimeMs = rand() % (MAX_RAND_WAIT_TIME_MS - MIN_RAND_WAIT_TIME_MS + 1) + MIN_RAND_WAIT_TIME_MS;
        sleepForMs(randWaitTimeMs);

        // Start Timer
        long long startTimeMs = getTimeInMs();

        long long elapsedTimeMs;

        bool userButtonWasPressed = (readGPIOValue(USER_BUTTON_GPIO_NUM) == USER_BUTTON_VALUE_PRESSED);

        if(userButtonWasPressed) {
            elapsedTimeMs = GAME_TIMEOUT_MS;
        }

        // Turn on LED3
        setLEDAttribute(3, "brightness", LED_BRIGHTNESS_ON);

        // Polling loop (waiting for button press)
        while(!userButtonWasPressed) {
            long long endTimeMs = getTimeInMs();

            elapsedTimeMs = endTimeMs - startTimeMs;

            // Check for timeout
            if(elapsedTimeMs >= GAME_TIMEOUT_MS) {
                exitGameSequence();
            }

            // Check if USER button was pressed
            userButtonWasPressed = (readGPIOValue(USER_BUTTON_GPIO_NUM) == USER_BUTTON_VALUE_PRESSED);
        }

        // Compare elapsed time with fastest time
        if(elapsedTimeMs < fastestTimeMs) {
            fastestTimeMs = (int)elapsedTimeMs;
            printf("New Best Time!\n");
        }
                
        // Light up all LEDS (0 and 3 are already on)
        setLEDAttribute(1, "brightness", LED_BRIGHTNESS_ON);
        setLEDAttribute(2, "brightness", LED_BRIGHTNESS_ON);

        // Print summary
        // Changing elapsedTimeMs into string from lld to keep the the summary constant length
        const int MAX_NUM_CHARS = 12;
        char elapsedTimeMsString[MAX_NUM_CHARS];
        sprintf(elapsedTimeMsString, "%lld", elapsedTimeMs);
        printf("Your reaction time: %s ms. \tYour fastest time: \t%d ms.\n", elapsedTimeMsString, fastestTimeMs);
    }
}


void playTimeGame(void)
{
    printf("\nWhen LED3 lights up, press the USER button!\n");

    configurePinForGPIO(USER_BUTTON_PIN);

    mainGameLoop();
}