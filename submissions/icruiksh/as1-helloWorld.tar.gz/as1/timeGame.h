
#ifndef TIMEGAME_H
#define TIMEGAME_H

void playTimeGame(void);

#endif