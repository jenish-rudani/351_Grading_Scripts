
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "generalTools.h"

// getTimeInMs was copied from Assignment Document
long long getTimeInMs(void) 
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

// sleepForMs was copied from Assignment Document
void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000000;
    const long long NS_PER_S = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_S;
    int nanoseconds = delayNs % NS_PER_S;
    
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, NULL);
}


FILE* openFileWithCheck(const char* fileName, const char* accessType)
{

    if(fileName == NULL || accessType == NULL) {
        printf("ERROR: NULL arguments in openFileWithCheck()");
        exit(1);
    }

    FILE* pFile = fopen(fileName, accessType);

    if(pFile == NULL) {
        printf("ERROR: Unable to open file %s\n", fileName);
        exit(1);
    }

    return pFile;
}


void configurePinForGPIO(const char* pin)
{
    const int COMMAND_MAX_SIZE = 50;
    char configPinCommand[COMMAND_MAX_SIZE];

    // Configure USER button for gpio
    
    sprintf(configPinCommand, "config-pin %s gpio > /dev/null", pin);
    system(configPinCommand);
}


int readGPIOValue(int gpioNum)
{
    const int GPIO_FILE_NAME_MAX_SIZE = 50;
    char gpioValueFileName[GPIO_FILE_NAME_MAX_SIZE];
    sprintf(gpioValueFileName, "/sys/class/gpio/gpio%d/value", gpioNum);

    FILE* gpioValueFile = openFileWithCheck(gpioValueFileName, "r");

    const int VAL_BUFFER_MAX_SIZE = 16;
    char valueBuffer[VAL_BUFFER_MAX_SIZE];
    fgets(valueBuffer, VAL_BUFFER_MAX_SIZE, gpioValueFile);

    fclose(gpioValueFile);

    int value = atoi(valueBuffer);

    return value;
}


void setLEDAttribute(const int LEDNum, const char* attribute, const char* value)
{
    if(attribute == NULL || value == NULL) {
        printf("ERROR: NULL arguments in setLEDAttribute() for LED%d", LEDNum);
        exit(1);
    }

    const int LED_FILE_NAME_MAX_SIZE = 50;
    char ledAttFileName[LED_FILE_NAME_MAX_SIZE];
    sprintf(ledAttFileName, "/sys/class/leds/beaglebone:green:usr%d/%s", LEDNum, attribute);

    FILE* ledAttFile = openFileWithCheck(ledAttFileName, "w");

    fprintf(ledAttFile, "%s", value);

    fclose(ledAttFile);
}