
#include <stdio.h>

#include "timeGame.h"

static char helloMessage[] = "\nHello embedded world, from Ian!\n";

int main() {

    printf(helloMessage);
    
    playTimeGame();

    return 0;
}