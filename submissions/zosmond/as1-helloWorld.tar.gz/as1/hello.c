//Zakrye Osmond
//301327952
//Zosmond@sfu.ca
//ENSC 351
//Oct 7th 2022

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <string.h>
#include <unistd.h>

#define DA_TRIGGER_FILE_NAME_HERE "/sys/class/leds/beaglebone:green:usr0/trigger"



char readFromFileToScreen(char *fileName)
{
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
		printf("ERROR: Unable to open file (%s) for read\n", fileName);
		exit(-1);
	}
	// Read string (line)
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	// Close
	fclose(pFile);
	//printf("Read: '%s'\n", buff);
	return buff[0];
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
        + nanoSeconds / 1000000;
    return milliSeconds;
}

static void runCommand(char* command)
{
	 // Execute the shell command (output into pipe)
	 FILE *pipe = popen(command, "r");
	 // Ignore output of the command; but consume it 
	 // so we don't get an error when closing the pipe.
	 char buffer[1024];
	 while (!feof(pipe) && !ferror(pipe)) {
	 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
	 break;
	 //printf("--> %s", buffer); // Uncomment for debugging
	 }
	 // Get the exit code from the pipe; non-zero is an error:
	 int exitCode = WEXITSTATUS(pclose(pipe));
	 if (exitCode != 0) {
		 perror("Unable to execute command:");
		 printf(" command: %s\n", command);
		 printf(" exit code: %d\n", exitCode);
	 }
}




int main(void)
{

	printf("Hello embedded world, from Zak! \n \n");


	//TESTING BUTTON STATE INTERMEDIATES
	char str1[50];
	char str2[50]="0";
	
	//RANDOM SEED
   	time_t t;
	srand((unsigned) time(&t));
	
	long long idlewait;			//THE TIMER FOR WAITING 5 SECONDS
	long long isThree;			//TO MAKE SURE THE BUTTON IS DOWN FOR ATLEAST 3 SECONDS
	long long AutoFive;			//IF THE GAME IS BEGUN AND NO ONE INPUTS 5 SECONDS AFTER LED3
	long long RandTime;			//TIME BETWEEN GAME START AND LED3
	long long milliseconds = 5000;		//TIMEOUT TIME (5 seconds)
	long long foreverseconds = 11000;	//TO MAKE SURE YOU CANT IDLE WHILE WAITING FOR BUTTON
	long long milliseconds2 = 3000;		//THE 3 SECOND BUTTON PRESS 
	long long randStop = 1000;		//THE RANDOM TIME BETWEEN START AND END LED3
	long long TimerStart;			//THE START TIMER ONCE GAME START
	long long TimerEnd;			//THE END TIMER ONCE THE BUTTON IS PRESSED AFTER LED3
	long long YourTime;			//DIFFERENCE BETWEEN START and END
	long long BestTime=5000;		//THE BEST TIME (autoset to 5s)
	
	bool running = true;			//CONSTANTLY RUN THE PROGRAM (true is running)
	
	int game=0;				//0 BUTTON HAS NOT BEEN HELD FOR 3 | 1 GAME START LED0 ON
	int Firstgame=0;			//IF ITS THE FIRST GAME PRINT INITIAL MESSAGE WHEN GAME START
	int reset=0;				//RESET GAME WHILE ACTIVE IF NEEDED (touching button before LED3)
	
	int charWritten = 0;			//AMOUNT OF CHARACTERS WRITTEN WHEN fprintf
	
	idlewait = getTimeInMs() + milliseconds;
	
	runCommand("config-pin p8.43 gpio");
	
	FILE *pLedTriggerFile;
	   
	   
	//ON START LED ON - WAIT 3s - LED OFF - WAIT 1s
	
	FILE *pLedBrightnessFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
	charWritten = fprintf(pLedBrightnessFile, "0");
	fclose(pLedBrightnessFile);
	FILE *pLedBrightnessFile1 = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
	charWritten = fprintf(pLedBrightnessFile1, "0");
	fclose(pLedBrightnessFile1);
	FILE *pLedBrightnessFile2 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
	charWritten = fprintf(pLedBrightnessFile2, "0");
	fclose(pLedBrightnessFile2);
	FILE *pLedBrightnessFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
	charWritten = fprintf(pLedBrightnessFile3, "0");
	fclose(pLedBrightnessFile3);
	sleep(1);
	
	//PROGRAM START
	while (running == true)
	{
		
		isThree = getTimeInMs() + milliseconds2;				
		
		
		str1[0]=readFromFileToScreen("/sys/class/gpio/gpio72/value");		//CONSTANT READ OF BUTTON PRESS
		
		while(str1[0]==str2[0] && game==0)
		{
			idlewait = getTimeInMs() + milliseconds;
			str1[0]=readFromFileToScreen("/sys/class/gpio/gpio72/value");
			
				
			if (getTimeInMs() > isThree) //ONCE HELD DOWN FOR 3 SECONDS
			{
				if(Firstgame==0)
				{
				    	printf("When LED3 lights up, press the USER button!\n");
				    	Firstgame=1;
			    	}
			    	pLedTriggerFile = fopen(DA_TRIGGER_FILE_NAME_HERE, "w");
				charWritten = fprintf(pLedTriggerFile, "none");
				//printf("CHAR%d\n", charWritten);
				if (charWritten <= 0) { 
					printf("ERROR WRITING DATA");
					exit(1);
				}
				
				fclose(pLedTriggerFile);
			    	
			    	pLedBrightnessFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile, "1");
				//printf("CHAR%d\n", charWritten);
				if (charWritten <= 0) { 
					printf("ERROR WRITING DATA");
					exit(1);
				}
				
				fclose(pLedTriggerFile);
				
			    	idlewait = getTimeInMs() + foreverseconds;
			    	
			    	 
			    	sleep(1);
			    	randStop = ((rand() % 3)+1)*1000;
			    	RandTime = getTimeInMs() + randStop;
			    	game=1;
			}
        	} 
		
		AutoFive = getTimeInMs() + milliseconds;
		str1[0]=readFromFileToScreen("/sys/class/gpio/gpio72/value");
		
		//PRESS TOO EARLY/CHEATING
		if(getTimeInMs() < RandTime && str1[0]==str2[0] && game==1)
		{
        		YourTime=5000;
        		printf("Your recation time was %lld ms; best so far in game is %lld ms!\n",YourTime, BestTime);
			sleep(1);
			reset=1;
			    
        	}
        	
        	//START TIMER
        	if(game==1)
        	{
        		TimerStart = getTimeInMs();
        	}
        	while(getTimeInMs() > RandTime && game==1) 
        	{
        		
        		
       			pLedBrightnessFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
			charWritten = fprintf(pLedBrightnessFile, "1");
			idlewait = getTimeInMs() + milliseconds; //FIX THIS
      			fclose(pLedBrightnessFile3);
      			
      			str1[0]=readFromFileToScreen("/sys/class/gpio/gpio72/value");
      			if(getTimeInMs() > AutoFive) //IF DONT TOUCH AFTER 5 SECONDS
			{
			 	printf("No input within 5000ms; quitting!\n");
				running = false;
				game=0;
				reset=1;
				sleep(2);
			    
			}
      			if(str1[0]==str2[0] || reset==1)
      			{
      				//LEDS ALL ON - WAIT 3s - LED OFF
	      			TimerEnd = getTimeInMs();
				pLedBrightnessFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile, "1");
				fclose(pLedBrightnessFile);
				pLedBrightnessFile1 = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile1, "1");
				fclose(pLedBrightnessFile1);
				pLedBrightnessFile2 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile2, "1");
				fclose(pLedBrightnessFile2);
				pLedBrightnessFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile3, "1");
				fclose(pLedBrightnessFile3);
				sleep(3);
				pLedBrightnessFile = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile, "0");
				fclose(pLedBrightnessFile);
				pLedBrightnessFile1 = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile1, "0");
				fclose(pLedBrightnessFile1);
				pLedBrightnessFile2 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile2, "0");
				fclose(pLedBrightnessFile2);
				pLedBrightnessFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
				charWritten = fprintf(pLedBrightnessFile3, "0");
				fclose(pLedBrightnessFile3);
				
				//PRINT MESSAGES
			   	if(reset==0)
      				{
	      				YourTime=TimerEnd-TimerStart;
	      				if(YourTime<BestTime){
		      				printf("New Best Time!\n");
		      				BestTime=YourTime;
	      				}
	      				
	      				printf("Your recation time was %lld ms; best so far in game is %lld ms!\n", YourTime, BestTime);
	      				sleep(1);
      				}
      				//GAME OVER AND RESET
      				reset=0;
			   	game=0;
			   	idlewait = getTimeInMs() + milliseconds;
      			}
      		}
        
	
	
        	if (getTimeInMs() > idlewait) //IF NO ONE TOUCHES BUTTON within 5 AFTER 
        	{
            		printf("No input within 5000ms; quitting!\n");
            		running = false;
        	}
	
	
	
    	}

	return 0;
}

