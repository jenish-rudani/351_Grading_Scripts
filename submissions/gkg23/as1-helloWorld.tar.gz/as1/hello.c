#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//function declarations
static void turnLED0Trigger(void);
static void turnLED0On(void);
static void turnLED1Trigger(void);
static void turnLED1On(void);
static void turnLED2Trigger(void);
static void turnLED2On(void);
static void turnLED3Trigger(void);
static void turnLED3On(void);
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
static void runCommand(char* command);
static void initilizeUserPin(void);
static char isUserButtonPressed(void);
static void turnLED0Off(void);
static void turnLED1Off(void);
static void turnLED2Off(void);
static void turnLED3Off(void);

//LEDS trigger definitions
#define LED0File "/sys/class/leds/beaglebone:green:usr0"
#define LED1File "/sys/class/leds/beaglebone:green:usr1"
#define LED2File "/sys/class/leds/beaglebone:green:usr2"
#define LED3File "/sys/class/leds/beaglebone:green:usr3"

int main(int argc, char* args[])
{

  //Initilizing User button and LEDS for use
  initilizeUserPin();
  turnLED0Trigger();
  turnLED1Trigger();
  turnLED2Trigger();
  turnLED3Trigger();
  turnLED0Off();
  turnLED1Off();
  turnLED2Off();
  turnLED3Off();

  int bestTime=100000;
  //Greeting message
  printf("Hello embedded world, from Gavin!\n");
  printf("When LED3 lights up, press the USER button!\n\n");

  while(1)
  {

    //Turn LEDs off at the start of each round
    turnLED0Off();
    turnLED1Off();
    turnLED2Off();
    turnLED3Off();

    //1. wait while user presses button
    while(isUserButtonPressed()=='0'){
      //empty while loop to wait until button is let go
    }

    //2. Turn on LED 0 only
    turnLED0On();

    //Wait a random time between 0.5-3seconds
    double randomNum =((double)rand()) / RAND_MAX;
    double delayRange = (3-0.5)*randomNum;
    double finalDelayInS = 0.5 + delayRange;
    double finalDelayInMs = finalDelayInS*1000;
    sleepForMs(finalDelayInMs);
  
    //Light up LED 3 and start the timer
    turnLED3On();
    long long startTime = getTimeInMs();

    //If user doesn't press a button within 5000ms
    //print an exit statement and quit the program
    while(isUserButtonPressed()=='1'){
      long long currentTime = getTimeInMs();
      long long timeSinceStart=currentTime-startTime;
      if(timeSinceStart>5000){
        printf("No input within 5000ms; quitting!\n");
        fflush(stdout);
        exit(1);
      }
    }

    //If buttons is pressed and the time has not gone over 5000 seconds
    //Output reaction time and compare against best time
    if(isUserButtonPressed()=='0' && (getTimeInMs()-startTime) < 5000 )
    {
      turnLED0On();
      turnLED1On();
      turnLED2On();
      turnLED3On();
      long long pressTime = getTimeInMs();
      long long longReactionTime = pressTime - startTime;
      int reactionTime = (int)longReactionTime;
      //handling if button is being held before game started
      if(reactionTime==1 || reactionTime==0){
        if(5000<bestTime)
        {
          bestTime=5000;
        }
        printf("Your response time was 5000ms; best so far is %dms\n",bestTime);
        fflush(stdout);
      }else{
        if(reactionTime<bestTime)
        {
          printf("New best time!\n");
          fflush(stdout);
          bestTime=reactionTime;
        }
        printf("Your reaction time was %dms; best so far is %dms\n",reactionTime,bestTime);
        fflush(stdout);
      }
    }
  }
}

//LED 0 trigger function
static void turnLED0Trigger(void){
  FILE *pLEDTriggerFile = fopen(LED0File"/trigger","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED0File"/trigger");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"none");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(pLEDTriggerFile);
}

//LED 0 turn On function
static void turnLED0On(void){
  FILE *pLEDTriggerFile = fopen(LED0File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED0File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"1");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(pLEDTriggerFile);
}

//LED 0 turn off function
static void turnLED0Off(void){
  FILE *pLEDTriggerFile = fopen(LED0File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED0File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"0");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}

//LED 1 trigger function
static void turnLED1Trigger(void){
  FILE *pLEDTriggerFile = fopen(LED1File"/trigger","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED1File"/trigger");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"none");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(pLEDTriggerFile);
}

//LED 1 on function
static void turnLED1On(void){
  FILE *pLEDTriggerFile = fopen(LED1File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED1File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"1");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}

//LED 1 off function
static void turnLED1Off(void){
  FILE *pLEDTriggerFile = fopen(LED1File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED1File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"0");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}

//LED 2 trigger function
static void turnLED2Trigger(void){
  FILE *pLEDTriggerFile = fopen(LED2File"/trigger","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED2File"/trigger");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"none");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(pLEDTriggerFile);
}

//LED 2 turn on function
static void turnLED2On(void){
  FILE *pLEDTriggerFile = fopen(LED2File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED2File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"1");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}

//LED 2 off function
static void turnLED2Off(void){
  FILE *pLEDTriggerFile = fopen(LED2File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED2File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"0");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}

//LED 3 trigger function
static void turnLED3Trigger(void){
  FILE *pLEDTriggerFile = fopen(LED3File"/trigger","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED3File"/trigger");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"none");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(pLEDTriggerFile);
}

//LED 3 on function
static void turnLED3On(void){
  FILE *pLEDTriggerFile = fopen(LED3File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED3File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"1");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}

//LED 3 off function
static void turnLED3Off(void){
  FILE *pLEDTriggerFile = fopen(LED3File"/brightness","w");
  //check if file open succeeded
  if (pLEDTriggerFile == NULL)
  {
    printf("ERROR OPENING %s",LED3File"/brightness");
    exit(1);
  }
  int charWritten = fprintf(pLEDTriggerFile,"0");
  if (charWritten <= 0)
  {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fflush(pLEDTriggerFile);
  fclose(pLEDTriggerFile);
}
 
//Initilize user button
static void initilizeUserPin(void){
  runCommand("config-pin p8.43 gpio");
  runCommand("cd /sys/class/gpio/gpio72 && echo in > direction");
  //runCommand("echo in > direction");
}

//Checking if button is currently being pressed
//0=pressed 1=not pressed
static char isUserButtonPressed(void){
  FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
  if (pFile == NULL) {
  printf("ERROR: Unable to open file (%s) for read\n", "/sys/class/gpio/gpio72/value");
  exit(-1);
  }
  // Read string (line)
  const int MAX_LENGTH = 1024;
  char buff[MAX_LENGTH];
  fgets(buff, MAX_LENGTH, pFile);
  // Close
  fclose(pFile);
  return(buff[0]);
}

//Instructor given get time function in ms
static long long getTimeInMs(void){
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}

//Instructor given nanosleep function in ms
static void sleepForMs(long long delayInMs){
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}

//Instructor given to run a linux command
static void runCommand(char* command){
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}
