#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdbool.h>

static void initializeLEDs(void);
static void initializeButton(void);
static void setTriggerNone(const char*);
static void turnOnLED(const int);
static void turnOffAllLEDs(void);
static void turnOnAllLEDs(void);
static void setBrightness(const char*,char*);
static void runCommand(char* command);
static void configurePinInput(const char*);
static void sleepForMs(long long);
static long long getTimeInMs(void);
static long long randomNumberInRange(int, int);
static bool userButtonPressed();
static char* readValue(const char*);
static void printRoundSummary(long long,long long);

static const char* LED_0_TRIGGER_PATH = "/sys/class/leds/beaglebone:green:usr0/trigger";
static const char* LED_1_TRIGGER_PATH = "/sys/class/leds/beaglebone:green:usr1/trigger";
static const char* LED_2_TRIGGER_PATH = "/sys/class/leds/beaglebone:green:usr2/trigger";
static const char* LED_3_TRIGGER_PATH = "/sys/class/leds/beaglebone:green:usr3/trigger";
static const char* LED_0_BRIGHTNESS_PATH = "/sys/class/leds/beaglebone:green:usr0/brightness";
static const char* LED_1_BRIGHTNESS_PATH = "/sys/class/leds/beaglebone:green:usr1/brightness";
static const char* LED_2_BRIGHTNESS_PATH = "/sys/class/leds/beaglebone:green:usr2/brightness";
static const char* LED_3_BRIGHTNESS_PATH = "/sys/class/leds/beaglebone:green:usr3/brightness";
static const char* GPIO_72_DIRECTION_PATH = "/sys/class/gpio/gpio72/direction";
static const char* GPIO_72_VALUE_PATH = "/sys/class/gpio/gpio72/value";

int main(void)
{
    printf("Hello embedded world, from Ryan!\n");

    initializeLEDs();
    initializeButton();

    printf("\nWhen LED3 lights up, press the USER button!\n");

    // set to maximum value since we are updating it with the min during the game
    long long bestTime = __LONG_LONG_MAX__;
    while (true) {
        turnOffAllLEDs();
        turnOnLED(0);
        long long waitTime = (long long) randomNumberInRange(500, 3000);
        sleepForMs(waitTime);
        // set to -1 as a flag for when the button is not pressed after 5sm n
        long long responseTime = -1;
        long long timeElapsed;
        if (userButtonPressed()) {
            responseTime = 5000;
            // skips upcoming while loop
            timeElapsed = 5000;
        } else {
            turnOnLED(3);
            timeElapsed = 0;
        }
        long long startTime = getTimeInMs();
        while (timeElapsed < 5000) {
            long long currentTime = getTimeInMs();
            timeElapsed = currentTime - startTime;
            if (userButtonPressed()) {
                 responseTime = timeElapsed;
                 break;
            }
        }
        if (timeElapsed >= 5000 && responseTime == -1) {
            printf("No input within 5000ms; quitting!\n");
            break;
        } else if (responseTime < bestTime) {
            bestTime = responseTime;
            printf("New best time!\n");
        }
        turnOnAllLEDs();
        printRoundSummary(responseTime, bestTime);
    }
    turnOffAllLEDs();
    return 0;
}

static void initializeLEDs(void) {
    setTriggerNone(LED_0_TRIGGER_PATH);
    setTriggerNone(LED_1_TRIGGER_PATH);
    setTriggerNone(LED_2_TRIGGER_PATH);
    setTriggerNone(LED_3_TRIGGER_PATH);
}

static void setTriggerNone(const char* triggerFilePath) {
    // code copied from LEDGuide on course website
    FILE* pLedTriggerFile = fopen(triggerFilePath, "w");
    if (pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s", triggerFilePath);
        exit(1);
    }
    int charWritten = fprintf(pLedTriggerFile, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedTriggerFile);
}

static void turnOffAllLEDs(void) {
    setBrightness(LED_0_BRIGHTNESS_PATH, "0");
    setBrightness(LED_1_BRIGHTNESS_PATH, "0");
    setBrightness(LED_2_BRIGHTNESS_PATH, "0");
    setBrightness(LED_3_BRIGHTNESS_PATH, "0");
}

static void turnOnAllLEDs(void) {
    setBrightness(LED_0_BRIGHTNESS_PATH, "1");
    setBrightness(LED_1_BRIGHTNESS_PATH, "1");
    setBrightness(LED_2_BRIGHTNESS_PATH, "1");
    setBrightness(LED_3_BRIGHTNESS_PATH, "1");
}

static void setBrightness(const char* brightnessFilePath, char* brightnessValue) {
    // code copied from LEDGuide on course website
    FILE* pLedBrightnessFile = fopen(brightnessFilePath, "w");
    if (pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s", brightnessFilePath);
    }
    int charWritten = fprintf(pLedBrightnessFile, brightnessValue);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
    }
    fclose(pLedBrightnessFile);
}

static void runCommand(char* command)
/* function copied from Assignment1 instructions */
{
    // Execute the shell command (output into pipe)
    FILE* pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
    // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

static void initializeButton(void) 
{
    runCommand("config-pin p8.43 gpio");
    configurePinInput(GPIO_72_DIRECTION_PATH);
}

static void configurePinInput(const char* directionPath) 
{
    // based on C code example in the GPIOGuide
    FILE* pFile = fopen(directionPath, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open %s\n", directionPath);
        exit(1);
    }

    // Write 'in' to the file to configue the pin for input
    fprintf(pFile, "in");

    fclose(pFile);

    // pin may need up to 300ms before it's ready for use
    sleepForMs(300);

}

static void sleepForMs(long long delayInMs)
/* Function copied from Assignment1 instructions */
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
/* Function copied from Assignment1 instructions */
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void turnOnLED(const int ledNumber)
{
    switch(ledNumber) {
        case 0:
            setBrightness(LED_0_BRIGHTNESS_PATH, "1");
            break;
        case 1:
            setBrightness(LED_1_BRIGHTNESS_PATH, "1");
            break;
        case 2:
            setBrightness(LED_2_BRIGHTNESS_PATH, "1");
            break;
        case 3:
            setBrightness(LED_3_BRIGHTNESS_PATH, "1");
            break;
        default:
            printf("ERROR: LED IDENTIFIER OUT OF RANGE\n");
    }
}

static long long randomNumberInRange(int minValue, int maxValue)
{
    srand(time(NULL));
    //random number between 0 and 1
    double random = (double)rand() / (double)RAND_MAX;
    long long generatedNumber = (random * (maxValue - minValue)) + minValue;
    return generatedNumber;
}

static bool userButtonPressed()
{
    char* pinValue = readValue(GPIO_72_VALUE_PATH);
    // 1 indicates the button is pressed
    if ( strncmp(pinValue, "1", 1) ) {
        free(pinValue);
        return true;
    }
    free(pinValue);
    return false;
}

static char* readValue(const char* gpioValuePath)
/* Function built off read example in GPIOGuide */
{
    FILE *pFile = fopen(gpioValuePath, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", gpioValuePath);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    // return memory allocated string so data does not get overwirtten later
    char* readValue = malloc( (strlen(buff) + 1) * sizeof(char) );
    strcpy(readValue, buff);
    return readValue;
}

static void printRoundSummary(long long responseTime, long long bestTime)
{
    printf("Your reaction time was %4lldms; best so far in game is %4lldms.\n"
            ,responseTime, bestTime);
}