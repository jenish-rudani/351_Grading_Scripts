/*ENSC351 - Assignment 1
Written by Megan Duclos on October 6th 2022
Student ID: mduclos - 301416085*/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(int argc, char* args[]) 
{
    int loop = 1;

    //Initializing timer variables
    long long bestTime = 5000;
    long long currentTime = 5000;
    long long tInit;
    long long tFinal;
    long long getTimeInMs(void);        //return time in ms

    //initialazing button state
    char ButtonState(char *fileName);   //returns 1 if unpresseed, 0 if pressed
    char buttonPressed = '1';           //1 if unpresseed, 0 if pressed

    //LEDs functions
    void TurnLightOff(char *fileName);
    void TurnLightOn(char *fileName);
    

    //Display a hello-world welcome message
    printf("Hello embedded world, from Megan!\n\n");
    printf("When LED3 lights up, press the USER button.\n");

    //Turning off all LEDs
    TurnLightOff("/sys/class/leds/beaglebone:green:usr0/brightness");
    TurnLightOff("/sys/class/leds/beaglebone:green:usr1/brightness");
    TurnLightOff("/sys/class/leds/beaglebone:green:usr2/brightness");
    TurnLightOff("/sys/class/leds/beaglebone:green:usr3/brightness");


    //Updating button state
    buttonPressed = ButtonState("/sys/class/gpio/gpio72/value");
    while (loop == 1){
        //Start Program
        //Wait while user holds down USER button
        while(buttonPressed == '0'){
            buttonPressed = ButtonState("/sys/class/gpio/gpio72/value");
        }

        //Light up LED 0
        TurnLightOff("/sys/class/leds/beaglebone:green:usr1/brightness");
        TurnLightOff("/sys/class/leds/beaglebone:green:usr2/brightness");
        TurnLightOff("/sys/class/leds/beaglebone:green:usr3/brightness");
        TurnLightOn("/sys/class/leds/beaglebone:green:usr0/brightness");

        //Wait 3.0s
        tInit = getTimeInMs();
        tFinal = getTimeInMs();
        while( tFinal - tInit < 3000){
            tFinal = getTimeInMs();
        }

        //Update button state
        buttonPressed = ButtonState("/sys/class/gpio/gpio72/value");

        //If user is pressing the USER button already currentTime = 5000ms
        if(buttonPressed == '0') currentTime = 5000;
        
        else{
            //Light up LED 3 & start timer
            TurnLightOn("/sys/class/leds/beaglebone:green:usr3/brightness");
            tInit = getTimeInMs();
            tFinal = getTimeInMs();
        
            //While timer < 5s and user hasn't pressed button, 
            //update button state & time
            while(buttonPressed == '1' && tFinal-tInit < 5000){
                buttonPressed = ButtonState("/sys/class/gpio/gpio72/value");
                tFinal = getTimeInMs();
            }

            //Exit program if timer is greater than 5
            if (tFinal-tInit >= 5000){
                printf("Exiting program.\n");
                loop = 0;
            }
            
            //When user presses USER button, stop timer
            currentTime = tFinal-tInit;

            //Update best time
            if(currentTime < bestTime){
                bestTime = currentTime;
                printf("New Best Time!\n");
            }   
        }
        
        //Light Up all LEDs
        TurnLightOn("/sys/class/leds/beaglebone:green:usr0/brightness");
        TurnLightOn("/sys/class/leds/beaglebone:green:usr1/brightness");
        TurnLightOn("/sys/class/leds/beaglebone:green:usr2/brightness");
        TurnLightOn("/sys/class/leds/beaglebone:green:usr3/brightness");
        
        //Display summary
        printf("Current response time: %lld ms\n", currentTime);
        printf("Best response time: %lld ms\n", bestTime);
    }

    return 0;
}

char ButtonState(char *fileName){
    //Open file for reading purposes
    FILE *pFile = fopen(fileName, "r");
        if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }

    //Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    
    //Close file
    fclose(pFile);

    //Return content of file
    return *buff;
}

void TurnLightOff(char *fileName){
    //Open file for writing purposes
    FILE *BrightnessFile = fopen(fileName, "w");
    if (BrightnessFile == NULL) {
        printf("ERROR OPENING %s.", fileName);
        exit(1);
    }
    
    //Overwrite the file to turn off the LED
    int charWritten = fprintf(BrightnessFile, "0");
    if (charWritten <= 0) { 
        printf("ERROR WRITING DATA");
        exit(1);
    }

    //Close file
    fclose(BrightnessFile);
}

void TurnLightOn(char *fileName){
    //Open file for writing purposes
    FILE *BrightnessFile = fopen(fileName, "w");
    if (BrightnessFile == NULL) {
        printf("ERROR OPENING %s.", fileName);
        exit(1);
    }
    
    //Overwrite the file to turn off the LED
    int charWritten = fprintf(BrightnessFile, "1");
    if (charWritten <= 0) { 
        printf("ERROR WRITING DATA");
        exit(1);
    }

    //Close file
    fclose(BrightnessFile);
}

long long getTimeInMs(void) {
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}