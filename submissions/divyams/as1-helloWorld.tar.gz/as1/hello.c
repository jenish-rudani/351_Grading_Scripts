// Divyam Sharma
// 301372345
// ENSC351, Assignment 1
// Purpose of File: This program is a simple reaction test game that uses the LEDs and the USER Button on the BeagleBone Green Board.

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TRIGGER_BBG_LED0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define TRIGGER_BBG_LED1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define TRIGGER_BBG_LED2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define TRIGGER_BBG_LED3 "/sys/class/leds/beaglebone:green:usr3/trigger"

#define BRIGHTNESS_BBG_LED0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define BRIGHTNESS_BBG_LED1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define BRIGHTNESS_BBG_LED2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define BRIGHTNESS_BBG_LED3 "/sys/class/leds/beaglebone:green:usr3/brightness"

#define DIRECTION_BBG_GPIO72 "/sys/class/gpio/gpio72/direction"
#define VALUE_BBG_GPIO72 "/sys/class/gpio/gpio72/value"

#define MIN_DELAY 500
#define MAX_DELAY 3000

#define MAX_RESPONSE_TIME 5000


static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}


static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

static FILE* openFile(char* pathToFile, char* rw)
{
    FILE *fileToOpen = fopen(pathToFile, rw);
    if (fileToOpen == NULL) {
        printf("ERROR OPENING %s.", pathToFile);
        exit(1);
    }

    return fileToOpen;
}

static void setTrigger(char* TRIGGER_FILE_NAME, char* trigger)
{
    FILE *pLedTriggerFile = openFile(TRIGGER_FILE_NAME, "w");

    int charWritten = fprintf(pLedTriggerFile, trigger);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(pLedTriggerFile);

    return;
}

static void setLED(char* BRIGHTNESS_FILE_NAME, char* ON)
{
    FILE *pLedBrightnessFile = openFile(BRIGHTNESS_FILE_NAME, "w");
    
    int charWritten = fprintf(pLedBrightnessFile, ON);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(pLedBrightnessFile);

    return;
}

static void setGPIO_direction(char* GPIO_DIRECTION_FILE_NAME, char* direction)
{
    FILE *pGPIODirectionFile = openFile(GPIO_DIRECTION_FILE_NAME, "w");
    
    int charWritten = fprintf(pGPIODirectionFile, direction);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(pGPIODirectionFile);

    return;
}


static void reset_All_LED()
{
    setTrigger(TRIGGER_BBG_LED0, "none");
    setTrigger(TRIGGER_BBG_LED1, "none");
    setTrigger(TRIGGER_BBG_LED2, "none");
    setTrigger(TRIGGER_BBG_LED3, "none");

    setLED(BRIGHTNESS_BBG_LED0, "0");
    setLED(BRIGHTNESS_BBG_LED1, "0");
    setLED(BRIGHTNESS_BBG_LED2, "0");
    setLED(BRIGHTNESS_BBG_LED3, "0");

    return;
}

static void set_All_LED(char* ON)
{
    setLED(BRIGHTNESS_BBG_LED0, ON);
    setLED(BRIGHTNESS_BBG_LED1, ON);
    setLED(BRIGHTNESS_BBG_LED2, ON);
    setLED(BRIGHTNESS_BBG_LED3, ON);

    return;
}

static void init_GPIO()
{
    runCommand("config-pin p8.43 gpio");
    
    sleepForMs(300);
    setGPIO_direction(DIRECTION_BBG_GPIO72, "in");
}

static int read_GPIO_USER(char *fileName)
{
    FILE *pFileGPIOUser= openFile(fileName, "r");

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFileGPIOUser);
    
    // Close
    fclose(pFileGPIOUser);
    // DEBUG: printf("Read: %s\n", buff);

    return atoi(buff);
}

static long long getRandomDelay()
{
    long long delay = 0;
    delay = (rand() % (MAX_DELAY + 1 - MIN_DELAY)) + MIN_DELAY;
    return delay;
}

int main(int argc, char* args[])
{
    long long reac_start_time = 0;
    long long reac_elapsed_time = 0;
    long long start_time = 0;
    long long elapsed_time = 0; 
    long long best_time = 5001;
    long long delay = 0;
    

    printf("Hello embedded world, from Divyam!\n");

    printf("Instructions: When LED3 lights up, press the USER button!\n\n");

    reset_All_LED();
    init_GPIO();
    
    while(1){
        reac_start_time = 0;
        reac_elapsed_time = 0;
        start_time = 0;
        elapsed_time = 0;
        delay = 0;
        set_All_LED("0");

        // 1. wait(USER_BUTTON)
        while(!read_GPIO_USER(VALUE_BBG_GPIO72)) {
            //do nothing;
            sleepForMs(1);
        }
        

        // 2. turnon(LED0)
        setLED(BRIGHTNESS_BBG_LED0, "1");

        // 3. wait(rand time)
        delay = getRandomDelay();
        start_time = getTimeInMs();
        while(elapsed_time < delay) {
            if(!read_GPIO_USER(VALUE_BBG_GPIO72)){
                reac_elapsed_time = 5000;
                goto step7;
            }
            elapsed_time = getTimeInMs() - start_time;
            //do nothing
            sleepForMs(1);
        }

        // 5. turn on(LED3)
        setLED(BRIGHTNESS_BBG_LED3, "1");
        
        reac_start_time = getTimeInMs();
        while(reac_elapsed_time < MAX_RESPONSE_TIME){
            reac_elapsed_time = getTimeInMs() - reac_start_time;
            if(!read_GPIO_USER(VALUE_BBG_GPIO72)){
                break;
            }    
            sleepForMs(1);
        }
        
        if (reac_elapsed_time >= 5000) {
            printf("No input within 5000ms; quitting!\n");
            return 0;
        }

        // 7. Light up all LEDs
        step7:
        set_All_LED("1");

        // 8 . Display Summary
        // - current resp time
        // - best respons in ms so far
        if(reac_elapsed_time < best_time) {
            best_time = reac_elapsed_time;
            printf("New Best Time!\n");
        }
        printf("Your reaction time was: %lld ms; Your best so far in the game is %lld ms.\n", reac_elapsed_time, best_time);
    
        // Simple delay added for better user experience
        printf("Waiting 1 second before starting next game!\n\n");
        sleepForMs(1000);
    }

    return 0;
}
