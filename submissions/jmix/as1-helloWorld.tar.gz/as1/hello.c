/*
ENSC 351 Assignment 1. Hello world, reaction speed game.
This .c file contains the code to run the basic hello world program and
the reaction time game directly after.

Written by: Jake Mix
*/

#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#define LED0_TRIGGER "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_TRIGGER "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_TRIGGER "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_TRIGGER "/sys/class/leds/beaglebone:green:usr3/trigger"
#define USER_BUTTON "/sys/class/gpio/gpio72/value"

static void initializeGame(void);
static void sleepForMs(long long delayInMs);
static long long getTimeInMs(void);
static bool isButtonPressed(const int MAX_SIZE);
static void toggleLEDOn(int ledNum, bool isOn);
static void toggleAllLEDON(bool isAllOn);
static void runCommand(char* command);

int main()
{
    initializeGame();
    const int MAX = 8;
    bool btnPressedEarly = false;
    long long bestTime = 5000;
    int maxWaitTime = 3000;
    int minWaitTime = 500;

    while(true) {
        toggleLEDOn(0,true);

        long long timeBeforeLEDOn = rand() % (maxWaitTime-minWaitTime+1)+maxWaitTime;
        long long startTime = getTimeInMs();

        while(getTimeInMs() - startTime < timeBeforeLEDOn) {
            if(isButtonPressed(MAX)) {
                btnPressedEarly = true;
                break;
            }
        }
        
        if(!btnPressedEarly) {
            toggleLEDOn(3,true);
            startTime = getTimeInMs();
            long long endTime = 0;

            while(true) {
                endTime = getTimeInMs();

                if(isButtonPressed(MAX)) {
                    break;
                }
                if(endTime - startTime >= 5000) {
                    printf("No input detected within 5s, program quitting\n");
                    toggleAllLEDON(false);
                    return 0;
                }
            }
            if(endTime - startTime < bestTime) {
                bestTime = endTime - startTime;
                printf("New best time of: %lldms!\n", bestTime);
            }
            
            printf("Your reaction speed was: %lldms. Best time so far is: %lldms\n", endTime - startTime, bestTime);
        }
        else {
            printf("Your reaction speed was: >5000ms. Best time so far is: %lldms\n", bestTime);
            btnPressedEarly = false;
        }
        toggleAllLEDON(true);
        sleepForMs(2000);
        toggleAllLEDON(false);
    }

    return 0;
}

static void initializeGame(void)
{
    srand(time(NULL));
    runCommand("config-pin p8.43 gpio");

    printf("Hello embedded world, from Jake!\n");
    printf("When LED3 lights up, press USER button.\n");

    toggleAllLEDON(false);
}


static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;

    return (seconds * 1000 + nanoSeconds/1000000);
}

static bool isButtonPressed(const int MAX_SIZE)
{
    char buff[MAX_SIZE];

    FILE *btnFile = fopen(USER_BUTTON, "r");
    fgets(buff,MAX_SIZE,btnFile);
    fclose(btnFile);
    buff[strcspn(buff, "\n")] = 0;

    if(strcmp(buff,"0") == 0) {
        return true;
    }
    return false;
}

static void toggleLEDOn(int ledNum, bool isOn)
{
    FILE *ledFile = NULL;
    switch(ledNum) {
        case 0:
            ledFile = fopen(LED0_TRIGGER, "w");
            break;
        case 1:
            ledFile = fopen(LED1_TRIGGER, "w");
            break;
        case 2:
            ledFile = fopen(LED2_TRIGGER, "w");
            break;            
        case 3:
            ledFile = fopen(LED3_TRIGGER, "w");
    }

    int writeToLED = 0;
    if(isOn) {
        writeToLED = fprintf(ledFile, "default-on");
    }    
    else {
        writeToLED = fprintf(ledFile, "none");
    }
    fclose(ledFile);
    if(writeToLED <= 0) {
        printf("ERROR writing to LEDs.\n"); 
        exit(-1);
    }
}

static void toggleAllLEDON(bool isAllOn)
{
    char *OPcode;
    if(!isAllOn) {
        OPcode = "none";
    }
    else {
        OPcode = "default-on";
    }

    FILE *ledFile = fopen(LED0_TRIGGER, "w");
    int writeToLED = fprintf(ledFile, "%s", OPcode);
    if(writeToLED <= 0) {exit(-1);}
    fclose(ledFile);

    ledFile = fopen(LED1_TRIGGER, "w");
    writeToLED = fprintf(ledFile, "%s", OPcode);
    if(writeToLED <= 0) {exit(-1);}
    fclose(ledFile);

    ledFile = fopen(LED2_TRIGGER, "w");
    writeToLED = fprintf(ledFile, "%s", OPcode);
    if(writeToLED <= 0) {exit(-1);}
    fclose(ledFile);

    ledFile = fopen(LED3_TRIGGER, "w");
    writeToLED = fprintf(ledFile, "%s", OPcode);
    if(writeToLED <= 0) {exit(-1);}
    fclose(ledFile);
}

static void runCommand(char* command) 
{
    FILE *pipe = popen(command, "r");

    char buffer[1024];
    while(!feof(pipe) && !ferror(pipe)) {
        if(fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
           printf("--> %s", buffer);
    }

    int exitCode = WEXITSTATUS(pclose(pipe));
    if(exitCode != 0) {
        perror("Unable to execute command:");
        printf("   command:   %s\n", command);
        printf("   exit code: %d\n", exitCode);
    }
}