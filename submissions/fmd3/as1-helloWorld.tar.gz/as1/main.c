#include <stdbool.h>
#include <fcntl.h> 
#include <sys/epoll.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include "led.h"
#include "gpio.h"

#define LED_USR0_PATH "/sys/class/leds/beaglebone:green:usr0"
#define LED_USR1_PATH "/sys/class/leds/beaglebone:green:usr1"
#define LED_USR2_PATH "/sys/class/leds/beaglebone:green:usr2"
#define LED_USR3_PATH "/sys/class/leds/beaglebone:green:usr3"

#define GPIO_PIN72_PATH "/sys/class/gpio/gpio72"
#define GPIO_PIN72_COMMAND "config-pin p8.43 gpio"

static float HELLO_randomNumberGenerator(float interval[]);
static void HELLO_initalizeGame(struct LED*, struct GPIO*);
static void HELLO_endGame(struct LED*);
static long long getTimeInMs(void); //copied from asssignment description
static void sleepForMs(long long delayInMs); //copied from assignment description
static void runCommand(char*); //copied from assignement description

struct Time{
    long long times[2];
    long long bestTime;
};

static struct Time timeStruct = {
    {0, 0},
    0
};



int main()
{

    printf("Hello embedded world, from Flynn!\n");
   
   // initalize leds
    struct LED ledstruct[] = {
        {0, LED_USR0_PATH},
        {1, LED_USR1_PATH},
        {2, LED_USR2_PATH},
        {3, LED_USR3_PATH}
    };

    // initalize gpio pin
    struct GPIO gpioStruct = {72, GPIO_PIN72_PATH};
    static long long reactionTime = 0;

    // initalize game
    HELLO_initalizeGame(ledstruct, &gpioStruct);

    LED_setBrightness(LED_HIGH, &ledstruct[2]);

    if(GPIO_getValue(&gpioStruct)){
        reactionTime = 5000;
        LED_setBrightness(LED_HIGH, &ledstruct[1]);
        LED_setBrightness(LED_HIGH, &ledstruct[3]);
        goto display;
    }

    while(1){

        int ret = GPIO_waitEdge(&gpioStruct);
        if(ret == -1){
            printf("Error: something went wrong.\n");
            exit(1);
        }

        if(ret){
            printf("No input within 5000ms quitting!\n");
            break;
        }

        // logic required for game
        int value_read = GPIO_getValue(&gpioStruct);

        if(value_read){
            if(!((int)timeStruct.times[0] | (int)timeStruct.times[1])){
                timeStruct.times[0] = getTimeInMs();
            }
            else{
                timeStruct.times[1] = getTimeInMs();        
                reactionTime = timeStruct.times[1] - timeStruct.times[0];
                
display:        if(!timeStruct.bestTime){
                    timeStruct.bestTime = reactionTime;
                    printf("New best time!\n");
                }
                
                if(reactionTime < timeStruct.bestTime){
                    timeStruct.bestTime = reactionTime;
                    printf("New best time!\n");
                }
                
                timeStruct.times[0] = 0;
                timeStruct.times[1] = 0;
                LED_setBrightness(LED_HIGH, &ledstruct[1]);
                LED_setBrightness(LED_HIGH, &ledstruct[3]);
                printf("Your reaction time was %lldms", reactionTime);
                printf("; best so far in game is %lldms\n", timeStruct.bestTime);
            }
        }
    }
    
    // clean/exit game
    HELLO_endGame(ledstruct);
    return 0;
}


void HELLO_initalizeGame(struct LED* ledStruct, struct GPIO* gpioStruct)
{
	LED_setTrigger(LED_NONE, &ledStruct[0]);
    LED_setTrigger(LED_NONE, &ledStruct[1]);
    LED_setTrigger(LED_NONE, &ledStruct[2]);
    LED_setTrigger(LED_NONE, &ledStruct[3]);

    LED_setBrightness(LED_LOW, &ledStruct[0]);
    LED_setBrightness(LED_LOW, &ledStruct[1]);
    LED_setBrightness(LED_LOW, &ledStruct[2]);
    LED_setBrightness(LED_LOW, &ledStruct[3]);

    runCommand(GPIO_PIN72_COMMAND);

    GPIO_setDirection(GPIO_IN, gpioStruct);
    GPIO_setActiveLow(GPIO_HIGH, gpioStruct);
    GPIO_setEdge(GPIO_RISING, gpioStruct);

    GPIO_waitEdge(gpioStruct);
    LED_setBrightness(LED_HIGH, &ledStruct[0]);

    printf("When LED3 lights up, press the USER button!\n");
    
    sleepForMs(rand() % (3000 - 500 + 1) + 500);

    
}
void HELLO_endGame(struct LED* ledStruct)
{
	LED_setBrightness(LED_LOW, &ledStruct[0]);
    LED_setBrightness(LED_LOW, &ledStruct[1]);
    LED_setBrightness(LED_LOW, &ledStruct[2]);
    LED_setBrightness(LED_LOW, &ledStruct[3]);
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}