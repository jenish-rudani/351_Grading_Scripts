#include "gpio.h"
#include <stdbool.h>
#include <fcntl.h> 
#include <sys/epoll.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#define MAX_SIZE 1024
#define NUMBER_OF_FILE_DESCRIPTORS 1
#define NUMBER_OF_EVENTS 1

static char* stringAppender(char* buff, char* path, char* added);
static void writeToGPIO(char* filename, char* value);
static int readLineFromFile(char* fileName, char* buff, unsigned int maxLength);


bool GPIO_setDirection(enum GPIO_DIRECTION direction, struct GPIO* gpioStruct)
{
    char buff[MAX_SIZE];
    char *path = stringAppender(buff, gpioStruct->path, "/direction");
    if(direction){
        writeToGPIO(path, "out");
    }
    else if(!direction){
        writeToGPIO(path, "in");
    }
    else{
        return false;
    }
    return true;
}
bool GPIO_setActiveLow(enum GPIO_ACTIVE_LOW active_low, struct GPIO* gpioStruct)
{
    char buff[MAX_SIZE];
    char *path = stringAppender(buff, gpioStruct->path, "/active_low");
    if(active_low){
        writeToGPIO(path, "1");
    }
    else if(!active_low){
        writeToGPIO(path, "0");
    }
    else{
        return false;
    }
    return true;
}
bool GPIO_setEdge(enum GPIO_EDGE edge, struct GPIO* gpioStruct)
{
    char buff[MAX_SIZE];
    char *path = stringAppender(buff, gpioStruct->path, "/edge");
    if(edge == GPIO_BOTH){
        writeToGPIO(path, "both");
    }
    else if(edge == GPIO_RISING){
        writeToGPIO(path, "rising");
    }
    else{
        return false;
    }
    return true;
}
int GPIO_waitEdge(struct GPIO* gpioStruct) //modified code from guides
{
    int epoll_fileDescriptor = epoll_create(NUMBER_OF_FILE_DESCRIPTORS);
    if(epoll_fileDescriptor == -1){
        printf("Error: failed to create file descriptor for epoll.\n");
        exit(1);
    }

    char buff[MAX_SIZE];
    char *pathToValue = stringAppender(buff, gpioStruct->path, "/value");
    
    int toBeRead_fileDescriptor = open(pathToValue, O_RDONLY | O_NONBLOCK);
    if(toBeRead_fileDescriptor == -1){
        printf("Error: failed to open %c for reading.\n", buff);
        exit(1);
    }

    struct epoll_event epollStruct;
    epollStruct.data.fd = toBeRead_fileDescriptor;
    epollStruct.events = EPOLLIN | EPOLLPRI | EPOLLET;
    int requestToAdd = epoll_ctl(epoll_fileDescriptor, EPOLL_CTL_ADD, toBeRead_fileDescriptor, &epollStruct);
    if(requestToAdd == -1){
        printf("Error: failed to add %c to epoll instance.\n", buff);
        exit(1);
    }

    for(int i = 0; i < 2; i++){
        int wait = epoll_wait(epoll_fileDescriptor, &epollStruct, 1, 5000);
        if(wait == -1){
            close(toBeRead_fileDescriptor);
            close(epoll_fileDescriptor);
            return -1;
        }

        if(!wait){
            close(toBeRead_fileDescriptor);
            close(epoll_fileDescriptor);
            return 1;
        }

    }

    close(toBeRead_fileDescriptor);
    close(epoll_fileDescriptor);
    return 0;
}

static char* stringAppender(char* buff, char* path, char* added)
{
    snprintf(buff, MAX_SIZE, path);
	strncat(buff, added,  MAX_SIZE - strnlen(buff, MAX_SIZE) -1);
	return buff;
}

static void writeToGPIO(char* filename, char* value)
{
    // code from GPIO guide.
    FILE *pFile = fopen(filename, "w");
    if (pFile == NULL) {
    printf("ERROR: Unable to open export file.\n");
    exit(1);
    }
    
    fprintf(pFile, "%s", value);
   
    fclose(pFile);
    
}

int GPIO_getValue(struct GPIO* gpioStruct)
{
    char buff[MAX_SIZE];
    char* path = stringAppender(buff, gpioStruct->path, "/value");
    int bytes_read = readLineFromFile(path, buff, MAX_SIZE);
    if(bytes_read > 0){
        return atoi(buff);
    }
    else{
        printf("Error: could not read any bytes from %s\n", path);
        exit(1);
    }
}

//function from gpio edge trigger example in guides
static int readLineFromFile(char* fileName, char* buff, unsigned int maxLength)
{
	FILE *file = fopen(fileName, "r");
	int bytes_read = getline(&buff, &maxLength, file);
	fclose(file);
	return bytes_read;
}