#include "led.h"
#include <stdbool.h> 
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAX_SIZE 1024

static void writeToLED(const char*, const char* );
static char* stringAppender(char* buff, char* path, char* added);

bool LED_setBrightness(enum LED_BRIGHTNESS brightness, struct LED *ledStruct)
{
    char buff[MAX_SIZE];
    char *path = stringAppender(buff, ledStruct->path, "/brightness");
    if(brightness){
        writeToLED(path, "1");
    }
    else if(!brightness){
        writeToLED(path, "0");
    }
    else{
        return false;
    }
    return true;
}
bool LED_setTrigger(enum LED_TRIGGER trigger, struct LED *ledStruct)
{
    char buff[MAX_SIZE];
    char *path = stringAppender(buff, ledStruct->path, "/trigger");
    switch(trigger){
        case LED_NONE:
            writeToLED(path, "none");
            break;
    }
    return true;
}

static void writeToLED(const char* filename, const char* command )
{
	FILE *pFile = fopen(filename, "w");

	if (pFile == NULL) {
		printf("ERROR OPENING %s.\n", filename);
		exit(1);
	}

	int charWritten = fprintf(pFile, command);

	if (charWritten <= 0) {
		printf("ERROR WRITING DATA\n");
		exit(1);
	}
	
	fclose(pFile);
}

static char* stringAppender(char* buff, char* path, char* added)
{
    snprintf(buff, MAX_SIZE, path);
	strncat(buff, added,  MAX_SIZE - strnlen(buff, MAX_SIZE) -1);
	return buff;
}