#ifndef LED_H_
#define LED_H_
#include <stdbool.h> // for bool functions

// enum, get and set functions referenced from Exploring BeagleBone 2nd edition, Derek Molloy.
// see led.c for code.

enum LED_BRIGHTNESS {LED_LOW = 0, LED_HIGH = 1};
enum LED_TRIGGER {LED_NONE};

// struct to hold led number and path
struct LED{
    int number;
    char *path;
};

bool LED_setBrightness(enum LED_BRIGHTNESS, struct LED *);
// function that sets the led brightness to high/1 or low/0.
// returns true if LED_BRIGHTNESS is defined in enum.

bool LED_setTrigger(enum LED_TRIGGER, struct LED *);
// function that sets the led trigger 
// returns true if LED_TRIGGER is defined in enum.

#endif