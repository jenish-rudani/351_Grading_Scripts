//  created by Chenting Mao
//  header file for functions related to LEDs on beaglebone
//	last edited: 2022/9/30	by:	Chenting Mao

#ifndef LED_H
#define LED_H
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

#define LED0_TRIGGER "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED0_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr0/brightness"

#define LED1_TRIGGER "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED1_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr1/brightness"

#define LED2_TRIGGER "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED2_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr2/brightness"

#define LED3_TRIGGER "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED3_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr3/brightness"

//  Initalize LED0-4
//  return false and print ERROR message and Initalize fails
bool LEDInitial(void);

//  Turn on/off LEDX
//  Turn on/off LEDX if "status" is otherwise/0 
//  Return 1/0 if LEDX is turned on/off
//  Return -1 if ERROR occurs and print ERROR message
//  VERY IMPORTANT: LEDs must be initalized using LEDInitial()!
//  Result is unexpected if LEDxLight is used before initalizing
int LED0Light(const int status);
int LED1Light(const int status);
int LED2Light(const int status);
int LED3Light(const int status);

// Turn on/off all LEDs
// Turn on/off all LEDs if "status" is otherwise/0
// Return 1/0 if LEDs are turned on/off
// Return -1 if ERROR occurs and print ERROR message
// VERY IMPORTANT: LEDs must be initalized using LEDInitial()!
// Result is unexpected if LEDALL_Light is used before initalizing
int LEDALL_Light(const int status);



#endif