//  created by Chenting Mao
//	last edited: 2022/9/30	by:	Chenting Mao

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>
#include "led.h"

//	Function given in notes
//	Return false if FileOpening failed and print ERROR message
static bool BBG_FileInput(const char* dir, const char* command);



bool LEDInitial(void)
{
	const char* LED_TriggerFIles[4] = { LED0_TRIGGER,LED1_TRIGGER,LED2_TRIGGER,LED3_TRIGGER };
	bool InputResult = true;

	//set all LEDs to none
	for (int i = 0; i < 4; i++) {
		InputResult = BBG_FileInput(LED_TriggerFIles[i], "none");
		if (!InputResult) {
			return 0;
		}
	}
	return InputResult;
}



int LED0Light(const int status)
{
	int ReturnValue = 1;
	bool FileOpened = 0;

	//write to LED0 brightness
	if(status == 0){
		FileOpened = BBG_FileInput(LED0_BRIGHTNESS, "0");
		ReturnValue = 0;
	}
	else{
		FileOpened = BBG_FileInput(LED0_BRIGHTNESS, "1");
	}

	//if file is not opened
	if(!FileOpened){
		ReturnValue = -1;
	}
	return ReturnValue;
}



int LED1Light(const int status)
{
	int ReturnValue = 1;
	bool FileOpened = 0;

	//write to LED1 brightness
	if(status == 0){
		FileOpened = BBG_FileInput(LED1_BRIGHTNESS, "0");
		ReturnValue = 0;
	}
	else{
		FileOpened = BBG_FileInput(LED1_BRIGHTNESS, "1");
	}

	//if file is not opened
	if(!FileOpened){
		ReturnValue = -1;
	}
	return ReturnValue;
}



int LED2Light(const int status)
{
	int ReturnValue = 1;
	bool FileOpened = 0;

	//write to LED2 brightness
	if(status == 0){
		FileOpened = BBG_FileInput(LED2_BRIGHTNESS, "0");
		ReturnValue = 0;
	}
	else{
		FileOpened = BBG_FileInput(LED2_BRIGHTNESS, "1");
	}

	//if file is not opened
	if(!FileOpened){
		ReturnValue = -1;
	}
	return ReturnValue;
}



int LED3Light(const int status)
{
	int ReturnValue = 1;
	bool FileOpened = 0;

	//write to LED3 brightness
	if(status == 0){
		FileOpened = BBG_FileInput(LED3_BRIGHTNESS, "0");
		ReturnValue = 0;
	}
	else{
		FileOpened = BBG_FileInput(LED3_BRIGHTNESS, "1");
	}

	//if file is not opened
	if(!FileOpened){
		ReturnValue = -1;
	}
	return ReturnValue;
}



int LEDALL_Light(const int status)
{
	int ReturnArr[4] = {0,0,0,0};
	ReturnArr[0] = LED0Light(status);
	ReturnArr[1] = LED1Light(status);
	ReturnArr[2] = LED2Light(status);
	ReturnArr[3] = LED3Light(status);

	//find return value -1 from LEDxLIght()
	int MinReturn = 1;
	for(int i=0; i<4; i++){
		if(MinReturn > ReturnArr[i]){
			MinReturn = ReturnArr[i];
		}
	}
	return MinReturn;

}



static bool BBG_FileInput(const char* dir, const char* command)
{
	FILE* BBG_File = fopen(dir, "w");

	if (BBG_File == NULL) {
		printf("ERROR OPENING %s.", dir);
		return 0;
	}
	int charWritten = fprintf(BBG_File, command);

	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		return 0;
	}
	fclose(BBG_File);
	return 1;
}
