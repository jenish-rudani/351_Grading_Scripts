//  created by Chenting Mao
//	last edited: 2022/10/2	by:	Chenting Mao

#include "gpio.h"

//	Unique Error Code for GPIO value reading check
//	Must be string of numbers
#define UNIQUE_ERROR_MESSAGE "97392913"

//	function given in notes
//	excute "command" in Linux
//	return false if command is unable to excute
static bool runCommand(char* command);

//	function given in notes
//	return < cat "fileName" > in Linux
//	return UNIQUE_ERROR_MESSAGE if file opening failed
static char* readFromFileToScreen(const char *fileName);



bool UserInit(void)
{
    return(runCommand("config-pin p8.43 gpio"));
}


int ReadUserValue(void)
{
    return(atoi(readFromFileToScreen(USER_VALUE)));
}


bool ReadUserValueErrorCheck(void)
{
    return(ReadUserValue() == atoi(UNIQUE_ERROR_MESSAGE));
}


bool UserIsPressed(void)
{
	if(ReadUserValue()==0){
		return true;
	}
	else{
		return false;
	}
	
}


static bool runCommand(char* command)
{
 	// Execute the shell command (output into pipe)
 	FILE *pipe = popen(command, "r");

 	// Ignore output of the command; but consume it 
 	// so we don't get an error when closing the pipe.
 	char buffer[1024];
 	while (!feof(pipe) && !ferror(pipe)) {
 		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 			break;
 	// printf("--> %s", buffer); // Uncomment for debugging
 	}

 	// Get the exit code from the pipe; non-zero is an error:
 	int exitCode = WEXITSTATUS(pclose(pipe));
 	if (exitCode != 0) {
 		perror("Unable to execute command:");
 		printf(" command: %s\n", command);
 		printf(" exit code: %d\n", exitCode);
		return 0;
 	}
	return 1;
}



static char* readFromFileToScreen(const char *fileName)
{
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
		printf("ERROR: Unable to open file (%s) for read\n", fileName);
		return UNIQUE_ERROR_MESSAGE;
	}

	// Read string (line)
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	char *message = buff;

	// Close
	fclose(pFile);
	//printf("Read: %s \n", s);
	return message;
}