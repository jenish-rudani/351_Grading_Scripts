//	created by Chenting Mao
//	main script of the program
//	this program is a little name: 	press the button when LED lights on 
//									reaction time will be displayed
//									game ends when the button is not pressed after a period of time
//	last edited: 2022/10/2	by:	Chenting Mao


#include "led.h"
#include "gpio.h"
#include "timer.h"

//#define DEBUG

#ifndef DEBUG
#define RUN
#endif

#define MaxReactionTimeInMs 5000

#define RandTimeLow 500
#define RandTImeUp	3000

#define TestLoopNum	2000

#define SleepTimeInMs	2300
#define	RoundGapTimeInMs	1000


int main()
{
	printf("\nWelcome to my embedded world!\n\n");
	sleepForMs(SleepTimeInMs);
	printf("Let's play a little game ... \n\n");
	
	//Initilize LEDs
	if(!LEDInitial()){
		exit(1);
	}

	//Light up only LED0
	if(LEDALL_Light(0)==-1){
		exit(1);
	}
	LED0Light(1);

	//config USER to gpio
	if(!UserInit()){
		exit(1);
	}

	//Check validity for user value reading
	if(ReadUserValueErrorCheck()){
		exit(1);
	}

	//calculating the average Code Ececuting Time Per Loop
	//getting the total time for running "TimeTest_LoopNum" loops
	long long TT_Time1InMs = getTimeInMs();
	int TT_PassedTimeCount = 0;

	while(!UserIsPressed() && TT_PassedTimeCount<=TestLoopNum){
			sleepForMs(1);
			TT_PassedTimeCount += 1;
	}
	long long TT_Time2InMs = getTimeInMs();

	//getting the average time
	//using doule type for calculation for percise 
	double TT_DoubleLoopNum = TestLoopNum;
	double TT_TimePassedInMs = (double)TT_Time2InMs-TT_Time1InMs;
	double TT_ExecutingTimePerLoop = (TT_TimePassedInMs-TT_DoubleLoopNum)/TT_DoubleLoopNum;


	#ifdef DEBUG
	//Calculation test
	//A 5s running
	//print out the actual passed time
	printf("TimeTest_ExecutingTimePerLoop is %lf \n", TT_ExecutingTimePerLoop);
	int testnum = 0;
	TT_PassedTimeCount = 0;
	testnum = MaxReactionTimeInMs/(1+TT_ExecutingTimePerLoop);
	printf("num is %d \n", testnum);
	TT_Time1InMs = getTimeInMs();
	while(ReadUserValue()!=0 && TT_PassedTimeCount <= testnum){
			sleepForMs(1);
			TT_PassedTimeCount += 1;
	}
	TT_Time2InMs = getTimeInMs();
	printf("time is %lld \n", TT_Time2InMs-TT_Time1InMs);
	#endif
	

	#ifdef RUN
	printf("When LED3 lights up, press the USER button!\n\n");

	long long RandTimeInMs = 0;

	int TimeElapsedInMs = 0;
	int BestTimeInMs = MaxReactionTimeInMs+1;

	int TimeElaspedLoopNum = 0;
	int LoopRound = MaxReactionTimeInMs/(1+TT_ExecutingTimePerLoop);

	long long Time1InMs = 0;
	long long Time2InMs = 0;

	while(1){
		TimeElapsedInMs = 0;

		//Wait between 0.5 - 3 s
		RandTimeInMs = rand()%(RandTImeUp-RandTimeLow+1)+RandTimeLow;
		sleepForMs(RandTimeInMs);

		//if USER is pressed already
		//Record response time as 5.0s
		//Skip to “Light up all LEDs”
		if(UserIsPressed()){
			TimeElapsedInMs = MaxReactionTimeInMs;
			if(BestTimeInMs > TimeElapsedInMs){
				BestTimeInMs = TimeElapsedInMs;
				printf("New Best Time! \n");
			}
			printf("Your recation time was %dms;",TimeElapsedInMs);
			printf(" best so far in game is %dms. \n\n",BestTimeInMs);
			LEDALL_Light(1);
			sleepForMs(RoundGapTimeInMs);
			LEDALL_Light(0);
			LED0Light(1);
			continue;
		}

		//Light up LED3
		if(LED3Light(1)==-1){
			exit(1);
		}

		TimeElaspedLoopNum = 0;
		Time1InMs = getTimeInMs();
		while(!UserIsPressed() && TimeElaspedLoopNum<=LoopRound){
			sleepForMs(1);
			TimeElaspedLoopNum += 1;
		}
		Time2InMs = getTimeInMs();
		TimeElapsedInMs = (int)(Time2InMs-Time1InMs);
		

		if(TimeElapsedInMs>LoopRound){
			printf("Times Up. Bye Bye!\n\n");
			LEDALL_Light(0);
			break;
		}

		if(BestTimeInMs > TimeElapsedInMs){
			BestTimeInMs = TimeElapsedInMs;
			printf("New Best Time! \n");
		}
		
		printf("Your recation time was %dms;",TimeElapsedInMs);
		printf(" best so far in game is %dms. \n\n",BestTimeInMs);

		//Light up All LEDs and proceed to next round after 1s
		LEDALL_Light(1);
		sleepForMs(RoundGapTimeInMs);
		LEDALL_Light(0);
		LED0Light(1);
	}
	#endif
	return 0;
}







