#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>

#define LED0_FILEPATH "/sys/class/leds/beaglebone:green:usr0"
#define LED1_FILEPATH "/sys/class/leds/beaglebone:green:usr1"
#define LED2_FILEPATH "/sys/class/leds/beaglebone:green:usr2"
#define LED3_FILEPATH "/sys/class/leds/beaglebone:green:usr3"

#define USER_BTN_FILEPATH "/sys/class/gpio/gpio72"

#define FILEPATH_STR_LENGTH 60

#define LED_OFF "0"
#define LED_ON "1"

#define MAX_RESPONSE_TIME 5000

void setupLED(char *ledFilePath);
void setLEDBrightness(char *ledPath, char *brightness);
FILE *openFile(char *filePath);
void writeFile(FILE *pFile, char *toWrite);
static void runCommand(char *command);
void setupUserInputButton();
int getGPIOValue(char *filePath);
static void sleepForMs(long long delayInMs);
static long long getTimeInMs(void);

int main()
{
    printf("Hello embedded world, from Tejash!\n\n");

    setupUserInputButton();

    setupLED(LED0_FILEPATH);
    setupLED(LED1_FILEPATH);
    setupLED(LED2_FILEPATH);
    setupLED(LED3_FILEPATH);

    setLEDBrightness(LED0_FILEPATH, LED_OFF);
    setLEDBrightness(LED1_FILEPATH, LED_OFF);
    setLEDBrightness(LED2_FILEPATH, LED_OFF);
    setLEDBrightness(LED3_FILEPATH, LED_OFF);

    bool runGame = true;
    // set first response record to maximum response time
    long long bestResponseTime = MAX_RESPONSE_TIME;

    printf("When LED3 lights up, press the USER button!\n");
    while (runGame)
    {

        long long responseTimeInMs = 0;
        long long startTime = 0;

        if (getGPIOValue(USER_BTN_FILEPATH) == 0)
        {

            setLEDBrightness(LED0_FILEPATH, LED_ON);
            setLEDBrightness(LED1_FILEPATH, LED_OFF);
            setLEDBrightness(LED2_FILEPATH, LED_OFF);
            setLEDBrightness(LED3_FILEPATH, LED_OFF);

            // wait for random time between 500ms and 3000ms
            int sleepTime = rand() % (3000 + 1 - 500) + 500;
            sleepForMs(sleepTime);

            // check if button is pressed before LED3 turns on
            if (getGPIOValue(USER_BTN_FILEPATH) == 1)
            {
                responseTimeInMs = MAX_RESPONSE_TIME;
            }
            else
            {
                // Turn on LED3
                setLEDBrightness(LED3_FILEPATH, LED_ON);
                // Start timer
                startTime = getTimeInMs();
                // While we don't have a response
                while (responseTimeInMs == 0)
                {
                    // check if button was pressed only if max response time has not elapsed
                    if (getTimeInMs() - startTime < MAX_RESPONSE_TIME)
                    {
                        if (getGPIOValue(USER_BTN_FILEPATH) == 1)
                        {
                            responseTimeInMs = getTimeInMs() - startTime;
                        }
                    }
                    // if max response time has elapsed, quit the program
                    else
                    {
                        printf("No input within %dms; quitting! \n", MAX_RESPONSE_TIME);
                        exit(1);
                    }
                }
            }
            // Set all LEDs to ON after user button is pressed
            setLEDBrightness(LED0_FILEPATH, LED_ON);
            setLEDBrightness(LED1_FILEPATH, LED_ON);
            setLEDBrightness(LED2_FILEPATH, LED_ON);
            setLEDBrightness(LED3_FILEPATH, LED_ON);
            // check if new best time
            if (responseTimeInMs < bestResponseTime)
            {
                bestResponseTime = responseTimeInMs;
                printf("New best time!\n");
            }
            // print results
            printf("Your reaction time was %lldms; best so far in the game is %lldms \n", responseTimeInMs, bestResponseTime);
        }
    }

    return 0;
}

// disable trigger on an led given its path
void setupLED(char *ledFilePath)
{

    char triggerFilePath[FILEPATH_STR_LENGTH];
    strcpy(triggerFilePath, ledFilePath);
    strcat(triggerFilePath, "/trigger");
    FILE *pLedTriggerFile = openFile(triggerFilePath);
    writeFile(pLedTriggerFile, "none");
    return;
}

// set led brightness given its path and brightness value
void setLEDBrightness(char *ledFilePath, char *brightness)
{
    char brightnessFilePath[FILEPATH_STR_LENGTH];
    strcpy(brightnessFilePath, ledFilePath);
    strcat(brightnessFilePath, "/brightness");
    FILE *pLEDBrightnessFile = openFile(brightnessFilePath);
    writeFile(pLEDBrightnessFile, brightness);
}

// open a file and return a pointer to the FILE object
FILE *openFile(char *filePath)
{
    FILE *pFile = fopen(filePath, "w");
    if (pFile == NULL)
    {
        printf("ERROR OPENING %s.", filePath);
        exit(1);
    }
    return pFile;
}

// write to a file given the pointer to a FILE object, and the string to write
void writeFile(FILE *pFile, char *toWrite)
{
    int charWritten = fprintf(pFile, toWrite);
    if (charWritten <= 0)
    {
        printf("ERROR WRIING DATA");
        exit(1);
    }
    fclose(pFile);
}

// Run a linux command
static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

// Run appropriate commands to configure USER button
void setupUserInputButton()
{
    runCommand("config-pin p8.43 gpio");
    runCommand("cd /sys/class/gpio");
    runCommand("echo 72 > export");
    runCommand("cd /sys/class/gpio/gpio72");
    runCommand("echo in > direction");
    runCommand("echo 1 > /sys/class/gpio/gpio72/active_low");
}

// get the value of a GPIO pin given its path
int getGPIOValue(char *filePath)
{
    char gpioFilePath[FILEPATH_STR_LENGTH];
    strcpy(gpioFilePath, filePath);
    strcat(gpioFilePath, "/value");
    FILE *pFile = fopen(gpioFilePath, "r");
    if (pFile == NULL)
    {
        printf("ERROR: Unable to open file (%s) for read\n", gpioFilePath);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);

    return atoi(buff);
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}