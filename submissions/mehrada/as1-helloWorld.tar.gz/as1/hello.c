// ASSIGNMENT #1
// Name: Mehrad Akhavan-Kharazi
// S#: 301368205
// ----------------------------------------------------------------
// Description: 
// Display a hello-world welcome message
// Continuously loop through the following steps to play the game:
// 1. Wait while user holds down USER button
// 2. Light up only LED 0
// 3. Wait a random time (between 0.5s and 3.0s)
// 4. If user is pressing the USER button already (too soon):
// - Record response time as 5.0s
// - Skip to “Light up all LEDs”
// 5. Light up LED 3 & start timer
// 6. When user presses USER button, stop timer
// - If timer > 5s, exit with a message without waiting for button press
// 7. Light up all LEDs
// 8. Display summary:
// - How many ms was the current response time?
// - How many ms is the best response time so far this game?

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define LED0 "/sys/class/leds/beaglebone:green:usr0" // These are paths for LED
#define LED1 "/sys/class/leds/beaglebone:green:usr1"
#define LED2 "/sys/class/leds/beaglebone:green:usr2"
#define LED3 "/sys/class/leds/beaglebone:green:usr3"

#define ON "1"
#define OFF "0"

void Set_Triggers(void) // Sets triggers for the LEDS
{
    FILE *pLedTriggerFile0 = fopen(LED0 "/trigger", "w");
    FILE *pLedTriggerFile1 = fopen(LED1 "/trigger", "w");
    FILE *pLedTriggerFile2 = fopen(LED2 "/trigger", "w");
    FILE *pLedTriggerFile3 = fopen(LED3 "/trigger", "w");

    fprintf(pLedTriggerFile0, "none");
    fprintf(pLedTriggerFile1, "none");
    fprintf(pLedTriggerFile2, "none");
    fprintf(pLedTriggerFile3, "none");

    fclose(pLedTriggerFile0);
    fclose(pLedTriggerFile1);
    fclose(pLedTriggerFile2);
    fclose(pLedTriggerFile3);
}

void Initialize_Pin(void) // Initializes USER GPIO pin
{
    FILE *pFile1 = fopen(" ", "w");
    FILE *pFile2 = fopen("/sys/class/gpio/gpio72/active_low", "w");
    fprintf(pFile1, "config-pin p8.43 gpio");
    fprintf(pFile2, OFF);
    fclose(pFile1);
    fclose(pFile2);
}

int Check_USER_Button(void) // Checks if the button is pressed
{
    FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
    char buffer[1024];
    fgets(buffer, sizeof(buffer), pFile);
    fclose(pFile);

    return atoi(buffer);
}

void LED0_ON(void) // Turns on LED0
{   
    FILE *pLedTriggerFile = fopen(LED0 "/brightness", "w");
    fprintf(pLedTriggerFile, ON);
    fclose(pLedTriggerFile);
}

void LED3_ON(void) // Turns off LED3
{   
    FILE *pLedTriggerFile = fopen(LED3 "/brightness", "w");
    fprintf(pLedTriggerFile, ON);
    fclose(pLedTriggerFile);
}

void Control_ALL_LEDs(int command) // Turns all LEDs ON (for command=1) or OFF (for command=0)
{   
    FILE *pLedTriggerFile0 = fopen(LED0 "/brightness", "w");
    FILE *pLedTriggerFile1 = fopen(LED1 "/brightness", "w");
    FILE *pLedTriggerFile2 = fopen(LED2 "/brightness", "w");
    FILE *pLedTriggerFile3 = fopen(LED3 "/brightness", "w");

    if (command==1)
    {
        fprintf(pLedTriggerFile0, ON);
        fprintf(pLedTriggerFile1, ON);
        fprintf(pLedTriggerFile2, ON);
        fprintf(pLedTriggerFile3, ON);
    }
    else if(command==0)
    {
        fprintf(pLedTriggerFile0, OFF);
        fprintf(pLedTriggerFile1, OFF);
        fprintf(pLedTriggerFile2, OFF);
        fprintf(pLedTriggerFile3, OFF);
    }

    fclose(pLedTriggerFile0);
    fclose(pLedTriggerFile1);
    fclose(pLedTriggerFile2);
    fclose(pLedTriggerFile3);
}

float Random_Number_Range(float lowerBound, float upperBound) // Generates random number between lower and upper bound
{
    srand(time(0));
    float difference=upperBound-lowerBound;
    return (((float) rand() / RAND_MAX) * difference) + lowerBound;
}

static long long getTimeInMs(void) // Gets the current time
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs) // You can wait a number of milliseconds with:
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

void Play_Game(void) // Function for playing the game
{
    long long Time0 = 0;
    long long Time1 = 0;
    long long Reaction_Time = 5000;
    long long Best_Reaction_Time = 5000;

    while(1)
    {
        while(Check_USER_Button()) // This while loop waits for USER button to be pressed
        {

        } 

        Control_ALL_LEDs(0); // Turn off all LEDs (Pass arguement 0 for off and 1 for on)
        LED0_ON(); // Turn on LED0 only
        
        sleepForMs(Random_Number_Range(500,3000)); // Wait for a random number between 0.5 and 3 seconds

        if(!Check_USER_Button()) // If button is held down, record response time as 5.0s
        {
            printf("Your reaction time was 5000ms; best so far in game is %llims \n", Best_Reaction_Time);
        }
        else
        {   
            LED3_ON(); // Turn on LED3 only
            Time0 = getTimeInMs(); // time initial
            while(Check_USER_Button()) // This while loop waits for USER button to be pressed
            {
                Time1 = getTimeInMs(); // time final
                Reaction_Time = Time1 - Time0; // time = time final - time initial
                if(Reaction_Time >= 5000)
                {
                    printf("No input within 5000ms; quitting! \n");
                    Control_ALL_LEDs(0); // Pass arguement 0 for off and 1 for on
                    exit(0); // go back to int main
                }
            } 

            if(Reaction_Time < Best_Reaction_Time) // Update best reaction time
            {
                Best_Reaction_Time = Reaction_Time; 
                printf("New best time! \n");
            }

            printf("Your reaction time was %llims; best so far in game is %llims \n", Reaction_Time, Best_Reaction_Time);
        }

        Control_ALL_LEDs(1);
        sleepForMs(350); // Wait a bit so input from button being held down doesn't spill over
    }
}

int main(int argc, char* args[])
{
    printf("Hello embedded world, from Mehrad Akhavan-Kharazi! \n");

    Set_Triggers(); // Set triggers for LEDs

    Initialize_Pin(); // Set pin to active_high

    Play_Game(); // Play the game..

    return 0;
}