#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define F_TRIGGER0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define F_TRIGGER1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define F_TRIGGER2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define F_TRIGGER3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define F_BRIGHTNESS0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define F_BRIGHTNESS1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define F_BRIGHTNESS2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define F_BRIGHTNESS3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define F_EXPORT "/sys/class/gpio/export"
#define F_USER_BUTTON_DIRECTION "/sys/class/gpio/gpio72/direction"
#define F_USER_BUTTON_ACTIVE_LOW "/sys/class/gpio/gpio72/active_low"
#define F_USER_BUTTON_VALUE "/sys/class/gpio/gpio72/value"

//write to file func
static void setTriggerToNone(char* triggerFile);
static void setAllTriggersToNone(void);
static void setBrightness(char* brightnessFile, char* brightness);
static void setAllBrightness(char* brightness);
static void setupUserButton(void);
static void waitForButtonFallingEdge();
static char readButton();
static int timeResponse();

//from Assignment1.pdf
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
static void runCommand(char* command);

int main(int argc, char* args[])
{
	int bestTime = 5000;
	int duration = 0;
	printf("Hello embedded world, from Bowie!\n\nWhen LED3 lights up, press the USER button!\n");

	setupUserButton();
	setAllTriggersToNone();
	setAllBrightness("0");

	while (duration <= 5000) {
		waitForButtonFallingEdge();
		setAllBrightness("0");
		setBrightness(F_BRIGHTNESS0, "1");

		srand(time(NULL));
		int randSleepTime = rand() % 2501 + 500; // 500-3000ms
		sleepForMs(randSleepTime);

		if (readButton() == '1') {
			duration = 5000;
		}
		else {
			setBrightness(F_BRIGHTNESS3, "1");
			duration = timeResponse();
		}
		
		if (duration > 5000) {
			setAllBrightness("0");
			printf("No input within 5000ms; quitting!\n");
		}
		else {
			setAllBrightness("1");
			if (duration < bestTime) {
				printf("New best time!\n");
				bestTime = duration;
			}
			printf("Your reaction time was %4dms; best so far in game is %4dms.\n", duration, bestTime);
		}
	}
	return 0;
}

static void setTriggerToNone(char* triggerFile)
{
	FILE *pLedTriggerFile = fopen(triggerFile, "w");
	if (pLedTriggerFile == NULL) {
		printf("ERROR OPENING %s.", triggerFile);
		exit(1);
	}

	int charWritten = fprintf(pLedTriggerFile, "none");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	fclose(pLedTriggerFile);
	return;
}

static void setAllTriggersToNone()
{
	setTriggerToNone(F_TRIGGER0);
	setTriggerToNone(F_TRIGGER1);
	setTriggerToNone(F_TRIGGER2);
	setTriggerToNone(F_TRIGGER3);
	return;
}

static void setBrightness(char* brightnessFile, char* brightness)
{
	FILE *pLedBrightnessFile = fopen(brightnessFile, "w");
	if (pLedBrightnessFile == NULL) {
		printf("ERROR OPENING %s.", brightnessFile);
		exit(1);
	}

	int charWritten = fprintf(pLedBrightnessFile, brightness);
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	fclose(pLedBrightnessFile);
	return;
}

static void setAllBrightness(char* brightness)
{
	setBrightness(F_BRIGHTNESS0, brightness);
	setBrightness(F_BRIGHTNESS1, brightness);
	setBrightness(F_BRIGHTNESS2, brightness);
	setBrightness(F_BRIGHTNESS3, brightness);
}

static void setupUserButton()
{
	runCommand("config-pin p8.43 gpio");

	FILE *pGpioExportFile = fopen(F_EXPORT, "w");
	if (pGpioExportFile == NULL) {
		printf("ERROR OPENING %s.", F_EXPORT);
		exit(1);
	}

	int charWritten = fprintf(pGpioExportFile, "72");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	fclose(pGpioExportFile);

	sleepForMs(300);

	FILE *pUserButtonDirectionFile = fopen(F_USER_BUTTON_DIRECTION, "w");
	if (pGpioExportFile == NULL) {
		printf("ERROR OPENING %s.", F_USER_BUTTON_DIRECTION);
		exit(1);
	}

	charWritten = fprintf(pUserButtonDirectionFile, "in");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	fclose(pUserButtonDirectionFile);

	FILE *pUserButtonActiveLowFile = fopen(F_USER_BUTTON_ACTIVE_LOW, "w");
	if (pGpioExportFile == NULL) {
		printf("ERROR OPENING %s.", F_USER_BUTTON_ACTIVE_LOW);
		exit(1);
	}

	charWritten = fprintf(pUserButtonActiveLowFile, "1");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	fclose(pUserButtonActiveLowFile);
	return;
}

static void waitForButtonFallingEdge()
{
	char buttonValue = readButton();

	while (buttonValue == '1') {
		sleepForMs(1);
		buttonValue = readButton();
	}
}

static char readButton()
{
	FILE *pUserButtonValueFile = fopen(F_USER_BUTTON_VALUE, "r");
	if (pUserButtonValueFile == NULL) {
		printf("ERROR: Unable to open file (%s) for read\n", F_USER_BUTTON_VALUE);
		exit(-1);
	}

	// Read string (line)
	const int MAX_LENGTH = 2;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pUserButtonValueFile);
	
	fclose(pUserButtonValueFile);\
	return *buff;
}

static int timeResponse()
{
	long long startTime = getTimeInMs();
	char buttonValue = readButton();
	int duration = 0;

	while (buttonValue == '0') {
		sleepForMs(1);
		buttonValue = readButton();
		duration = (int)(getTimeInMs() - startTime);
		if (duration > 5000)
			break;
	}
	return duration;
}

static long long getTimeInMs(void)
{
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
	return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;
	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");

	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
			break;
		// printf("--> %s", buffer); // Uncomment for debugging
	}

	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) {
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
	}
}
