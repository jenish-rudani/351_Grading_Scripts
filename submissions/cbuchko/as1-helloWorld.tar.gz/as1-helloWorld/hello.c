#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

//static void runCommand(char* command);
void initialize();
void shutdown();
void sleepForMs(long long delayInMs);
long long getTimeInMs(void);
int getButton();
void readFromFileToScreen(char *fileName);
void display();
int randTimeInt;

int l = 1;
int test123 = 0;
int k = 1;
long long startTime = 0;
long long startTime2 = 0;
int bestScore = 5000;
int currentScore = 0;
int timeSpent = 0;
long long timeSpentPlayer = 0;

int main(void){
initialize();
printf("Hello embedded world, from Colin!\n");
printf("When LED3 light up, press the USER button!\n");


while(k == 1){

while(getButton() == 0){
sleepForMs(10);
} //wait until button is not pressed

startTime = getTimeInMs();
system("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");//light up led0
system("echo 0 > /sys/class/leds/beaglebone:green:usr1/brightness");
system("echo 0 > /sys/class/leds/beaglebone:green:usr2/brightness");
system("echo 0 > /sys/class/leds/beaglebone:green:usr3/brightness");
randTimeInt = (500 + (rand() % 2500)); //time in ms

l = 1;
timeSpent = 0;
while((getButton() == 1) && (timeSpent < 5000)){
sleepForMs(10);
timeSpent = timeSpent+10;
if (timeSpent > randTimeInt && (l==1)){
system("echo 1 > /sys/class/leds/beaglebone:green:usr2/brightness");
l = 0;
}	
}

system("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");
system("echo 1 > /sys/class/leds/beaglebone:green:usr1/brightness");
system("echo 1 > /sys/class/leds/beaglebone:green:usr2/brightness");
system("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");

timeSpentPlayer = getTimeInMs()-startTime;
if (timeSpentPlayer < randTimeInt){
printf("Too fast!\n");
currentScore = 5000;
}
else if (timeSpentPlayer >= randTimeInt){
currentScore = timeSpent - randTimeInt;
}

if (timeSpent > 4999){
printf("No input within 5s, quitting!\n");
k=0;
currentScore = 5000;
system("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");
system("echo 1 > /sys/class/leds/beaglebone:green:usr1/brightness");
system("echo 1 > /sys/class/leds/beaglebone:green:usr2/brightness");
system("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");
}

if (currentScore < bestScore){
bestScore = currentScore;
printf("New best time!\n");
}

display();




}
shutdown();
}
/*static void runCommand(char* command)
{
// Execute the shell command (output into pipe)
FILE *pipe = popen(command, "r");
// Ignore output of the command; but consume it
// so we don't get an error when closing the pipe.
char buffer[1024];
while (!feof(pipe) && !ferror(pipe)) {
if (fgets(buffer, sizeof(buffer), pipe) == NULL)
break;
printf("--> %s", buffer); // Uncomment for debugging
}
// Get the exit code from the pipe; non-zero is an error:
int exitCode = WEXITSTATUS(pclose(pipe));
if (exitCode != 0) {
perror("Unable to execute command:");
printf(" command: %s\n", command);
printf(" exit code: %d\n", exitCode);
}
}*/

void initialize(){
system("config-pin p8.43 gpio");
system("echo none > /sys/class/leds/beaglebone:green:usr0/trigger");
system("echo none > /sys/class/leds/beaglebone:green:usr2/trigger");
}

int getButton(){
char *fileName = "/sys/class/gpio/gpio72/value";
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
return (buff[0]-48);
}

void readFromFileToScreen(char *fileName){
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
printf("Read: '%d'\n", (buff[0]-48));
}

void shutdown(){
system("echo 0 > /sys/class/leds/beaglebone:green:usr0/brightness");
system("echo 0 > /sys/class/leds/beaglebone:green:usr1/brightness");
system("echo 0 > /sys/class/leds/beaglebone:green:usr2/brightness");
system("echo 0 > /sys/class/leds/beaglebone:green:usr3/brightness");
}

void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

long long getTimeInMs(void)
{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}

void display(){
printf("Best score: %dms current score: %dms\n", bestScore, currentScore);
}
