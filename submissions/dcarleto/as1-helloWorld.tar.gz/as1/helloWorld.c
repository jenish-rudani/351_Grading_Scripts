// Program to play an LED reaction game with the user on the BBG

// include packages
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdbool.h>

// DEFINES
#define BBG_USER_LINUX_PIN_NUMBER 72
#define MAX_STRING_LENGTH 1024
#define NS_PER_MS 100000
#define NS_PER_SECOND 100000000
#define MS_PER_SECOND 1000
#define SET_PIN72_AS_GPIO "config-pin p8.43 gpio"

// Declare function prototypes
static void setLedTrigger(const int led, const char state[]);
static void setLedBrightness(const int led, const char state[]);
static void initializeLeds(void);
static void turnOnAllLeds(void);
static void turnOffAllLeds(void);

static int getButtonState(const int linuxGpioNumber);
static void setPinDirection(const int linuxGpioNumber, const char direction[]);
int readFromFileToInt(char *fileName);
static void setPinAsGpio(char* command);

static void sleepForMs(const long long delayInMs);
static double generateRandomNumber(const double upperBound, const double lowerBound);
static long long getTimeInMs(void);

static long long bbgLedGame(void);

int main()
{
    // Initialize the BBG
    initializeLeds(); // Initialize the LED's on the BBG (trigger and brightness)
    long long bestReactionTime = 10000; // Initialize best reaction time to 10s

    // Set USER/BOOT pin as gpio pin on BBG (config-pin p8.43 gpio)
    setPinAsGpio(SET_PIN72_AS_GPIO);

    // Set USER/BOOT as input
    char userPinDirection[MAX_STRING_LENGTH] = "in"; 
    setPinDirection(BBG_USER_LINUX_PIN_NUMBER, userPinDirection);

    // Start the LED Game
    printf("Hello embedded world, from Daniel Carleton! \n"); // Display hello world message on screen
    while(1)
    {
        turnOffAllLeds();
        // Play one round of the LED game
        long long recentReactionTime = bbgLedGame();

        if (recentReactionTime >= 5000) // Game timed out
        {
            printf("No input within 5000 ms; quitting\n");
            turnOnAllLeds(); 
            sleepForMs(1000); // Short pause after game times out
            break;
        }
        if (recentReactionTime == -1) // if user cheated
        {
            printf("Your Reaction time was 5000 ms; Too early you cheater!");
            printf("; ");
            printf("Best time this session: %lld ms \n", bestReactionTime);
        }

        else if ( (recentReactionTime < bestReactionTime) && (recentReactionTime != -1) ) // Store the best reaction time this session
        {
            bestReactionTime = recentReactionTime;
            printf("NEW BEST TIME!\n");
        }

        if (recentReactionTime != -1) // If valid round of the game
        {
            printf("Your reaction time was %lld ms", recentReactionTime);
            printf("; ");
            printf("Best time this session: %lld ms \n", bestReactionTime);
        }

        turnOnAllLeds();
        sleepForMs(1000); // Short pause between ending current game and starting new game
    }

    turnOffAllLeds(); // Return board to a default state
    return 0; // Exit program
}

static long long getTimeInMs(void)
{
    struct timespec spec; // Create timespec struct named spec
    clock_gettime(CLOCK_REALTIME, &spec); // Get the time of the computer clock and store it in spec
    long long seconds = spec.tv_sec; 
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds/1000000; // Store the current time in milliseconds

    return milliSeconds;
}

static void sleepForMs(const long long delayInMs)
{
    long long delayNs = delayInMs * NS_PER_MS; // Delay in milliseconds
    int seconds = delayNs/NS_PER_SECOND; // Seconds of delay
    int nanoSeconds = delayNs % NS_PER_SECOND; // Nanoseconds of delay

    struct timespec reqDelay = {seconds, nanoSeconds}; // create the struct to pass to the sleep function
    nanosleep(&reqDelay, (struct timespec *) NULL); // Sleep function
}

static void setLedTrigger(const int led, const char state[])
{
    char filePath[MAX_STRING_LENGTH] = "/sys/class/leds/beaglebone:green:usr"; // start of filepath, constant for all LEDS
    char fileName[MAX_STRING_LENGTH] = "/trigger"; // Name of file

    // LED number passed in the function argument converted from int to string
    char ledNum[2];
    sprintf(ledNum, "%d", led); 

    // Concatenate string's into a total filepath
    strcat(filePath, ledNum);
    strcat(filePath, fileName);

    // define the filepath to the trigger of the selected LED
    #define TRIGGER_FILEPATH filePath

    // Pointer to have write access to the opened file
    FILE *pLedTriggerFile = fopen(TRIGGER_FILEPATH, "w");

    // If the file doesn't exist, print an error
    if (pLedTriggerFile == NULL)
    {
        printf("Error Opening %s.", TRIGGER_FILEPATH);
    }

    // Trigger determines what turns the LED on, writing none changes it to turn on via direct control
    int charWritten = fprintf(pLedTriggerFile, "none");

    // If the charWritten is less than or equal to zero, print an error
    if (charWritten <= 0)
    {
        printf("Error Writing Data.");
        exit(1);
    }

    fclose(pLedTriggerFile);
}

static void setLedBrightness(const int led, const char state[])
{
    char filePath[MAX_STRING_LENGTH] = "/sys/class/leds/beaglebone:green:usr"; // start of filepath, constant for all LEDS
    char fileName[MAX_STRING_LENGTH] = "/brightness"; // Name of file

    // LED number passed in the function argument converted from int to string
    char ledNum[MAX_STRING_LENGTH];
    sprintf(ledNum, "%d", led); 

    // Concatenate string's into a total filepath
    strcat(filePath, ledNum);
    strcat(filePath, fileName);

    // define the filepath to the trigger of the selected LED
    #define BRIGHTNESS_FILEPATH filePath

    // Pointer to have write access to the opened file
    FILE *pLedBrightnessFile = fopen(BRIGHTNESS_FILEPATH, "w");

    // If the file doesn't exist, print an error
    if (pLedBrightnessFile == NULL)
    {
        printf("Error Opening %s.", BRIGHTNESS_FILEPATH);
        exit(1);
    }

    // Turn the LED either on/off (1/0)
    int newBrightness = fprintf(pLedBrightnessFile, state);

    // If the charWritten is less than or equal to zero, print an error
    if ( (newBrightness < 0) || (newBrightness > 1) )
    {
        printf("Error Writing Data.");
    }
    
    fclose(pLedBrightnessFile);
}

static void initializeLeds(void)
{
    char triggerState[MAX_STRING_LENGTH] = "none"; // set trigger to direct control only
    char brightnessState[MAX_STRING_LENGTH] = "0"; // off

    for (int i = 0; i<4; i++)
    {
        setLedTrigger(i, triggerState);
        setLedBrightness(i, brightnessState);
    }
}

static void turnOffAllLeds(void)
{
    char brightnessState[MAX_STRING_LENGTH] = "0"; // off

    for (int i = 0; i<4; i++)
    {
        setLedBrightness(i, brightnessState);
    }
}

static void turnOnAllLeds(void)
{
    char brightnessState[MAX_STRING_LENGTH] = "1"; // on

    for (int i = 0; i<4; i++)
    {
        setLedBrightness(i, brightnessState);
    }
}

int readFromFileToInt(char *filePath) // Get the value of the USER button
{
    FILE *pFileToReadFrom = fopen(filePath, "r");

    if (pFileToReadFrom == NULL)
    {
        printf("Error: Unable to open file (%s) for read \n", filePath);
        exit(-1);
    }

    char buff[MAX_STRING_LENGTH]; // Allocate memory for the file contents
    
    // Get the value from the file
    fgets(buff, MAX_STRING_LENGTH, pFileToReadFrom); // Get the value as a string
    int buttonState = atoi(buff); // convert from string to int

    fclose(pFileToReadFrom); // close the file

    return buttonState;
}

static int getButtonState(const int linuxGpioNumber)
{
    char filePath[MAX_STRING_LENGTH] = "/sys/class/gpio/gpio"; // start of filepath, constant for all LEDS
    char fileName[MAX_STRING_LENGTH] = "/value"; // Name of file

    // LED number passed in the function argument converted from int to string
    char pinNum[MAX_STRING_LENGTH]; // Allocate memory
    sprintf(pinNum, "%d", linuxGpioNumber); 

    // Concatenate string's into a total filepath
    strcat(filePath, pinNum);
    strcat(filePath, fileName);

    int buttonState = readFromFileToInt(filePath); // get contents of file

    return buttonState;
}

static void setPinAsGpio(char* command)
{
    // Execute the shell command
    FILE *pipe = popen(command, "r");

    // Ignore output of the command, but consume it so we dont get an error when closing the pipe
    char buffer[MAX_STRING_LENGTH];

    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf(" --> %s \n", buffer); // Uncomment for debugging

        // Get the exit code from the pipe; non-zero is an error
        int exitCode = WEXITSTATUS(pclose(pipe));
        if (exitCode != 0)
        {
            perror("Unable to execute command: ");
            printf(" command: %s\n", command);
            printf(" exit code: %d\n", exitCode);
        }
    }
}

void setPinDirection(const int linuxGpioNumber, const char direction[])
{
    char filePath[MAX_STRING_LENGTH] = "/sys/class/gpio/gpio"; // start of filepath, constant for all LEDS
    char fileName[MAX_STRING_LENGTH] = "/direction"; // Name of file

    // LED number passed in the function argument converted from int to string
    char pinNum[MAX_STRING_LENGTH];
    sprintf(pinNum, "%d", linuxGpioNumber);

    // Concatenate string's into a total filepath
    strcat(filePath, pinNum);
    strcat(filePath, fileName);

    FILE *pPinDirectionFile = fopen(filePath, "w");

    if (pPinDirectionFile == NULL)
    {
        printf("Error: Unable to open file (%s) for write \n", filePath);
        exit(-1);
    }

    // Trigger determines what turns the LED on, writing none changes it to turn on via direct control
    fprintf(pPinDirectionFile, direction);

    fclose(pPinDirectionFile);
}

static double generateRandomNumber(const double upperBound, const double lowerBound)
{
    srand(time(0)); // Initialize random seed
    double randomNumber = (upperBound-lowerBound)*(double)rand()/RAND_MAX + lowerBound; // returns value between 0.5 and 5 seconds
    double randomNumberMs = MS_PER_SECOND * randomNumber; // Convert to milliseconds
    return randomNumberMs;
}

static long long bbgLedGame(void)
{
    // Game starts once user presses USER button

    // Then turn on LED0
    int numLed0 = 0;
    char led0BrightnessState[MAX_STRING_LENGTH] = "1";
    setLedBrightness(numLed0, led0BrightnessState);

    // Wait a random time between 0.5 to 5s
        // Have to check if user has pressed the button too early
    const double minWait = 0.5;
    const double maxWait = 3;
    double randomDelayMs = generateRandomNumber(minWait, maxWait);
    double elapsedWaitTime = 0.0;
    double timeIncremement = 100.0; // ms, time incremement between each check of the button
    bool cheaterFlag = 0.0;

    int userButtonState = 1; // Initialize USER button state, active low
    while (elapsedWaitTime < randomDelayMs)
    {
        sleepForMs(timeIncremement);
        userButtonState = getButtonState(BBG_USER_LINUX_PIN_NUMBER); // get the state of the user pin 
        if (userButtonState == 0) // if the button is pressed or if too much time has passed
        {
            return -1;
        }
        elapsedWaitTime = elapsedWaitTime + timeIncremement;
    }
    
    if (cheaterFlag != 1)
    {
        // Then turn on LED3
        int numLed3 = 3;
        char led3BrightnessState[MAX_STRING_LENGTH] = "1";
        setLedBrightness(numLed3, led3BrightnessState);

        // Start timer to measure reaction time
        long long startTime = getTimeInMs();
        long long elapsedTime = 0.0;
        int userButtonState = 1; // USER button is active low

        while(1)
        {
            userButtonState = getButtonState(BBG_USER_LINUX_PIN_NUMBER); // get the state of the user pin 

            elapsedTime = getTimeInMs() - startTime; // Get the current elapsed time of this round

            if ( (userButtonState == 0) || (elapsedTime > 5000) ) // if the button is pressed or if too much time has passed
            {
                return elapsedTime;
            }
        }
    }
    return -1;  
}