#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

// initialize LEDs for triggers
#define t_LED0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define t_LED1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define t_LED2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define t_LED3 "/sys/class/leds/beaglebone:green:usr3/trigger"

#define USER_BUTTON "/sys/class/gpio/gpio72/value"

// initialize LEDs for brightness
#define b_LED0 "/sys/class/leds/beaglebone:green:usr0/brightness" // at top of file
#define b_LED1 "/sys/class/leds/beaglebone:green:usr1/brightness" // at top of file
#define b_LED2 "/sys/class/leds/beaglebone:green:usr2/brightness" // at top of file
#define b_LED3 "/sys/class/leds/beaglebone:green:usr3/brightness" // at top of file

//------------------------------------------------------------------------------------

// trigger
void LED_trig(char *t_LED)
{
    FILE *pLedTriggerFile = fopen(t_LED, "w");
    if (pLedTriggerFile == NULL)
    {
        printf("ERROR OPENING %s.", t_LED);
        exit(1);
    }
    int charWritten0 = fprintf(pLedTriggerFile, "none");
    if (charWritten0 <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLedTriggerFile);
}

// brightness active high 'low'
void brightness_1(char *b_LED)
{
    FILE *pLed_brightnessFile = fopen(b_LED, "w");

    if (pLed_brightnessFile == NULL)
    {
        printf("ERROR OPENING %s.", b_LED);
        exit(1);
    }

    int charWritten1 = fprintf(pLed_brightnessFile, "1");
    if (charWritten1 <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(pLed_brightnessFile);
}

// brightness active low "0"
void brightness_0(char *b_LED)
{
    FILE *pLed_brightnessFile0 = fopen(b_LED, "w");

    if (pLed_brightnessFile0 == NULL)
    {
        printf("ERROR OPENING %s.", b_LED);
        exit(1);
    }

    int charWritten1 = fprintf(pLed_brightnessFile0, "0");
    if (charWritten1 <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(pLed_brightnessFile0);
}

//-----------------------------------------------------------------------------------

// how to get the current value of the button
int readFromFileToScreen(char *button)
{
    FILE *pFile = fopen(button, "r");
    if (pFile == NULL)
    {
        printf("ERROR: Unable to open file (%s) for read\n", button);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    // printf("Read: '%s'\n", buff);
    return atoi(buff);
}


static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

// the delay in time

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}

// to run linux commands
static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

bool is_button_pressed()
{
    return (readFromFileToScreen(USER_BUTTON) == 0);
}

//----------------------------------------------------------------------------------

int main()
{

    runCommand("config-pin p8.43 gpio");

    LED_trig(t_LED0);
    LED_trig(t_LED1);
    LED_trig(t_LED2);
    LED_trig(t_LED3);

    long long best_time = 10000;

    printf("Hello embedded world, from Ken\n");
    printf("When LED3 lights up, press the user button!\n");

    while (1)
    {
        // printf("this line is 222\n");
        // step 1 - check to see if user is pressing the button

        brightness_0(b_LED0);
        brightness_0(b_LED1);
        brightness_0(b_LED2);
        brightness_0(b_LED3);

        while (is_button_pressed())
        {
            sleepForMs(10);
        }

        // led 0 turn on, delay by 3s and then led 3 turns on

        long long random_time = (rand() % (2501)) + 500;
         



        brightness_1(b_LED0);
        sleepForMs(random_time);

        brightness_1(b_LED3);

        //  step 4. --- cheating code : hold button
        if (is_button_pressed())
        {
            long long response_sub = 5000;
            brightness_1(b_LED0);
            brightness_1(b_LED1);
            brightness_1(b_LED2);
            brightness_1(b_LED3);
            printf("Your recation time was %lld ", response_sub);
             printf(" ms;\n");

        }

        // if the button is not pressed early 
        else
        {
            long long start_time = getTimeInMs();
            // initial check for it user does not press button
            while (!is_button_pressed())
            {
                long long end_time = getTimeInMs();
                long long current_response = end_time - start_time;
                if (current_response > 5000)
                {
                    break;   
                }
                
            }
            long long new_endt = getTimeInMs();
            long long current_response = new_endt - start_time;

            // final check for it user deoes not not press button
            if (current_response > 5000)
            {
                printf("No input within 5000ms;");
                printf("quitting\n");

                LED_trig(t_LED0);
                LED_trig(t_LED1);
                LED_trig(t_LED2);
                LED_trig(t_LED3);

                brightness_0(b_LED0);
                brightness_0(b_LED1);
                brightness_0(b_LED2);
                brightness_0(b_LED3);
                exit(1);
            }
            //step 6/7
            // display response and best time 
            else
            {
                printf("Your recation time was  %lld ", current_response);
                printf("ms;");

                if (current_response < best_time)
                {
                    best_time = current_response;
                    printf("\n");
                    printf("New best time !\n");
                }

                else
                {
                    printf("best so far in game is  %lld ", best_time);
                    printf(" ms.\n");
                }
                
                // step 7
                LED_trig(t_LED0);
                LED_trig(t_LED1);
                LED_trig(t_LED2);
                LED_trig(t_LED3);

                brightness_1(b_LED0);
                brightness_1(b_LED1);
                brightness_1(b_LED2);
                brightness_1(b_LED3);

                sleepForMs(100);
                
            }
        }
    }

    return (0);
}
