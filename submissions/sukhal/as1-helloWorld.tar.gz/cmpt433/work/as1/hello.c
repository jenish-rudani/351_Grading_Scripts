#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define LED3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED0on "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1on "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2on "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3on "/sys/class/leds/beaglebone:green:usr3/brightness"
#define button_value "/sys/class/gpio/gpio72/value"

static void runCommand(char *command);
static long long getTimeInMs(void);          // get current time
static void sleepForMs(long long delayInMs); // delay time
void initledtrigger();                       // set trigger value for led to none
void initbutton();                           // initialize USER
void led_set(int led, int value);            // set led on or off
void led_all_off();                          // turn off all leds
void led_all_on();                           // turn on all leds
void printDetails();     // print current record & best record
int buttonpress();       // read value of button either 1 or 0
long long initial_time;  // start time
long long final_time;    // end time
long long response;      // time duration
long long best_response; // best time duration
static long long invalid_response_record = 5000; // no response time of 5s
int randomnumber;                                // randomly generated number
int exitGame = 0;                                // exit

int main() {
  printf("Hello embedded world, from Sukha!\n\n"); // say hi
  printf("When LED3 lights up, press the USER button!\n");
  initledtrigger(); // set led trigger value to none
  led_all_off();    // turn off all leds

  // Setup USER button and set to be GPIO pin
  runCommand("config-pin p8.43 gpio");
  initbutton();

  int loop_main = 1; // while loop variable for main
  int loop_game = 1; // while loop variable for during game

  while (loop_main == 1) {
    int but_val = buttonpress(); // read button value
    while (but_val == 1) {
      but_val = buttonpress(); // read button value
      if (!but_val) {
        break;
      }
    }
    if (!but_val) {
      // turn off all leds
      led_all_off();
      // get random number between 2500 and 500
      randomnumber = rand() % 2500 + 501;
      // turn on led0
      led_set(0, 1);
      // sleep for random number of milliseconds
      sleepForMs(randomnumber);
      if (buttonpress()) {
        response = invalid_response_record; //pressed before led3 was turned on
        led_all_on(); //turn all led on
        loop_game = 0; //skip main game and print result
      } else
        loop_game = 1;
      // turn on led3
      led_set(3, 1);
      // get initial time (start timer)
      initial_time = getTimeInMs(); 
      while (loop_game == 1) {
        if (buttonpress()) {
          // get final time
          final_time = getTimeInMs();
          // calculate response time
          response = final_time - initial_time;
          break;
        } else {
          // check if it has been 5s since start of the game
          if ((getTimeInMs() - initial_time) >= invalid_response_record) {
            response = invalid_response_record;
            loop_main = 0;
            printf("No input within 5000ms; quitting!\n");
            exitGame = 1; //exit the program
            break;
          }
        }
      }
      if (!exitGame) {
        led_all_on();
        printDetails(); //print result
      }
    }
  }
  initledtrigger(); // set led trigger value
  led_all_off();    // turn off all leds
  return 0;
}

static long long getTimeInMs(void) {
  struct timespec spec;
  clock_gettime(CLOCK_REALTIME, &spec);
  long long seconds = spec.tv_sec;
  long long nanoSeconds = spec.tv_nsec;
  long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
  return milliSeconds;
}

static void sleepForMs(long long delayInMs) {
  const long long NS_PER_MS = 1000 * 1000;
  const long long NS_PER_SECOND = 1000000000;
  long long delayNs = delayInMs * NS_PER_MS;
  int seconds = delayNs / NS_PER_SECOND;
  int nanoseconds = delayNs % NS_PER_SECOND;
  struct timespec reqDelay = {seconds, nanoseconds};
  nanosleep(&reqDelay, (struct timespec *)NULL);
}

void initledtrigger() {
  FILE *Led3TriggerFile = fopen(LED3, "w");
  if (Led3TriggerFile == NULL) {
    printf("ERROR OPENING %s.", LED3);
    exit(1);
  }

  int charWritten3 = fprintf(Led3TriggerFile, "none");
  if (charWritten3 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(Led3TriggerFile);

  FILE *Led2TriggerFile = fopen(LED2, "w");
  if (Led2TriggerFile == NULL) {
    printf("ERROR OPENING %s.", LED2);
    exit(1);
  }

  int charWritten2 = fprintf(Led2TriggerFile, "none");
  if (charWritten2 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(Led2TriggerFile);

  FILE *Led1TriggerFile = fopen(LED1, "w");
  if (Led1TriggerFile == NULL) {
    printf("ERROR OPENING %s.", LED1);
    exit(1);
  }

  int charWritten1 = fprintf(Led1TriggerFile, "none");
  if (charWritten1 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(Led1TriggerFile);

  FILE *Led0TriggerFile = fopen(LED0, "w");
  if (Led0TriggerFile == NULL) {
    printf("ERROR OPENING %s.", LED0);
    exit(1);
  }

  int charWritten0 = fprintf(Led0TriggerFile, "none");
  if (charWritten0 <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(Led0TriggerFile);
}

void initbutton() {
  FILE *pFile = fopen("/sys/class/gpio/gpio72/direction", "w");
  if (pFile == NULL) {
    printf("ERROR: Unable to open export file.\n");
    exit(1);
  }
  fprintf(pFile, "in");
  fclose(pFile);
}

int buttonpress() {
  FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
  if (pFile == NULL) {
    printf("ERROR: Unable to open file (%s) for read\n",
           "/sys/class/gpio/gpio72/value");
    exit(-1);
  }
  // Read string (line)
  const int MAX_LENGTH = 1024;
  char buff[MAX_LENGTH];
  fgets(buff, MAX_LENGTH, pFile);
  fclose(pFile);
  // convert string to int 
  int value = atoi(buff);
  value = !value;
  return value;
}

void led_set(int led, int value) {
  FILE *LedTriggerFile;
  if (led == 0) {
    LedTriggerFile = fopen(LED0on, "w");
  } else if (led == 1) {
    LedTriggerFile = fopen(LED1on, "w");
  } else if (led == 2) {
    LedTriggerFile = fopen(LED2on, "w");
  } else if (led == 3) {
    LedTriggerFile = fopen(LED3on, "w");
  }

  if (LedTriggerFile == NULL) {
    printf("ERROR OPENING %s.", LED0on);
    exit(1);
  }

  // int to string
  char str[2];
  sprintf(str, "%d", value);
  int charWritten = fprintf(LedTriggerFile, str);
  if (charWritten <= 0) {
    printf("ERROR WRITING DATA");
    exit(1);
  }
  fclose(LedTriggerFile);
}

void led_all_on() {
  led_set(0, 1);
  led_set(1, 1);
  led_set(2, 1);
  led_set(3, 1);
}

void led_all_off() {
  led_set(0, 0);
  led_set(1, 0);
  led_set(2, 0);
  led_set(3, 0);
}

void printDetails() {

  if (response < best_response || best_response == 0) {
    best_response = response;
    printf("New Record!\n");
  }
  printf("Your recation time was %lld; best so far in game is %lld\n", response,
         best_response);
}

static void runCommand(char *command) {
  // Execute the shell command (output into pipe)
  FILE *pipe = popen(command, "r");
  // Ignore output of the command; but consume it
  // so we don't get an error when closing the pipe.
  char buffer[1024];
  while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
      break;
    // printf("--> %s", buffer);  // Uncomment for debugging
  }
  // Get the exit code from the pipe; non-zero is an error:
  int exitCode = WEXITSTATUS(pclose(pipe));
  if (exitCode != 0) {
    perror("Unable to execute command:");
    printf("  command:   %s\n", command);
    printf("  exit code: %d\n", exitCode);
  }
}