// SOME CODE IS ADAPTED FROM THE ASSIGNMENT GUIDES.
// ALSO I KNOW I HAVE ALOT OF REPEATED CODE WHICH SHOULD HAVE BEEN CLEANER :(
// LIKE I KNOW I COULD HAVE MADE ONE GENERAL fopen() FUNCTION HAD I HAD MORE TIME

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define led0_brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define led1_brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define led2_brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define led3_brightness "/sys/class/leds/beaglebone:green:usr3/brightness"

#define led0_trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define led1_trigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define led2_trigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define led3_trigger "/sys/class/leds/beaglebone:green:usr3/trigger"

static void runCommand(char* command)
{
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe))
	{
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
		break;
		// printf("--> %s", buffer); // Uncomment for debugging
	}
	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0)
	{
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
	}
}

void initialize_userButton()
{
	// First we want to configure the pin as GPIO 
	runCommand("config-pin p8.43 gpio");
	
	//Next we want to set the pin to an input
	
	FILE *pInput = fopen("/sys/class/gpio/gpio72/direction","w");
	if (pInput == NULL) 
	{
		printf("ERROR: Unable to open direction file.\n");
		exit(1);
	}
	fprintf(pInput, "%s", "in");
	fclose(pInput);
	
	// Our USER button should be ready to go	
}

int readUserInput()
{
	FILE *pValue = fopen("/sys/class/gpio/gpio72/value", "r");
	if (pValue == NULL)
	{
		printf("ERROR: Unable to open value file for read\n");
		exit(1);
	}
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pValue);
	fclose(pValue);
	int x = atoi(buff);
	return x;
}

void setLedTrigger(char* led)
{		
	FILE *pLeds = fopen(led,"w");
	if (pLeds == NULL) 
	{
		printf("ERROR: Unable to open trigger file.\n");
		printf( "%s\n", led);
		exit(1);
	}
	fprintf(pLeds, "%s", "none");
	fclose(pLeds);

}

void turnLed_On_Off(char* led, int brightness)
{		
	FILE *pLeds = fopen(led,"w");
	if (pLeds == NULL) 
	{
		printf("ERROR: Unable to open brightness file.\n");
		exit(1);
	}
	fprintf(pLeds, "%d", brightness);
	fclose(pLeds);

}

void turnOffAllLeds_On_Off(int brightness)
{

	turnLed_On_Off(led0_brightness,brightness);
	turnLed_On_Off(led1_brightness,brightness);
	turnLed_On_Off(led2_brightness,brightness);
	turnLed_On_Off(led3_brightness,brightness);
}

void initialize_leds()
{
	
	setLedTrigger(led0_trigger);
	setLedTrigger(led1_trigger);
	setLedTrigger(led2_trigger);
	setLedTrigger(led3_trigger);
	
	turnOffAllLeds_On_Off(0);	
}

static void sleepForMs(long long delayInMs)
{
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;
	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
{
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
	return milliSeconds;
}

void printStatistics(long long currentScore, long long bestScore)
{
	if(currentScore<bestScore)
	{
		printf("WOW! NEW BEST TIME\n");
		printf("Your recation time was\t%lldms;\tbest so far in game is\t%lldms\n", currentScore,currentScore);
	}
	else
		printf("Your recation time was\t%lldms;\tbest so far in game is\t%lldms\n", currentScore,bestScore);

}

int main(int argc, char* args[])
{
    printf("Hello embedded world, from Keith:)\n");
    
    //First initialize our USER button and leds
    initialize_userButton();
    initialize_leds();
    long long currentScore = 5000; // just some default values
    long long bestScore = 5000;
    long long startTime = 0;
    
    //Main loop begins here
    while(1)
    {
	    //Wait while user holds down USER button
	    while(1)
	    {
	    	if(readUserInput()==1)
	    		break;
	    }
	    
	    //Light up only LED 0
	    turnOffAllLeds_On_Off(0);
	    turnLed_On_Off(led0_brightness,255);
	    
	    //Wait a random time (between 0.5s and 3.0s)
	    long long randomTime = (rand() % (2501)) + 500;
	    sleepForMs(randomTime);
	    
	    //If user is pressing the USER button already (too soon)
	    if(readUserInput()==0)
	    {
	    	currentScore = 5000;
	    }
	    else
	    {
	    	//Light up LED 3 & start timer
	    	turnLed_On_Off(led3_brightness,255);
	    	startTime = getTimeInMs();
	    	while(1)
	    	{
	    		if(getTimeInMs() - startTime > 5000)
	    		{
	    			printf("Too slow:( Goodbye \n");
	    			turnOffAllLeds_On_Off(0);
	    			return(0);
	    		}
	    		if(readUserInput()==0)
	    		{
	    			currentScore = getTimeInMs() - startTime;
	    			break;
	    		}
	    	}
	    }
	    
	    //Light up all LEDs
	    turnOffAllLeds_On_Off(255);
	    
	    //Display summary
	    printStatistics(currentScore,bestScore);
	    if(currentScore<bestScore)
	    	bestScore = currentScore;
	    	
    }
    
    return 0; //poor fella will never be executed :( how lonely
}
