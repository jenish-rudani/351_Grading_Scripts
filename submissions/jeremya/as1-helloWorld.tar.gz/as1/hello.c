#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <stdbool.h>
#define trigger "..."
#define LED_PATH "/sys/class/leds/beaglebone:green:usr"
#define LED0_PATH "/sys/class/leds/beaglebone:green:usr0"
#define LED1_PATH "/sys/class/leds/beaglebone:green:usr1"
#define LED2_PATH "/sys/class/leds/beaglebone:green:usr2"
#define LED3_PATH "/sys/class/leds/beaglebone:green:usr3"
#define GPIO72_PATH "/sys/class/gpio/gpio72/value"

static void turnOffAllLeds() 
{
	FILE *pLedBrightnessFile = fopen(LED0_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 0);
	fclose(pLedBrightnessFile);

	pLedBrightnessFile = fopen(LED1_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 0);
	fclose(pLedBrightnessFile);

	pLedBrightnessFile = fopen(LED2_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 0);
	fclose(pLedBrightnessFile);

	pLedBrightnessFile = fopen(LED3_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 0);
	fclose(pLedBrightnessFile);
}

static void turnOnAllLeds() 
{
	FILE *pLedBrightnessFile = fopen(LED0_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 1);
	fclose(pLedBrightnessFile);

	pLedBrightnessFile = fopen(LED1_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 1);
	fclose(pLedBrightnessFile);

	pLedBrightnessFile = fopen(LED2_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 1);
	fclose(pLedBrightnessFile);

	pLedBrightnessFile = fopen(LED3_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 1);
	fclose(pLedBrightnessFile);
}

static void turnOnLed0() 
{
	//char brightness[] = "/brigthness";
	//char strcat(ledPath, brightness);
	//printf("ledPath: %s\n", ledPath);
	FILE *pLedBrightnessFile = fopen(LED0_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 1);
	fclose(pLedBrightnessFile);
}

static void turnOnLed3() 
{
	//char brightness[] = "/brigthness";
	//char strcat(ledPath, brightness);
	//printf("ledPath: %s\n", ledPath);
	FILE *pLedBrightnessFile = fopen(LED3_PATH "/brightness", "w");
	fprintf(pLedBrightnessFile, "%d", 1);
	fclose(pLedBrightnessFile);
}

static void runCommand(char* command)
{
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
		break;
		//printf("--> %s", buffer); // Uncomment for debugging
	}
	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) {
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
	}
}

static long long getTimeInMs(void)
{
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
	return milliSeconds;
}

/*static void sleepForMs(long long delayInMs)
{
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;
	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
}*/

// returns 0 if btn is pressed, else 1
static int getUsrBtnValue() 
{
	FILE *pUsrBtnFile = fopen(GPIO72_PATH, "r");
	int i;
	fscanf(pUsrBtnFile, "%d", &i);
	fclose(pUsrBtnFile);
	return i;
}

static int getMaxArrayValue(int array[], int length)
{
	int maxArrayValue = array[0];

	for (int i = 0; i < length; i++) {
		//printf("array at i: %d\n", array[i]);
		if (array[i] < maxArrayValue) {
			maxArrayValue = array[i];
		}
	}
	return maxArrayValue;
}

int main(){
	printf("Hello embedded world, from Jeremy!\n\n");
	printf("When LED3 lights up, press the USER button!\n");
	
	// initializing user button to be gpio instead of default
	char command[] = "config-pin p8.43 gpio";
	runCommand(command);

	FILE *pLedTriggerFile = fopen(LED0_PATH "/trigger", "w");
	if (pLedTriggerFile == NULL) {
		printf("ERROR OPENING %s.", trigger);
		exit(1);
	}
	int charWritten = fprintf(pLedTriggerFile, "none");
	if (charWritten <= 0) {
		printf("error writing data");
		exit(1);
	}
	fclose(pLedTriggerFile);
	
	int reactTimeHistory[100];
	for (int i = 0; i < 100; i++) {
		reactTimeHistory[i] = 1000000;
	}
	int index = 0;
	while (true) {
		turnOffAllLeds();
		
		// while button is pressed
		while (getUsrBtnValue() == 0) {
			//printf("pressed\n");
		}

		// turn on LED 0
		turnOnLed0();

		// wait a random time (1.5s)
		bool earlyPress = false;
		bool isOver5s = true;
		long long waitTimeStart = getTimeInMs();
		long long waitTimeEnd = waitTimeStart + 1500;
		long long timeBtnPressed;
		long long reactTime;

		//sleepForMs(1500);
		
		// check if user presses btn early
		while (getTimeInMs() < waitTimeEnd)
		{
			if (getUsrBtnValue() == 0) {
				earlyPress = true;
			}
		}

		// turn on led3, user clicks button after led3 turns on
		if (earlyPress == false) {
			turnOnLed3();
			while (getTimeInMs() <= waitTimeEnd + 5000) {
				if (getUsrBtnValue() == 0) {
					timeBtnPressed = getTimeInMs();
					isOver5s = false;
					break;
				}
			}
		}

		// light up all leds when the game is over
		turnOnAllLeds();

		// if user early pressed, record response time as 5s
		if (earlyPress == true) {
			reactTimeHistory[index] = 5000;
			int length = sizeof(reactTimeHistory) / sizeof(reactTimeHistory[0]);
			printf("Your recation time was 5000ms;");
			printf(" best so far in game is %dms.\n", getMaxArrayValue(reactTimeHistory, length));
		}
		// if no input within 5s quit game
		else if (isOver5s == true && earlyPress == false) {
			printf("No input within 5000ms; quitting!\n");
			break;
		}
		// calculate and print the reaction time
		else {

			reactTime = timeBtnPressed - waitTimeEnd;
			reactTimeHistory[index] = reactTime;


			// see if current react time is best react time
			int length = sizeof(reactTimeHistory) / sizeof(reactTimeHistory[0]);

			if (getMaxArrayValue(reactTimeHistory, length) == reactTime)
			{
				printf("New best time!\n");
			}
			
			printf("Your reaction time was  %lldms;", reactTime);
			printf(" best so far in game is %dms.\n", getMaxArrayValue(reactTimeHistory, length));

			index++;
		}
	}
	

	return 0;
}


