#ifndef LED_H_
#define LED_H_
#include <stdlib.h>
#include <stdio.h>

void ledtrigger(char* path, char* pin);
//sets led trigger 

void ledOn(int led);
//sets a specific led to be on

void ledOnALL();
//sets all leds on

void ledOffALL();
//sets all leds off

void ledDirect();
//sets all leds to direct control

#endif