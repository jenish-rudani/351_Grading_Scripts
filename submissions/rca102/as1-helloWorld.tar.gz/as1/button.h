#ifndef BUTTON_H_
#define BUTTON_H_
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void runCommand(char* command);
//runs a command

void buttonDefine(char* path, char* pin);
//writes to file

bool buttonPress(char* fileName);
//checks certain button is pressed

void userbtnInitalize();
//assigns to let linux know to use gpio and can read

bool checkBtn();
//checks if USER button is pressed


#endif
