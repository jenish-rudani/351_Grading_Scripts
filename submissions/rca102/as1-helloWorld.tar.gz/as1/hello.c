#include <stdlib.h>
#include <stdio.h>
#include "button.h"
#include "led.h"
#include "timer.h"
#include "logic.h"

int main(){
    long long PR = 5000;
    long long current = 0;
    int loop = 0;
    Initalize();
    printf("Press button to start the game\n");
    while(loop == 0){
        current = Game();
        ledOnALL();
        if(current < PR){
            printf("New best time!\n");
            PR = current;
        }
        printf("Your reaction time was %lldms; best so far in game is %lldms.\n", current, PR);
    }
    return 0;
}
