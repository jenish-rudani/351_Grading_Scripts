#ifndef LOGIC_H_
#define LOGIC_H_
#include <stdio.h>
#include <stdlib.h>
#include "button.h"
#include "timer.h"
#include "led.h"

void Initalize();
//sets up everything

long long Game();
//plays game and returns time
#endif 