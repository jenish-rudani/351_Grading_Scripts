#include "logic.h"

void Initalize(){
    printf("Hello embedded world, from Raymond!\n");
    userbtnInitalize();
    ledDirect();
    printf("When LED3 lights up, press the USER button!\n");
}
long long Game(){
    long long StartTime = 0;
    long long activationTime = 0;
    long long responseTime = 0;
    long long startDelay = 0;
    long long endDelay = 0;
    long long errTime = 5000;
    ledOffALL();
    srand(time(NULL));
    activationTime = (rand() % 2500) + 500;
    //in ms 0+500 = 500ms or .5 seconds, 2500+500 = 3000ms or 3s
    startDelay = getTimeInMs();
    while(checkBtn() == false){
        endDelay = getTimeInMs();
        if((endDelay - startDelay) > errTime){
            printf("No input within 5000ms; quitting!\n");
            exit(1);
        }
    }
    sleepForMs(200);//for debouncing
    //while(checkBtn() == true);
    ledOn(0);
    startDelay = getTimeInMs();
    endDelay = (getTimeInMs() + activationTime);
    while(startDelay < endDelay){
        startDelay = getTimeInMs();
        if(checkBtn() == true){
            printf("Pressed button too fast\n");
            return errTime;
        }
    }
    ledOn(3);
    StartTime = getTimeInMs();
    while(checkBtn() == false){
        responseTime = getTimeInMs();
        if ((responseTime - StartTime) > 5000){
            printf("No input within 5000ms; quitting!\n");
            exit(1);
        }
    }
    responseTime = getTimeInMs();
    return(responseTime - StartTime);
}
