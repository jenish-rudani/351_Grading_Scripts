#include "led.h"

void ledtrigger(char* path, char* pin){
    FILE *pFile = fopen(path, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    int charWritten = fprintf(pFile,"%s", pin);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    // Close the file using fclose():
    fclose(pFile);
}

void ledOn(int led){
    if(led == 0)
            ledtrigger("/sys/class/leds/beaglebone:green:usr0/brightness", "1");
    else if(led == 1)
            ledtrigger("/sys/class/leds/beaglebone:green:usr1/brightness", "1");
    else if(led == 2)
            ledtrigger("/sys/class/leds/beaglebone:green:usr2/brightness", "1");
    else if(led == 3)
            ledtrigger("/sys/class/leds/beaglebone:green:usr3/brightness", "1");
}

void ledOnALL(){
    ledtrigger("/sys/class/leds/beaglebone:green:usr0/brightness", "1");
    ledtrigger("/sys/class/leds/beaglebone:green:usr1/brightness", "1");
    ledtrigger("/sys/class/leds/beaglebone:green:usr2/brightness", "1");
    ledtrigger("/sys/class/leds/beaglebone:green:usr3/brightness", "1");
}

void ledOffALL(){
    ledtrigger("/sys/class/leds/beaglebone:green:usr0/brightness", "0");
    ledtrigger("/sys/class/leds/beaglebone:green:usr1/brightness", "0");
    ledtrigger("/sys/class/leds/beaglebone:green:usr2/brightness", "0");
    ledtrigger("/sys/class/leds/beaglebone:green:usr3/brightness", "0");
}

void ledDirect(){
    ledtrigger("/sys/class/leds/beaglebone:green:usr0/trigger", "none");
    ledtrigger("/sys/class/leds/beaglebone:green:usr1/trigger", "none");
    ledtrigger("/sys/class/leds/beaglebone:green:usr2/trigger", "none");
    ledtrigger("/sys/class/leds/beaglebone:green:usr3/trigger", "none");
    ledOffALL();
}