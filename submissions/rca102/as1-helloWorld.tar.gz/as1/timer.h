#ifndef TIMER_H_
#define TIMER_H_
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

long long getTimeInMs();
//get current time

void sleepForMs(long long delayInMs);
//wait a number of ms


#endif
