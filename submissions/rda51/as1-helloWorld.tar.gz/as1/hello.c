#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>

static void runCommand(char* command);
static long long getTimeInMs (void);
static void sleepForMs(long long delayInMs);
static void turnOffAllLeds();
static void turnOnAllLeds();
static void setTriggerToNone();
static int finalCheckTime(long long time);

int check = 1;
int skipRestOfGame = 1;
long long bestTime = 0;

int main() 
{
    int i = 0;
    setTriggerToNone();
    turnOffAllLeds();

    char* command = "config-pin p8.43 gpio";
    runCommand(command);
    
    printf("Hello embedded world, from Ruth!\n");
    printf("\n");
    printf("Once LED3 lights up, press the user button to record your reaction speed!! Press to early and you're automatically slow :(\n\n");

    while (i == 0) {
        turnOffAllLeds();
        sleepForMs(1000);

        //Turning on LED0
        FILE *bFile0 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
        if (bFile0 == NULL) {
            printf("ERROR: Unable to open export file.\n");
            exit(1);
        }
        fprintf(bFile0, "1");
        fclose(bFile0);

        const int MAX = 1024;
        char value[MAX];
        value[0] = 49;

        printf("GO!!\n\n");

        //Opening value file to check to see if user pressed the button before the delay begins
        //and if they do, we skip to lighting up the LEDS and setting a penalty of 5s reaction time. 
        FILE *uFile = fopen("/sys/class/gpio/gpio72/value", "r");
        if (uFile == NULL) {
            printf("ERROR: Unable to open export file.\n");
            exit(1);
        }
        fgets(value, MAX, uFile);
        fclose(uFile);

        if (value[0] == 48) {
            skipRestOfGame = 2;
        } else {
            value[0] = 49;
        }

        long long delay = (rand() % (3000 - 500 + 1)) + 500;
        sleepForMs(delay);

        //Opening value file again to check to see if user pressed the button right after the delay ends
        //and if they do, we skip to lighting up the LEDS and setting a penalty of 5s reaction time. 
        uFile = fopen("/sys/class/gpio/gpio72/value", "r");
        if (uFile == NULL) {
            printf("ERROR: Unable to open export file.\n");
            exit(1);
        }
        fgets(value, MAX, uFile);
        fclose(uFile);

        if (value[0] == 48) {
            skipRestOfGame = 2;
        } else {
            value[0] = 49;
        }

        //Lighting up LED3 to begin timer
        FILE *bFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
        if (bFile3 == NULL) {
            printf("ERROR: Unable to open export file.\n");
            exit(1);
        }
        fprintf(bFile3, "1");
        fclose(bFile3);

        long long startTime = getTimeInMs();
        long long endTime = 0;
        long long timerTotal = 0;

        //If condition to see if user had pressed the button before LED3 lights up
        if (skipRestOfGame == 1) {
            const int MAX1 = 1024;
            char value2[MAX1];
            value2[0] = 49;

            //loop that runs the timer to see when the user presses the button
            while (value2[0] != 48) {
                FILE *uFile = fopen("/sys/class/gpio/gpio72/value", "r");
                if (uFile == NULL) {
                    printf("ERROR: Unable to open export file.\n");
                    exit(1);
                }
                fgets(value2, MAX1, uFile);
                fclose(uFile);

                endTime = getTimeInMs();
                timerTotal = endTime - startTime;
                
                //condition below checks to see if 5sec has passed, if so it breaks from the loop and goes to finalCheckTime function where
                //for time greater than 5s, i is set to 1 and we exit the loop of the game to quit the game
                if (timerTotal >= 5000) {
                    break;
                }
            }
            check = 1;

            //check is a variable used to make sure the game doesn't skip to the final step before the user has a chance to play the game
            if (check == 1) {
                i = finalCheckTime(timerTotal);
            }
        } else {
            //If user had pressed the button before LED3 lights up, timer is set to 0 which in our finalCheckTime function sets the penalty
            i = finalCheckTime(0);
        }
        
    }
    
    turnOffAllLeds();
    return 0;
}

//Function below deals with setting the best time and displaying the reaction time of the current round
//Deals with whether or not time is greater than 5sec or if button was pressed before LED3
static int finalCheckTime(long long time)
{
    int i = 0;
    if (time >= 5000) {
        printf("Oops, way too slow ;)!!\n\n");
        i = 1;
    } else if (time == 0) {
        turnOnAllLeds();
        printf("You hit the user button before LED3 lit up:(\n Penalty: your reaction time is 5000ms. The best time was %lldms.\n\n", bestTime);
        sleepForMs(1000);
        skipRestOfGame = 1;
    } else {
        turnOnAllLeds();
        if (time < bestTime || bestTime == 0) {
            bestTime = time;
        }
        printf("Your reaction time was %lldms, the best time is %lldms!\n\n", time, bestTime);
        sleepForMs(1000);
    }
    check = 0;
    return i;
}

//Sets the trigger of all the LEDS to none
static void setTriggerToNone()
{
    FILE *tFile0 = fopen("/sys/class/leds/beaglebone:green:usr0/trigger", "w");
    if (tFile0 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(tFile0, "none");
    fclose(tFile0);

    FILE *tFile1 = fopen("/sys/class/leds/beaglebone:green:usr1/trigger", "w");
    if (tFile1 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(tFile1, "none");
    fclose(tFile1);

    FILE *tFile2 = fopen("/sys/class/leds/beaglebone:green:usr2/trigger", "w");
    if (tFile2 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(tFile2, "none");
    fclose(tFile2);

    FILE *tFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/trigger", "w");
    if (tFile3 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(tFile3, "none");
    fclose(tFile3);
}

//Turns of all the LEDS
static void turnOffAllLeds()
{
    FILE *bFile1 = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
    if (bFile1 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile1, "0");
    fclose(bFile1);

    FILE *bFile2 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
    if (bFile2 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile2, "0");
    fclose(bFile2);

    FILE *bFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
    if (bFile3 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile3, "0");
    fclose(bFile3);

    FILE *bFile0 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
    if (bFile0 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile0, "0");
    fclose(bFile0);
}

//Turns on all the LEDS
static void turnOnAllLeds() 
{
    FILE *bFile1 = fopen("/sys/class/leds/beaglebone:green:usr1/brightness", "w");
    if (bFile1 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile1, "1");
    fclose(bFile1);

    FILE *bFile2 = fopen("/sys/class/leds/beaglebone:green:usr2/brightness", "w");
    if (bFile2 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile2, "1");
    fclose(bFile2);

    FILE *bFile3 = fopen("/sys/class/leds/beaglebone:green:usr3/brightness", "w");
    if (bFile3 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile3, "1");
    fclose(bFile3);

    FILE *bFile0 = fopen("/sys/class/leds/beaglebone:green:usr0/brightness", "w");
    if (bFile0 == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    fprintf(bFile0, "1");
    fclose(bFile0);

}

//Three of these functions below were provided by Dr. Brian
static void runCommand(char* command)
{
    //Execute the shell command (output into the pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        printf("--> %s", buffer);
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf("  command:   %s\n", command);
        printf("  exit code: %d\n", exitCode);
    }

    return;
}

static long long getTimeInMs (void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNS = delayInMs * NS_PER_MS;
    int seconds = delayNS / NS_PER_SECOND;
    int nanoseconds = delayNS % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);

}
