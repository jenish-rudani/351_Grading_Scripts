#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdbool.h>

#define TRIGGER_ZERO "/sys/class/leds/beaglebone:green:usr0/trigger"
#define TRIGGER_ONE "/sys/class/leds/beaglebone:green:usr1/trigger"
#define TRIGGER_TWO "/sys/class/leds/beaglebone:green:usr2/trigger"
#define TRIGGER_THREE "/sys/class/leds/beaglebone:green:usr3/trigger"
#define BRIGHTNESS_ZERO "/sys/class/leds/beaglebone:green:usr0/brightness"
#define BRIGHTNESS_ONE "/sys/class/leds/beaglebone:green:usr1/brightness"
#define BRIGHTNESS_TWO "/sys/class/leds/beaglebone:green:usr2/brightness"
#define BRIGHTNESS_THREE "/sys/class/leds/beaglebone:green:usr3/brightness"
#define USR_BUTTON_DIRECTION "/sys/class/gpio/gpio72/direction"
#define USR_BUTTON_VALUE "/sys/class/gpio/gpio72/value"

void initializeLEDs(void);
void initializeTriggers(void);
void initializeButton(void);
void setBrightness(int brZero, int brOne, int brTwo, int brThree);
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
static int setRandomNum (int lowLimitMs, int highLimitMs);
static void runCommand(char* command);
int readFile(char *fileName);
bool gameOn = true;

int main()
{
    initializeLEDs();
    initializeButton();
    printf("---------------------------------------\n");
    printf("Hello embedded world, from Amir Eghbal!\n");
    printf("---------------------------------------\n");
    printf("When LED3 lights up, press the USER button!\n");
    int firstIterationFlag = 0; 
    long long responseTime = 0;
    long long bestTime;
    while(gameOn == true)
    {
        setBrightness(1,0,0,0);
        srand(time(0));
        int randomTime = setRandomNum (500, 3000);
        int waitTimeIndex = 0;
        int earlyPressFlag = 0;
        while(((waitTimeIndex < randomTime)) && (earlyPressFlag == 0))
        {
            sleepForMs(1);
            if (readFile(USR_BUTTON_VALUE) == 0)
            {
                if (firstIterationFlag == 0)
                {
                    bestTime = 5000;
                    printf("New best time!\n");
                }
                printf("You pressed the button too early. Reaction time recorded is 5000 ms; best so far in game is %lld ms.\n", bestTime);
                firstIterationFlag = 1;
                setBrightness(1,1,1,1);
                while(readFile(USR_BUTTON_VALUE) == 0)
                {

                }
                earlyPressFlag = 1;
            }
            waitTimeIndex++;
        }
        if (earlyPressFlag == 0)
        {
            setBrightness (0,0,0,1);
            long long startTime = getTimeInMs();
            long long elapsedTime = 0;
            int doneIterationFlag = 0;
            while ((elapsedTime < 5000) && (doneIterationFlag == 0))
            {
                long long endTime;
                elapsedTime = getTimeInMs() - startTime;
                if (readFile(USR_BUTTON_VALUE) == 0)
                {
                endTime = getTimeInMs();
                responseTime = endTime - startTime;
                if (firstIterationFlag == 0)
                    {
                        bestTime = responseTime;
                        printf("New best time!\n");
                    }
                    if (responseTime < bestTime)
                    {
                        bestTime = responseTime;
                        printf("New best time!\n");
                    }
                    printf("Your reaction time was %lld ms; best so far in game is %lld ms.\n", responseTime, bestTime);
                    firstIterationFlag = 1;
                    setBrightness(1,1,1,1);
                    while(readFile(USR_BUTTON_VALUE) == 0)
                    {

                    }
                    doneIterationFlag = 1;
                }
            }
            if (elapsedTime >= 5000)
            {
                printf("No input within 5000ms; quitting!\n");
                setBrightness(0,0,0,0);
                exit(1);
            }
        }
    }
    return EXIT_SUCCESS;
}

void initializeLEDs(void)
{
    initializeTriggers();
    setBrightness(0,0,0,0);
}

void initializeTriggers(void)
{
    FILE *pLedTriggerZero = fopen(TRIGGER_ZERO, "w");
    FILE *pLedTriggerOne = fopen(TRIGGER_ONE, "w");
    FILE *pLedTriggerTwo = fopen(TRIGGER_TWO, "w");
    FILE *pLedTriggerThree = fopen(TRIGGER_THREE, "w");
    if (pLedTriggerZero== NULL)
    {
        printf("Error opening %s." , TRIGGER_ZERO);
        exit(1);
    }
    if (pLedTriggerOne== NULL)
    {
        printf("Error opening %s." , TRIGGER_ONE);
        exit(1);
    }
    if (pLedTriggerTwo== NULL)
    {
        printf("Error opening %s." , TRIGGER_TWO);
        exit(1);
    }
    if (pLedTriggerThree== NULL)
    {
        printf("Error opening %s." , TRIGGER_THREE);
        exit(1);
    }

    int trigZeroWrite = fprintf(pLedTriggerZero, "none");
    int trigOneWrite = fprintf(pLedTriggerOne, "none");
    int trigTwoWrite = fprintf(pLedTriggerTwo, "none");
    int trigThreeWrite = fprintf(pLedTriggerThree, "none");
    if(trigZeroWrite <= 0 ||  trigOneWrite <= 0 || trigTwoWrite <= 0 || trigThreeWrite <= 0)
    {
        printf("Error writing data to one of the trigger files");
        exit(1);
    }
    fclose(pLedTriggerZero);
    fclose(pLedTriggerOne);
    fclose(pLedTriggerTwo);
    fclose(pLedTriggerThree);
}

void initializeButton(void)
{
    runCommand ("config-pin p8.43 gpio");
    // Use fopen() to open the file for write access.
    FILE *pFile = fopen(USR_BUTTON_DIRECTION, "w");
    if (pFile == NULL) {
    printf("ERROR: Unable to open direction file.\n");
    exit(1);
    }
    // Write to data to the file using fprintf():
    fprintf(pFile, "%s", "in");
    // Close the file using fclose():
    fclose(pFile);
}

void setBrightness(int brZero, int brOne, int brTwo, int brThree)
{
    FILE *pLedBrightnessZero = fopen(BRIGHTNESS_ZERO, "w");
    FILE *pLedBrightnessOne = fopen(BRIGHTNESS_ONE, "w");
    FILE *pLedBrightnessTwo = fopen(BRIGHTNESS_TWO, "w");
    FILE *pLedBrightnessThree = fopen(BRIGHTNESS_THREE, "w");
    if (pLedBrightnessZero== NULL)
    {
        printf("Error opening %s." , BRIGHTNESS_ZERO);
        exit(1);
    }
    if (pLedBrightnessOne== NULL)
    {
        printf("Error opening %s." , BRIGHTNESS_ONE);
        exit(1);
    }
    if (pLedBrightnessTwo== NULL)
    {
        printf("Error opening %s." , BRIGHTNESS_TWO);
        exit(1);
    }
    if (pLedBrightnessThree== NULL)
    {
        printf("Error opening %s." , BRIGHTNESS_THREE);
        exit(1);
    }

    int briZeroWrite = fprintf(pLedBrightnessZero, "%d", brZero);
    int briOneWrite = fprintf(pLedBrightnessOne, "%d", brOne);
    int briTwoWrite = fprintf(pLedBrightnessTwo, "%d", brTwo);
    int briThreeWrite = fprintf(pLedBrightnessThree, "%d", brThree);
    if(briZeroWrite <= 0 ||  briOneWrite <= 0 || briTwoWrite <= 0 || briThreeWrite <= 0)
    {
        printf("Error writing data to one of the brightness files");
        exit(1);
    }

    fclose(pLedBrightnessZero);
    fclose(pLedBrightnessOne);
    fclose(pLedBrightnessTwo);
    fclose(pLedBrightnessThree);
}
static long long getTimeInMs(void)

{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

static int setRandomNum (int lowLimitMs, int highLimitMs)
{
    int randNum = (rand() % (highLimitMs - lowLimitMs + 1)) + lowLimitMs;
    return randNum;
}

static void runCommand(char* command)
{
// Execute the shell command (output into pipe)
FILE *pipe = popen(command, "r");
// Ignore output of the command; but consume it
// so we don't get an error when closing the pipe.
char buffer[1024];
while (!feof(pipe) && !ferror(pipe)) {
if (fgets(buffer, sizeof(buffer), pipe) == NULL)
break;
printf("--> %s", buffer); // Uncomment for debugging
}
// Get the exit code from the pipe; non-zero is an error:
int exitCode = WEXITSTATUS(pclose(pipe));
if (exitCode != 0) {
perror("Unable to execute command:");
printf(" command: %s\n", command);
printf(" exit code: %d\n", exitCode);
}
}

int readFile(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
//Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
//Close
fclose(pFile);
int theValue = atoi(buff);
return(theValue);
}