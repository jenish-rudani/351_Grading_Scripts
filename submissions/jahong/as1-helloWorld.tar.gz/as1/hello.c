#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#define TRIGGER_FILE_LED_0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define TRIGGER_FILE_LED_1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define TRIGGER_FILE_LED_2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define TRIGGER_FILE_LED_3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define BRIGHTNESS_FILE_LED_0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define BRIGHTNESS_FILE_LED_1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define BRIGHTNESS_FILE_LED_2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define BRIGHTNESS_FILE_LED_3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define GPIO_72_Value "/sys/class/gpio/gpio72/value"
#define GPIO_72_Direction "/sys/class/gpio/gpio72/direction"

//Author: Jason Hong 301343629
//Date: October 5, 2022
//Description of Assignment 1: A game where when LED3 is turned on, you try to click the USER button the fastest. The program will keep track of your best time and change your current time to 5s
//if you happen to press the button too early. Program will exit if you don't click a button for over 5 seconds.

//List of all the Functions Used

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

//Opens directory export and writes "in" for GPIO Direction
static void writeToGPIO_Direction_Input(void)

{

    // Use fopen() to open the file for write access.
    FILE *pFile = fopen("/sys/class/gpio/export", "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    // Write to data to the file using fprintf():
    fprintf(pFile, "in");
    // Close the file using fclose():
    fclose(pFile);
    // Call nanosleep() to sleep for ~300ms before use.


}
// Reads the line in the directory "/sys/class/gpio/gpio72/value" and returns the value which is either '0' or '1'
static char gettingValueFromFileToScreen(char *fileNameUSED)
{

    FILE *pFile = fopen(fileNameUSED, "r");
    if (pFile == NULL){
        printf("ERROR: Unable to open file (%s) for read\n", fileNameUSED);
        exit(-1);

    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    return buff[0];
    
}


//Supplied by Brian Fraser
static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
    break;
    // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

//Used to get current time in milliseconds
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

static void initializeTriggerFile(char *TRIGGER_FILE)
{
    FILE *pLedTriggerFile = fopen(TRIGGER_FILE, "w");
    
    //Checking if fopen succeeded

    if(pLedTriggerFile == NULL)
    {

        printf("ERROR OPENING %s.", TRIGGER_FILE);
        exit(1);
    }

    int charWritten = fprintf(pLedTriggerFile, "none");
    if (charWritten <= 0)
    {

        printf("ERROR WRITING DATA");
        exit(1);

    }

    // Closing the trigger file
    fclose(pLedTriggerFile);

}
// Used for controlling the LEDS to turn on
static void initializeBrightnessFile(char *BRIGHTNESS_FILE)
{
    // Opening the brightness file

    FILE *pLedBrightnessFile = fopen(BRIGHTNESS_FILE, "w");

    //Checking if fopen succeeded

    if(pLedBrightnessFile == NULL)
    {

        printf("ERROR OPENING %s.", BRIGHTNESS_FILE);
        exit(1);
    }

    //Turning the brightness on
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "1");
    if (charWrittenBrightness <= 0)
    {

        printf("ERROR WRITING DATA");
        exit(1);
    }

    //Closing the Brightness file
    fclose(pLedBrightnessFile);

}
// Used for controlling the LEDS to turn off
static void initializeBrightnessFile_OFF(char *BRIGHTNESS_FILE)
{
    // Opening the brightness file

    FILE *pLedBrightnessFile = fopen(BRIGHTNESS_FILE, "w");

    //Checking if fopen succeeded

    if(pLedBrightnessFile == NULL)
    {

        printf("ERROR OPENING %s.", BRIGHTNESS_FILE);
        exit(1);
    }

    //Turning the brightness off
    int charWrittenBrightness = fprintf(pLedBrightnessFile, "0");
    if (charWrittenBrightness <= 0)
    {

        printf("ERROR WRITING DATA");
        exit(1);
    }

    //Closing the Brightness file
    fclose(pLedBrightnessFile);

}

// Initialize all the brightness files to off
static void initializeBrightnessFile_OFF_ALL(void)
{

    initializeBrightnessFile_OFF(BRIGHTNESS_FILE_LED_0);
    initializeBrightnessFile_OFF(BRIGHTNESS_FILE_LED_1);
    initializeBrightnessFile_OFF(BRIGHTNESS_FILE_LED_2);
    initializeBrightnessFile_OFF(BRIGHTNESS_FILE_LED_3); 

}

// Initialize all the brightness files to on
static void initializeBrightnessFile_ON_ALL(void)
{

    initializeBrightnessFile(BRIGHTNESS_FILE_LED_0);
    initializeBrightnessFile(BRIGHTNESS_FILE_LED_1);
    initializeBrightnessFile(BRIGHTNESS_FILE_LED_2);
    initializeBrightnessFile(BRIGHTNESS_FILE_LED_3); 

}

// Initialize all the trigger files to 'none' for every LED
static void initializeTriggerFile_ALL(void)
{

    initializeTriggerFile(TRIGGER_FILE_LED_0);
    initializeTriggerFile(TRIGGER_FILE_LED_1);
    initializeTriggerFile(TRIGGER_FILE_LED_2);
    initializeTriggerFile(TRIGGER_FILE_LED_3);

}



int main(int argc, char **argv)

{

    // Setting the trigger to 'none' for all LEDs
    initializeTriggerFile_ALL();


    // Setting all LED's off
    initializeBrightnessFile_OFF_ALL();

    // Configuring USER button
    runCommand("config-pin p8.43 gpio");
    sleepForMs(100);
    writeToGPIO_Direction_Input();
    sleepForMs(100);


    printf("Hello embedded world, from Jason!\n\n");

    printf("When LED3 lights up, press the USER button!\n");

  

    int inGame = 0;
    long long gettingTimeElapsed = 0;
    long long gettingTime = 0;
    long long gettingTime2 = 0;
    long long currentTime = 0;
    long long bestTime = 5000;
    char valueOfButton = '0';
    long long randomNumber = 0;

    while(inGame == 0)
    {
        // Initializing and turning all LED off
        initializeBrightnessFile_OFF_ALL();



        // Turning LED 0 on

        initializeBrightnessFile(BRIGHTNESS_FILE_LED_0);


        //Waiting a random time between 0.5 to 3s.
        randomNumber = rand() % (3000 +1 - 500) + 500;
        sleepForMs(randomNumber);

        valueOfButton = gettingValueFromFileToScreen(GPIO_72_Value);
        

        if(valueOfButton == '0'){

            //Button is pressed too early
            currentTime = 5000;
            

            //Turning on all LEDs
            initializeBrightnessFile_ON_ALL();

            //Delay so you can see the lights all flash up
            sleepForMs(1000);
            
            //printf("You pressed the button too early \n");

            printf("Your current time is %lldms; Your best time is %lldms\n", currentTime, bestTime);

            
        }

        //Lighting up LED 3 
        initializeBrightnessFile(BRIGHTNESS_FILE_LED_3);
        
        //Starting Timer
        gettingTime = getTimeInMs();


        //Checking if user is not pressing button: '1' means off, '0' means on
            
        while(valueOfButton == '1')
        {
            
            char valueOfButton = gettingValueFromFileToScreen(GPIO_72_Value);
                
            
            // Used in equation to check elapsed time
            gettingTime2 = getTimeInMs();

            // Calculating the elapsed time
            gettingTimeElapsed = (gettingTime2 - gettingTime);

            // Wait until user clicks button and stop time
            if(valueOfButton == '0') 
            {
                
                gettingTime2 = getTimeInMs();

                // Getting the time the user takes to hit button
                gettingTimeElapsed = (gettingTime2 - gettingTime);

                // Turning on all LEDS
                initializeBrightnessFile_ON_ALL();


                //Delay so you can see the lights all flash up
                sleepForMs(1000);

                    
                currentTime = gettingTimeElapsed;
                if(currentTime < bestTime){
                    //updating best Time
                    bestTime = currentTime;

                }
                printf("Your current time is %lldms; Your best time is %lldms\n", currentTime, bestTime);

                break;

                    

            }
            // Checking if you didn't press the button and exceed 5000 milliseconds without pressing the button.
            if(valueOfButton == '1' && gettingTimeElapsed > 5000)
            {

                printf("No input within 5000ms. Exiting \n");
                    
                //Before exiting setting trigger for all LED to 0
                initializeTriggerFile_ALL();


                //Turning off all the LED
                initializeBrightnessFile_OFF_ALL();

                exit(1);

            }

            

        }


        
    }

    return 0;

}