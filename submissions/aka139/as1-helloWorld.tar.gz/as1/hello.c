//Assignment1 - This code runs a game with all the detailed instructions provided. (SFU ID-301404918)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define LED0_path "/sys/class/leds/beaglebone:green:usr0"
#define LED1_path "/sys/class/leds/beaglebone:green:usr1"
#define LED2_path "/sys/class/leds/beaglebone:green:usr2"
#define LED3_path "/sys/class/leds/beaglebone:green:usr3"
#define user_path "/sys/class/gpio/gpio72/value"

static void runCommand(char* command)
{
 FILE *pipe = popen(command, "r");
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 }
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}

int readFromFileToScreen(char *fileName)
{
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
	printf("ERROR: Unable to open file (%s) for read\n", fileName);
	exit(-1);
	}
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	fclose(pFile);
	//printf("Read: '%s'\n", buff);
	return atoi(buff);
}

void turn_all_on(){
	FILE *pLed0BrightnessFile = fopen(LED0_path "/brightness", "w");
	if (pLed0BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED0_path);
		exit(1);
	}
	int charbWritten = fprintf(pLed0BrightnessFile, "1");
	if (charbWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed0BrightnessFile);
	
	FILE *pLed1BrightnessFile = fopen(LED1_path "/brightness", "w");
	if (pLed1BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED1_path);
		exit(1);
	}
	int charb1Written = fprintf(pLed1BrightnessFile, "1");
	if (charb1Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed1BrightnessFile);
	
	FILE *pLed2BrightnessFile = fopen(LED2_path "/brightness", "w");
	if (pLed2BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED2_path);
		exit(1);
	}
	int charb2Written = fprintf(pLed2BrightnessFile, "1");
	if (charb2Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed2BrightnessFile);
	
	FILE *pLed3BrightnessFile = fopen(LED3_path "/brightness", "w");
	if (pLed3BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED3_path);
		exit(1);
	}
	int charb3Written = fprintf(pLed3BrightnessFile, "1");
	if (charb3Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed3BrightnessFile);
}

void turn_all_off()
{
	FILE *pLed0BrightnessFile = fopen(LED0_path "/brightness", "w");
	if (pLed0BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED0_path);
		exit(1);
	}
	int charbWritten = fprintf(pLed0BrightnessFile, "0");
	if (charbWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed0BrightnessFile);
	
	FILE *pLed1BrightnessFile = fopen(LED1_path "/brightness", "w");
	if (pLed1BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED1_path);
		exit(1);
	}
	int charb1Written = fprintf(pLed1BrightnessFile, "0");
	if (charb1Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed1BrightnessFile);
	
	FILE *pLed2BrightnessFile = fopen(LED2_path "/brightness", "w");
	if (pLed2BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED2_path);
		exit(1);
	}
	int charb2Written = fprintf(pLed2BrightnessFile, "0");
	if (charb2Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed2BrightnessFile);
	
	FILE *pLed3BrightnessFile = fopen(LED3_path "/brightness", "w");
	if (pLed3BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED3_path);
		exit(1);
	}
	int charb3Written = fprintf(pLed3BrightnessFile, "0");
	if (charb3Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed3BrightnessFile);
}

void turn_led0on ()
{
	FILE *pLed0BrightnessFile = fopen(LED0_path "/brightness", "w");
	if (pLed0BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED0_path);
		exit(1);
	}
	int charbWritten = fprintf(pLed0BrightnessFile, "1");
	if (charbWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed0BrightnessFile);
}

void turn_led3on ()
{
	FILE *pLed3BrightnessFile = fopen(LED3_path "/brightness", "w");
	if (pLed3BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED3_path);
		exit(1);
	}
	int charb3Written = fprintf(pLed3BrightnessFile, "1");
	if (charb3Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed3BrightnessFile);
}

void trigger_all()
{
	FILE *pLed0TriggerFile = fopen(LED0_path "/trigger" , "w");
	if (pLed0TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED0_path);
		exit(1);
	}
	int charWritten = fprintf(pLed0TriggerFile, "heartbeat");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed0TriggerFile);
	
	FILE *pLed1TriggerFile = fopen(LED1_path "/trigger", "w");
	if (pLed1TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED1_path);
		exit(1);
	}
	int char1Written = fprintf(pLed1TriggerFile, "heartbeat");
	if (char1Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed1TriggerFile);
	
	FILE *pLed2TriggerFile = fopen(LED2_path "/trigger", "w");
	if (pLed2TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED2_path);
		exit(1);
	}
	int char2Written = fprintf(pLed2TriggerFile, "heartbeat");
	if (char2Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed2TriggerFile);
	
	FILE *pLed3TriggerFile = fopen(LED3_path "/trigger", "w");
	if (pLed3TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED3_path);
		exit(1);
	}
	int char3Written = fprintf(pLed3TriggerFile, "heartbeat");
	if (char3Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed3TriggerFile);
}

void trigger_none()
{
	FILE *pLed0TriggerFile = fopen(LED0_path "/trigger" , "w");
	if (pLed0TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED0_path);
		exit(1);
	}
	int charWritten = fprintf(pLed0TriggerFile, "none");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed0TriggerFile);
	
	FILE *pLed1TriggerFile = fopen(LED1_path "/trigger", "w");
	if (pLed1TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED1_path);
		exit(1);
	}
	int char1Written = fprintf(pLed1TriggerFile, "none");
	if (char1Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed1TriggerFile);
	
	FILE *pLed2TriggerFile = fopen(LED2_path "/trigger", "w");
	if (pLed2TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED2_path);
		exit(1);
	}
	int char2Written = fprintf(pLed2TriggerFile, "none");
	if (char2Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed2TriggerFile);
	
	FILE *pLed3TriggerFile = fopen(LED3_path "/trigger", "w");
	if (pLed3TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED3_path);
		exit(1);
	}
	int char3Written = fprintf(pLed3TriggerFile, "none");
	if (char3Written <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(pLed3TriggerFile);
}

static void sleepForMs(long long delayInMs)
{
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
 return milliSeconds;
}

int main() 
{
	runCommand("config-pin p8.43 gpio");
	runCommand("echo 72 > export");
	int n =0;//n is later used so that during the first iteration best_reaction_time = actual reaction_time
	long long best_reaction_time;
	long long reaction_time;
	printf("Hello embedded world, from Arminder! \n\n");
	trigger_all(); // triggering to heartbeat so that user gets a sense that he can press the user button now

	while(readFromFileToScreen(user_path) == 1)
	{
		//the button is not pressed yet so it keeps looping with leds flashing
	}
	printf("When LED3 lights up, press the USER button!\n");
	printf("New best time!\n");
	while(1)
	{
		n++;
		turn_all_off();//These 2 lines help turn only led0 on since these are immediate, it works fine
		turn_led0on();
		long long random_time = (rand() % (3000 - 500 + 1)) + 500;
		sleepForMs(random_time);
		if(readFromFileToScreen(user_path) == 0)//checks if user cheated i.e. pressed the user button during wait time
		{	
			reaction_time = 5000;
		}
		else
		{
			long long reaction_time1 = getTimeInMs();
			turn_led3on();
			long long t1 = getTimeInMs();
			while(readFromFileToScreen(user_path) != 0)//waiting user to press the button
			{
				long long t2 = getTimeInMs();
				if (t2 - t1 > 5000)
				{
					printf("No input within 5000ms; quitting!\n");
					trigger_none();
					turn_all_off();
					exit(1);
				}
			}
			long long reaction_time2 = getTimeInMs();
			reaction_time = reaction_time2 - reaction_time1;
			if (n==1)
			{
				best_reaction_time = reaction_time;
			}
			else{
			if(reaction_time < best_reaction_time)
			{
				printf("New best time!\n");
				best_reaction_time = reaction_time;
			}
			}
		}
		turn_all_on();
		printf("Your reaction time was %lld;",reaction_time);
		printf(" best so far in game is %lld.\n",best_reaction_time);
		long long delay = (rand() % (300 - 50+ 1)) + 50;//added delay to clearly see all leds turn on
		sleepForMs(delay);
	}
	return 0;
}