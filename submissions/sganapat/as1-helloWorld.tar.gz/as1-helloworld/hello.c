#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

/* Function Declarations */
static void sleepForMs(long long delayInMs);
static void runCommand(char* command);
static void LED_init(char *fileName);
static void LED_bright(char *fileName, bool ledstatus);
static long long getTimeInMs(void);
static int readFromFileToVar(char *fileName);

/* MACRO DECLARATIONS*/
#define LED0 "/sys/class/leds/beaglebone:green:usr0"
#define LED1 "/sys/class/leds/beaglebone:green:usr1"
#define LED2 "/sys/class/leds/beaglebone:green:usr2"
#define LED3 "/sys/class/leds/beaglebone:green:usr3"

#define TRIGGER "/trigger"
#define BRIGHTNESS "/brightness"

#define GPIO "/sys/class/gpio"
#define USERBTN	"/gpio72"
#define VALUETAG "/value"

/* VARIABLE DECLARATIONS */


/* Main Role is shown below*/
int main(void){
	// Greetings
	printf("Hello embedded world, from SRINATH GANAPATHY!!!\n");
	LED_init(LED0 TRIGGER); 
	LED_init(LED1 TRIGGER); 
	LED_init(LED2 TRIGGER); 
	LED_init(LED3 TRIGGER); 

	// Game Instructions
	//printf("Press the 'USER' button to start the game.");
	printf("When LED3 Lights Up, press the 'USER' button.\n");

	runCommand("config-pin p8.43 gpio");
	runCommand("echo 72 > " GPIO "/export");
	//runCommand("cd " GPIO USERBTN);
	//runCommand("echo 1 > active_low");

	// Declare Locally applicable variables
	long long start_time = 0;	// start time
	long long end_time = 0;		// end time
	int high_score = 5000;		// ms
	int delta_time = 5000;			// ms
	
	int delayms_time = 3000;	// ms
	//bool quit_game = false;		// flag to quit game
	bool false_start = false;	// fast start flag

	while(true){
		if(readFromFileToVar(GPIO USERBTN VALUETAG) == 1){
			sleepForMs(500); // Delay to read again

			while(readFromFileToVar(GPIO USERBTN VALUETAG) == 1){
				sleepForMs(400); // Wait until the button is released			
			}

			// Turn ONLY LED0
			LED_bright(LED0 BRIGHTNESS,true);
			
			// Get Random waiting time
			delayms_time = (rand() % 2500) + 500;
			while((delayms_time > 3000) && (delayms_time < 500)){
				delayms_time = (rand() % 2500) + 500;
			}

			// Wait prior to starting game
			false_start = false;
			//printf("%d\n\n",delayms_time);
			sleepForMs(delayms_time);

			// Start the game LED3 is on; LED0 is off; timer on
			//		check to see USER button is on.
			LED_bright(LED0 BRIGHTNESS,false); 
			LED_bright(LED3 BRIGHTNESS,true);

			if(readFromFileToVar(GPIO USERBTN VALUETAG) == 1){
				false_start = true;
			}
			start_time = getTimeInMs(); end_time = getTimeInMs();
			delta_time = end_time - start_time;

			while (delta_time <= 5000) {
				if(readFromFileToVar(GPIO USERBTN VALUETAG) == 1){
					break;
				}
				end_time = getTimeInMs();
				delta_time = end_time - start_time;
			}

			// Print exit message and leave if reaction is > 5s
			if (delta_time > 5000){
				//quit_game = true;
				printf("No input within 5000ms; quitting!!!\n");
				break;
			}
			
			// Continue with game and provide result:
			LED_bright(LED0 BRIGHTNESS,true); LED_bright(LED1 BRIGHTNESS,true);
			LED_bright(LED2 BRIGHTNESS,true); LED_bright(LED3 BRIGHTNESS,true);

			// False Start Scenario; when current score < high_score update
			if (false_start == true){
				delta_time = 5000;
			} else {
				if (delta_time < high_score){
					printf("\nNew best time!\n");
					high_score = delta_time;
				}
			}

			printf("Your reaction time was %d ms; best so far in game is %d ms!\n",delta_time,high_score);

			sleepForMs(3000);
			LED_bright(LED0 BRIGHTNESS,false); LED_bright(LED1 BRIGHTNESS,false);
			LED_bright(LED2 BRIGHTNESS,false); LED_bright(LED3 BRIGHTNESS,false);
			false_start = false;
		}
		sleepForMs(300);
	}

	LED_bright(LED0 BRIGHTNESS,false); LED_bright(LED1 BRIGHTNESS,false);
	LED_bright(LED2 BRIGHTNESS,false); LED_bright(LED3 BRIGHTNESS,false);
	runCommand("echo 72 > " GPIO "/unexport");
	sleepForMs(500);
	return 0;
}

static void sleepForMs(long long delayInMs){
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;
	
	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command){
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
			break;
	// printf("--> %s", buffer); // Uncomment for debugging
	}
	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) {
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
	}
}

static long long getTimeInMs(void){
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000
	+ nanoSeconds / 1000000;
	return milliSeconds;
}

static void LED_init(char *fileName){
	FILE *pLedTriggerFile = fopen(fileName, "w");
	if (pLedTriggerFile == NULL) {
		printf("ERROR OPENING %s.", fileName);
		exit(-1);
	}
	
	int charWritten = fprintf(pLedTriggerFile, "none");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(-1);
	}
	fclose(pLedTriggerFile);
}

static void LED_bright(char *fileName, bool ledstatus){
	FILE *pLedBrightnessFile = fopen(fileName, "w");
	
	if (pLedBrightnessFile == NULL) {
		printf("ERROR OPENING %s.", fileName);
		exit(-1);
	}
	
	int charWritten =0;
	if (ledstatus == true){
		charWritten = fprintf(pLedBrightnessFile, "1");
	} else {
		charWritten = fprintf(pLedBrightnessFile, "0");
	}
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(-1);
	}
	
	fclose(pLedBrightnessFile);	
}

static int readFromFileToVar(char *fileName){	
	// Use fopen() to open the file for read access.
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
		printf("ERROR: Unable to open file for reading.\n");
		exit(-1);
	}
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	fclose(pFile);

	if (strcmp("1",buff)==true){
		//printf("clicked");
		//printf("1");
		return 1;
	} else {
		//printf("0");
		//printf("unclicked\n");
		return 0;
	}
}
