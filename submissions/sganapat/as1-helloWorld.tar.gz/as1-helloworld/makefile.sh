#!/bin/sh
arm-linux-gnueabihf-gcc -Wall -g -std=c99 -D _POSIX_C_SOURCE=200809L -Werror hello.c -o submithello
cp submithello ${HOME}/cmpt433/public/myApps/
