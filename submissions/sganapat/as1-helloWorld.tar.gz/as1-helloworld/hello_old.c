#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

/* Function Declarations */
static void sleepForMs(long long delayInMs);
static void readFromFileToScreen(char *fileName);
static void runCommand(char* command);
static void LED_init(char *fileName);
static void LED_bright(char *fileName, bool ledstatus);
static long long getTimeInMs(void);
void writetoGPIO30(); //Only writes to GPIO-30

/* MACRO DECLARATIONS*/
#define LED0 "/sys/class/leds/beaglebone:green:usr0"
#define LED1 "/sys/class/leds/beaglebone:green:usr1"
#define LED2 "/sys/class/leds/beaglebone:green:usr2"
#define LED3 "/sys/class/leds/beaglebone:green:usr3"

#define TRIGGER "/trigger"
#define BRIGHTNESS "/brightness"

#define GPIO "/sys/class/gpio"
#define USERBTN	"/gpio72"
#define VALUETAG "/value"

/* VARIABLE DECLARATIONS */


/* Main Role is shown below*/
int main(void){
	long long start_time = getTimeInMs();
	long long end_time = 0;

	// Initialize LEDs
	LED_init(LED0 TRIGGER); LED_init(LED1 TRIGGER);
	LED_init(LED2 TRIGGER); LED_init(LED3 TRIGGER); 
    printf("Hello embedded world, from SRINATH GANAPATHY!!!\n");
	sleepForMs(1500);

	// Set LEDs on for a few seconds
	LED_bright(LED0 BRIGHTNESS,true); 
	LED_bright(LED1 BRIGHTNESS,true);
	LED_bright(LED2 BRIGHTNESS,true); 
	LED_bright(LED3 BRIGHTNESS,true); 
	sleepForMs(2000);

	// turn off all leds
	LED_bright(LED0 BRIGHTNESS,false); 
	LED_bright(LED1 BRIGHTNESS,false);
	LED_bright(LED2 BRIGHTNESS,false); 
	LED_bright(LED3 BRIGHTNESS,false);
	sleepForMs(2000);

	// Initializing 'USER BUTTON'
	runCommand("cd ${HOME}");
	runCommand("cd " GPIO);
	runCommand("echo 72 > unexport");
	sleepForMs(500);
	runCommand("echo 72 > export");
	sleepForMs(500);
	runCommand("cd " GPIO USERBTN);
	runCommand("echo 1 > active_low");
	sleepForMs(500);

	for(int j = 0; j < 10; j++){
		readFromFileToScreen(GPIO USERBTN VALUETAG);
		sleepForMs(1000);
	}

	runCommand("echo 72 > unexport");
	sleepForMs(500);

	// Identify if the timer is functionning as it should.
	end_time = getTimeInMs();
	double delta_time = (end_time - start_time)/1000;
	printf("The start time is: %llu.\n", start_time);
	printf("The end time is: %llu.\n", end_time);
	printf("A total time of: %f.\n", delta_time);

	return 0;
}

static void sleepForMs(long long delayInMs){
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;
	
	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void readFromFileToScreen(char *fileName){
	// Use fopen() to open the file for read access.
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
		printf("ERROR: Unable to open file for reading.\n");
		exit(-1);
	}

	// Read string (line)
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);

	// Close the file using fclose():
	fclose(pFile);

	printf("Read: '%s' \n", buff);
}

static void runCommand(char* command){
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
		if (fgets(buffer, sizeof(buffer), pipe) == NULL)
			break;
	// printf("--> %s", buffer); // Uncomment for debugging
	}
	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) {
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitCode);
	}
}

static long long getTimeInMs(void){
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000
	+ nanoSeconds / 1000000;
	return milliSeconds;
}

static void LED_init(char *fileName){
	FILE *pLedTriggerFile = fopen(fileName, "w");
	if (pLedTriggerFile == NULL) {
		printf("ERROR OPENING %s.", fileName);
		exit(-1);
	}
	
	int charWritten = fprintf(pLedTriggerFile, "none");
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(-1);
	}
	fclose(pLedTriggerFile);
}

static void LED_bright(char *fileName, bool ledstatus){
	FILE *pLedBrightnessFile = fopen(fileName, "w");
	
	if (pLedBrightnessFile == NULL) {
		printf("ERROR OPENING %s.", fileName);
		exit(-1);
	}
	
	int charWritten =0;
	if (ledstatus == true){
		charWritten = fprintf(pLedBrightnessFile, "1");
	} else {
		charWritten = fprintf(pLedBrightnessFile, "0");
	}
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(-1);
	}
	
	fclose(pLedBrightnessFile);	
}

void writetoGPIO30(){
	// Use fopen() to open the file for write access.
	FILE *pFile = fopen("/sys/class/gpio/export", "w");

	if (pFile == NULL) {
		printf("ERROR: Unable to open export file.\n");
		exit(-1);
	}

	// Write to data to the file using fprintf():
	fprintf(pFile, "%d", 30);

	// Close the file using fclose():
	fclose(pFile);
}