#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define trigger0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define trigger1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define trigger2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define trigger3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define brightness0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define brightness1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define brightness2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define brightness3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define USERbuttonValue "/sys/class/gpio/gpio72/value"
#define USERbuttonDirection "/sys/class/gpio/gpio72/direction"

static int readButtonValue(char *filename);
static void writeToButtons(char *filename, const char* value);
static void initializeLEDTriggers(char *filename);
static void turnOffLED(char *filename);
static void turnOnLED(char *filename);
static long long getTime(void);
static int sleepForTime(long long delayInMS);
static void runCommand(char* command);

int main(int arg, char* args[])
{
    // display message
    printf("Hello embedded world, from Rose!\n");
    // configure USER button to be gpio
    runCommand("config-pin p8.43 gpio");
    // configure USER button to be input
    writeToButtons(USERbuttonDirection, "in");
    // setting all LED triggers to "none"
    initializeLEDTriggers(trigger0);
    initializeLEDTriggers(trigger1);
    initializeLEDTriggers(trigger2);
    initializeLEDTriggers(trigger3);
    // turing all LEDs off at beginning
    turnOffLED(brightness0);
    turnOffLED(brightness1);
    turnOffLED(brightness2);
    turnOffLED(brightness3);

    int delayTime;
    long long responseTime, startTime, minResponseTime;
    time_t startCountdownTime, endCountdownTime;
    long long responseTimeArray[100];
    int iterationCount = 0;
    printf("\nWhen LED3 lights up, press the USER button!\n");
    
    int buttonValue = readButtonValue(USERbuttonValue);
    while(1) {
        // button not pressed yet
        if(buttonValue == 0) {
            while(1) {
                // button released
                if(buttonValue == 1) {
                    // if button released (buttonValue = 1) then play game
                    break;
                }
                else {
                    buttonValue = readButtonValue(USERbuttonValue);
                    sleepForTime(5); // delay to read file
                    continue;
                }
            }
        }
        else {
            buttonValue = readButtonValue(USERbuttonValue);
            sleepForTime(5); // delay to read file
            continue;
        }
        // enter game
        // turning on LED0
        turnOnLED(brightness0);
        // wait a random time from 0.5s to 3.0s
        delayTime = rand() % 2500 + 501;
        sleepForTime(delayTime);
        // turn on LED3
        turnOnLED(brightness3);
        // read buttonsto check if user pressed
        buttonValue = readButtonValue(USERbuttonValue);
        // user pressed button too quick
        if(buttonValue == 0) { 
            responseTime = 5000;
            continue;
        }
        // button not pressed
        else {
            // start timer
            startTime = getTime();
            // countdown timer for 5s
            time(&startCountdownTime);
            do {
                time(&endCountdownTime);
                if(buttonValue == 0) { // button pressed
                    // stop timer & get time
                    responseTime = getTime() - startTime; 
                    break;
                }
                else {
                    // wait for user to press button
                    buttonValue = readButtonValue(USERbuttonValue);
                    sleepForTime(50);
                    continue;
                }
            }
            while(difftime(endCountdownTime, startCountdownTime) < 5);
        }

        if(difftime(endCountdownTime, startCountdownTime) >= 5) {
            // end game no input
            printf("No inpput withing 5000ms; quiting!\n");
            initializeLEDTriggers(trigger0);
            initializeLEDTriggers(trigger1);
            initializeLEDTriggers(trigger2);
            initializeLEDTriggers(trigger3);
            turnOffLED(brightness0);
            turnOffLED(brightness1);
            turnOffLED(brightness2);
            turnOffLED(brightness3);
            exit(1);
        }
        // light up all LEDs
        turnOnLED(brightness1);
        turnOnLED(brightness2);  
        // assign response times to array
        responseTimeArray[iterationCount] = responseTime;
        minResponseTime = responseTimeArray[0];
        // finding smallest response time
        if(iterationCount > 0) {
            for(int c = 0; c <= iterationCount; c++) {
                if(responseTimeArray[c] < minResponseTime) {
                minResponseTime = responseTimeArray[c];
                }
            }
        }
        iterationCount++;
        // display summary
        printf("Your reaction time was \t%lldms;", responseTime);
        printf("\tbest so far in game is \t%lldms\n", minResponseTime); 
        turnOffLED(brightness0);
        turnOffLED(brightness1);
        turnOffLED(brightness2);
        turnOffLED(brightness3); 
    }
    // end
    initializeLEDTriggers(trigger0);
    initializeLEDTriggers(trigger1);
    initializeLEDTriggers(trigger2);
    initializeLEDTriggers(trigger3);
    turnOffLED(brightness0);
    turnOffLED(brightness1);
    turnOffLED(brightness2);
    turnOffLED(brightness3);
    
    return 0;
}

static void initializeLEDTriggers(char *filename)
{
    // setting triggers
    // opening trigger file
    FILE *pLedTriggerFile = fopen(filename, "w");
    // checkin that fopen() call is successful
    if(pLedTriggerFile == NULL) {
        printf("ERROR OPENING %s.", filename);
        exit(1);
    }

    // writing to trigger file
    int charWritten = fprintf(pLedTriggerFile, "none");
    // checking that fprintf() is successful at writing to files
    if(charWritten <= 0) {
        printf("ERROR WRTING DATA");
        exit(1);
    }
    // closing trigger files
    fclose(pLedTriggerFile);
}

static void turnOffLED(char *filename)
{
    // setting brightness
    FILE *pLedBrightnessFile = fopen(filename, "w");
    // checkin that fopen() call is successful
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", filename);
        exit(1);
    }

    // writing to trigger file
    int charWritten = fprintf(pLedBrightnessFile, "0");
    if(charWritten <= 0) {
        printf("ERROR WRTING DATA");
        exit(1);
    }
    // closing brightnes files
    fclose(pLedBrightnessFile);
}

static void turnOnLED(char *filename)
{
    FILE *pLedBrightnessFile = fopen(filename, "w");
    // checkin that fopen() call is successful
    if(pLedBrightnessFile == NULL) {
        printf("ERROR OPENING %s.", filename);
        exit(1);
    }
    int charWritten = fprintf(pLedBrightnessFile, "1");
    if(charWritten <= 0) {
        printf("ERROR WRTING DATA");
        exit(1);
    }
    // closing brightness file
    fclose(pLedBrightnessFile);
}

static int readButtonValue(char *filename)
{
    FILE *pFile = fopen(filename, "r");
    if(pFile == NULL) {
        printf("ERROR: Unable to open file (%s).\n", filename);
        exit(1);
    }
    // reading line
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // retrieving button value to return
    int value;
    sscanf(buff, "%d", &value);
    return value;
    // close
    fclose(pFile);
}

static void writeToButtons(char *filename, const char* value)
{
    // open the file
    FILE *pFile = fopen(filename, "w");
    if(pFile == NULL) {
        printf("ERROR: Unable to open export file.\n");
        exit(1);
    }
    // write value to the file
    fprintf(pFile, "%s", value);
    // close the file
    fclose(pFile);
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // ignore output of command
    char buffer[1024];
    while(!feof(pipe) && !ferror(pipe)) {
        if(fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
    }
    // get exit coe from pipe, non-zero is error
    int exitCode = WEXITSTATUS(pclose(pipe));
    if(exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command %s\n",command);
        printf(" exit code: %d\n", exitCode);
    }
}

static long long getTime(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static int sleepForTime(long long delayInMS)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNS = delayInMS * NS_PER_MS;
    int seconds = delayNS / NS_PER_SECOND;
    int nanoseconds = delayNS % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    return nanosleep(&reqDelay, (struct timespec *) NULL);
}

