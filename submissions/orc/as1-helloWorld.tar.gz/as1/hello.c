#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

float RandomBetween(void) 
{
    srand((long long)getTimeInMs());
    double x = ((double)rand()) / ((double)RAND_MAX) * 2.5 + 0.5;
    return x * 1000;
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

int readFromFileToInput()
{
    char *fileName = "/sys/class/gpio/gpio72/value";
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL)
    {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    // convert string to int
    int value = atoi(buff);
    return !value;
}

int main(void)
{
    runCommand("config-pin p8.43 gpio");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr0/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr1/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr2/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr3/trigger");
    printf("Hello embedded world, from Owen!\n");
    bool gameactive = true;
    long long bestT = 5000;
    while(gameactive) 
    {
        runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr1/brightness");
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr2/brightness");
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr3/brightness");
        long long waitTime = RandomBetween();
        long long waitedTime = 0;
        long long difT = 0;
        bool earlypress = false;
        while(waitedTime < waitTime){
            sleepForMs(100);
            waitedTime += 100;          
            if(readFromFileToInput() == 1) {
                difT = 5000;
                earlypress = true;
                break;
            }
        }
        if (earlypress == false)
        {
            runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");
            long long initialT = getTimeInMs();
            while(difT < 5000) 
            {
                difT = getTimeInMs() - initialT;
                if (difT >= 5000)
                {
                    gameactive = false;
                }
                if(readFromFileToInput() == 1) 
                {
                    break;
                }
            }
        }
        if(gameactive != false)
        {
            while(readFromFileToInput() == 1){
                continue;
            }
            if(difT < bestT) {
                bestT = difT;
            }
            runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");
            runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr1/brightness");
            runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr2/brightness");
            runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");
            printf("Your reaction time was %dms; best so far this game is %dms \n", (int)difT, (int)bestT);
        }


    }
    /*
    Loop until timer is greater than 5s 

    wait while user holds down USER button
    Light up only LED 0
    Wait a random time (between 0.5s and 3.0s)
    If user is pressing the USER button already (too soon):
    - Record response time as 5.0s
    - Skip to "Light up all LEDs"
    Light up LED 3 & start timer
    When user presses USER button, stop timer
    - if timer > 5s, exit with a message w/o waiting for button press
    Light up all LEDs
    Display summary:
    - How many ms was the current response time?
    - How many ms is the best response time so far this game?

    */

    printf("No input within 5000ms; quitting!\n\n");
    return 0;
}