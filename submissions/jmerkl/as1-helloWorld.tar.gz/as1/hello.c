/*
-------------------------------------------------------------------------------------------------
Jake Merkl
STU#: 301398265
ENSC351
Assignment 1

Desc:
Test reaction time of a user within 0.5-3sec,.
-------------------------------------------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//LED0
#define TriggerZero "/sys/class/leds/beaglebone:green:usr0/trigger"
#define BrightnessZero "/sys/class/leds/beaglebone:green:usr0/brightness"
//LED1
#define TriggerOne "/sys/class/leds/beaglebone:green:usr1/trigger"
#define BrightnessOne "/sys/class/leds/beaglebone:green:usr1/brightness"
//LED2
#define TriggerTwo "/sys/class/leds/beaglebone:green:usr2/trigger"
#define BrightnessTwo "/sys/class/leds/beaglebone:green:usr2/brightness"
//LED3
#define TriggerThree "/sys/class/leds/beaglebone:green:usr3/trigger"
#define BrightnessThree "/sys/class/leds/beaglebone:green:usr3/brightness"
//USER button
#define User "/sys/class/gpio/gpio72/value"

//GPIO set commands
#define ButtonGPIOsetup "config-pin p8.43 gpio"
#define gotoButtonPath "cd /sys/class/gpio/gpio72"
#define SetButtonAsInput "echo in > direction"



void LedHIGH(char *brightness)
{
    FILE *pLedBrightnessFile = fopen(brightness, "w");

    if (pLedBrightnessFile == NULL) {
    printf("ERROR OPENING %s.", brightness);
    exit(1);
    }    

    int BcharWritten = fprintf(pLedBrightnessFile, "1");

    //WriteBrightnessCheck
if (BcharWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLedBrightnessFile);


}

void LedLOW(char *brightness)
{
    FILE *pLedBrightnessFile = fopen(brightness, "w");

    if (pLedBrightnessFile == NULL) {
    printf("ERROR OPENING %s.", brightness);
    exit(1);
    }    

    int BcharWritten = fprintf(pLedBrightnessFile, "0");

    //WriteBrightnessCheck
if (BcharWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLedBrightnessFile);


}


void LedSetup(char *brightness, char *trigger)
{

FILE *pLedTriggerFile = fopen(trigger, "w");
FILE *pLedBrightnessFile = fopen(brightness, "w");


//OpenTriggerCheck
if (pLedTriggerFile == NULL) {
    printf("ERROR OPENING %s.", trigger);
    exit(1);
    }    

//Write
int TcharWritten = fprintf(pLedTriggerFile, "none");

//OpenBrightnessCheck
if (pLedBrightnessFile == NULL) {
    printf("ERROR OPENING %s.", brightness);
    exit(1);
    }    

//Write
int BcharWritten = fprintf(pLedBrightnessFile, "0");



//WriteTriggerCheck
if (TcharWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLedTriggerFile);

//WriteBrightnessCheck
if (BcharWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLedBrightnessFile);


}


static long long getTimeInMs(void) //Get current time
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}

static void sleepForMs(long long delayInMs) //wait certain amount of ms
{
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}


static void runCommand(char* command) // run a linux command
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}


int getButtonStatus()
{

int status;
FILE *pFile = fopen(User, "r");

if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", User);
exit(-1);
}

// Read string (line)
const int MAX_LENGTH = 1024;
char buttonstatus[MAX_LENGTH];
fgets(buttonstatus, MAX_LENGTH, pFile);

// Close
fclose(pFile);
sscanf(buttonstatus, "%d", &status);

return status;
    
}

int main()
{

    runCommand(ButtonGPIOsetup);
    runCommand(gotoButtonPath);
    runCommand(SetButtonAsInput);

    LedSetup(BrightnessZero, TriggerZero);
    LedSetup(BrightnessOne, TriggerOne);
    LedSetup(BrightnessTwo, TriggerTwo);
    LedSetup(BrightnessThree, TriggerThree);

printf("Hello embedded world, from Jake!\n\n");
printf("When LED3 lights up, press the USER button!\n");

while(1){
   
   if(getButtonStatus()){           //if button is being held down

    LedHIGH(BrightnessZero);
    LedLOW(BrightnessOne);
    LedLOW(BrightnessTwo);
    LedLOW(BrightnessThree);

   }else if(!getButtonStatus()){    //if button is not being held down


    LedLOW(BrightnessZero);
    LedLOW(BrightnessOne);
    LedLOW(BrightnessTwo);
    LedLOW(BrightnessThree);

    //Game Start countdown
    sleepForMs(2000);

    LedHIGH(BrightnessZero);

    sleepForMs(2000);

    LedHIGH(BrightnessOne);

    sleepForMs(2000);

    LedHIGH(BrightnessTwo);

    sleepForMs((rand() % 3000 + 500));

    LedHIGH(BrightnessThree);
    long long time0 = getTimeInMs();

    while(1){

        long long TimeElapsed = getTimeInMs()-time0;

        if(getButtonStatus()){

            long long time1 = getTimeInMs();
            long long ReactionTime = time1-time0;
            long long BestTime;

            if(ReactionTime<0.001){
                if(BestTime>100000) {//First Run

                    BestTime = 5000;
                    printf("Your reaction time was 5000ms; Your best reaction time so far is %lldms\n", BestTime);
                    break;

                }else{

                    printf("Your reaction time was 5000ms; Your best reaction time so far is %lldms\n", BestTime);
                    break;

                }
            }else {

                if(ReactionTime<BestTime){

                    BestTime = ReactionTime;
                    printf("New High Score!!\n");
                    printf("Your reaction time was: %lldms; Best so far in game is %lldms\n", ReactionTime, BestTime);
                    break;

                }else{
                    printf("Your reaction time was: %lldms ; Your best reaction time so far is : %lldms\n", ReactionTime, BestTime);
                    break;
                    }
                }
    
    }else if(!getButtonStatus() && (TimeElapsed >= 5000)){

        printf("No input within 5000ms! quitting . . .\n\n");
        LedLOW(BrightnessZero);
        LedLOW(BrightnessOne);
        LedLOW(BrightnessTwo);
        LedLOW(BrightnessThree);
        return 0;

    }

   }

}else {
    printf("Uh oh... Looks like something unexpected happened!\nSystem Shutting down. . .\n");

    LedLOW(BrightnessZero);
    LedLOW(BrightnessOne);
    LedLOW(BrightnessTwo);
    LedLOW(BrightnessThree);

    break;
   }


}

LedLOW(BrightnessZero);
LedLOW(BrightnessOne);
LedLOW(BrightnessTwo);
LedLOW(BrightnessThree);

return 0;

}
