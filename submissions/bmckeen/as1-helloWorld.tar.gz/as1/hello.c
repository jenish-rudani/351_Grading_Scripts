#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#include <sys/wait.h>
#include <stdlib.h>

#define LED0_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED0_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED1_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED2_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED3_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr3/brightness"
#define GPIO_72_VALUE_FILE_NAME "/sys/class/gpio/gpio72/value"
#define GPIO_72_DIRECTION_FILE_NAME "/sys/class/gpio/gpio72/direction"

static int testReactionTime();
static void runCommand(char* command);
static int writeToFile(char* filePath, char* message);
static int readGPIOValue(char* filePath);
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);

static int writeToFile(char* filePath, char* message) {
	FILE *file = fopen(filePath, "w");
	
	if (file == NULL) {
		printf("ERROR OPENING FILE: %s\n", filePath);
		return 1;
	}
	
	int charsWritten = fprintf(file, message);
	
	fclose(file);
	
	if (charsWritten < 0) {
		printf("ERROR WRITING TO FILE: %s\n", filePath);
		return 1;
	} else {
		return 0;
	}
}

static int readGPIOValue(char* filePath) {
	FILE *file = fopen(filePath, "r");
	int gpioValue = 0;
	
	if (file == NULL) {
		printf("ERROR OPENING FILE: %s\n", filePath);
		return 1;
	}
	
	int charsRead = fscanf(file, "%d", &gpioValue);
	
	fclose(file);
	
	if (charsRead < 0) {
		printf("ERROR READING FILE: %s\n", filePath);
		return -1;
	} else {
		return gpioValue;
	}
}

static void runCommand(char* command)
{
 	// Execute the shell command (output into pipe)
 	FILE *pipe = popen(command, "r");
 	// Ignore output of the command; but consume it
 	// so we don't get an error when closing the pipe.
 	char buffer[1024];
 	while (!feof(pipe) && !ferror(pipe)) {
 	if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 		break;
 	// printf("--> %s", buffer); // Uncomment for debugging
 	}
 	// Get the exit code from the pipe; non-zero is an error:
 	int exitCode = WEXITSTATUS(pclose(pipe));
 	if (exitCode != 0) {
 		perror("Unable to execute command:");
 		printf(" command: %s\n", command);
 		printf(" exit code: %d\n", exitCode);
 	}	
}

static long long getTimeInMs(void) {
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
	return milliSeconds;
}

static void sleepForMs(long long delayInMs) {
	const long long NS_PER_MS = 1000 * 1000;
 	const long long NS_PER_SECOND = 1000000000;
 	long long delayNs = delayInMs * NS_PER_MS;
 	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;
	struct timespec reqDelay = {seconds, nanoseconds};
	nanosleep(&reqDelay, (struct timespec *) NULL);

}

static int testReactionTime() {
	int startTime = 0;
	int currentTime = 0;
	
	int randomWaitTime = (rand() % 2500) + 500;
	sleepForMs(randomWaitTime); //wait for random time between 0.5s and 3s
	if (readGPIOValue(GPIO_72_VALUE_FILE_NAME) == 0) {//button pressed
		return 5000;
	}
	if (writeToFile(LED3_BRIGHTNESS_FILE_NAME, "1") != 0) {
		return 1;
	}
	startTime = getTimeInMs();

	while (true) {
		currentTime = getTimeInMs();
		if (readGPIOValue(GPIO_72_VALUE_FILE_NAME) == 0) {//button pressed
			return currentTime - startTime;
		}

		if (currentTime - startTime > 5000) {
			// 5000ms has elapsed with no input
			return 0;
		}
	}
}

int main() {
	int bestReactionTime = 5000;
	int reactionTime = 0;

	printf("Hello embedded world, from Brayden\n\n");
	
	if (writeToFile(LED0_TRIGGER_FILE_NAME, "none") != 0) {
		return 1;
	}
	
	if (writeToFile(LED0_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(LED1_TRIGGER_FILE_NAME, "none") != 0) {
		return 1;
	}
	
	if (writeToFile(LED1_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(LED2_TRIGGER_FILE_NAME, "none") != 0) {
		return 1;
	}
	
	if (writeToFile(LED2_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(LED3_TRIGGER_FILE_NAME, "none") != 0) {
		return 1;
	}
	
	if (writeToFile(LED3_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(GPIO_72_DIRECTION_FILE_NAME, "in") != 0) {
		return 1;
	}
	
	runCommand("config-pin p8.43 gpio");
	
	printf("When LED3 lights up, press the USER button\n");
	
	srand(time(0));

	while (true) {
		while (readGPIOValue(GPIO_72_VALUE_FILE_NAME) == 0) { 
		}
		
		if (writeToFile(LED0_BRIGHTNESS_FILE_NAME, "1") != 0) {
			return 1;
		}
		if (writeToFile(LED1_BRIGHTNESS_FILE_NAME, "0") != 0) {
			return 1;
		}
		if (writeToFile(LED2_BRIGHTNESS_FILE_NAME, "0") != 0) {
			return 1;
		}
		if (writeToFile(LED3_BRIGHTNESS_FILE_NAME, "0") != 0) {
			return 1;
		}
		
		reactionTime = testReactionTime();
		
		if (writeToFile(LED0_BRIGHTNESS_FILE_NAME, "1") != 0) {
			return 1;
		}
		if (writeToFile(LED1_BRIGHTNESS_FILE_NAME, "1") != 0) {
			return 1;
		}
		if (writeToFile(LED2_BRIGHTNESS_FILE_NAME, "1") != 0) {
			return 1;
		}
		if (writeToFile(LED3_BRIGHTNESS_FILE_NAME, "1") != 0) {
			return 1;
		}
		
		if (reactionTime == 0) {
			printf("No input within 5000ms; Quitting\n");
			break;

		}

		if (reactionTime < bestReactionTime) {
			bestReactionTime = reactionTime;
			printf("New best time!\n");
		}
		printf("Your reaction time was %dms; best so far is %dms\n", reactionTime, bestReactionTime);
	}
	
	if (writeToFile(LED0_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(LED1_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(LED2_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	
	if (writeToFile(LED3_BRIGHTNESS_FILE_NAME, "0") != 0) {
		return 1;
	}
	return 0;
}
