//Nimrat Gill
//note: couldn't get my code to work properly so commented out stuff 
//so that it would atleast compile and be executable

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>


#define trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define led0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define led3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define gpio "/sys/class/gpio/gpio47/value"

/*void brightness(char *file, int val){
    FILE*pLedBrightnessFile = fopen(file,"w");
    if (pLedBrightnessFile == NULL){
        printf("Error opening %s.", led0);
    }

    fprintf(pLedBrightnessFile,"%d", val);
    fclose(pLedBrightnessFile);
}

void timingtest(){
    for (int i = 0; i < 5; i++){
        long second = 1;
        long nanosecond = 500000000;
        struct timespec reqDelay = {second,nanosecond};
        nanosleep(&reqDelay, (struct timespec *) NULL);
        
    }
}

int readFromFileToScreen(char *fileName){
    FILE *file = fopen(fileName, "r");
    if (file = NULL){
        printf("Error opening the file %s to read \n", fileName);
        exit(-1);
    }
    //read a string line
    const int MAX_LENGTH = 1024;
    char buff(MAX_LENGTH);
    fgets(buff, MAX_LENGTH, file);

    //close
    fclose(file);

    return atoi(buff);
}

void initialize(){
    FILE *pFile1 = fopen(led0,"w");
    FILE *pFile2 = fopen(led3,"w");
    if (!pFile1 || !pFile2){
        printf("Error opening the export file. \n");
        exit(1);
    }
    fprintf(pFile1, "%d", 0);
    fprintf(pFile2, "%d", 0);
    fclose(pFile1);
    fclose(pFile2);
}

static long long getTimeInMs(void){
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs){
    const long long NS_PER_MS = 1000*1000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

enum  button(val){
    readFromFileToScreen(gpio);
    return val;
}

static void runCommand(char* command){
    FILE *pipe = popen(command, "r");
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)){
        if (fgets(buffer, sizeof(buffer), pipe) == NULL) break;  
    }

    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0){
        perror("Unable to execute command:");
        printf("    command:    %s\n", command);
        printf("    exit code:  %d\n", exitCode);
    }
}

void clean(){
    initialize();
}*/

int main(int argc, char* args[])
{
    printf("Hello embedded world, from Nimrat!\n");
    
    /*initialize();
    
    //trigger set
    FILE *pLedTriggerFile = fopen(trigger,"w");
    if (pLedTriggerFile == NULL){
        printf("Error opening %s.", trigger);
        exit(1);
    }
    
    //turn on led 0
    brightness(char *led0, int 1);

    while (1){
        //turn on led 3
        brightness(char *led3, int 1);
        //start recording time
        timingtest();
        
        //read respond time using getTimeInMs
        //fprint statements to display time
        //not sure how to record the best time
        //exit game if too long using testtiming and a break statement?

    }
    


    int charWritten = fprintf(pLedTriggerFile, "none");
    if (charWritten <= 0) {
        printf("Error Writing Data");
        exit(1);
    }
    fclose(pLedTriggerFile);*/
    
    return 0;
}
