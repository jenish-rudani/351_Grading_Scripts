#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>

static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}

static void sleepForMs(long long delayInMs)
{
 const long long NS_PER_MS = 1000 * 1000;
 const long long NS_PER_SECOND = 1000000000;
 long long delayNs = delayInMs * NS_PER_MS;
 int seconds = delayNs / NS_PER_SECOND;
 int nanoseconds = delayNs % NS_PER_SECOND;
 struct timespec reqDelay = {seconds, nanoseconds};
 nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void)
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000
 + nanoSeconds / 1000000;
 return milliSeconds;
}

// this function wasnt working for some reason
// update figured it out wasnt working due to a char array, should have made that just a sngle char but its fine
/*int readFromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    printf("Read: %s\n", buff);
    printf("we are here");
    return (int) buff;
}*/

static int readFromFileToScreen(char *fileName) 
{
    FILE *pfile = fopen(fileName, "r");
    int buff = 0;
    fscanf(pfile, "%d", &buff);
    fclose(pfile);
    return buff;
}

int main(int argc, char* args[])
{
    
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr0/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr1/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr2/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone:green:usr3/trigger");

    runCommand("config-pin p8.43 gpio");

    printf("Hello embedded world, from Samanjot Waraich!\n");
    printf("\n");
    printf("When LED3 lights up, press the USER button to test your reaction time!\n");
    int besttime = 10000;
    bool earlypress = false;
    int duration = 0;

    /*
    Display a hello-world welcome message
    Continuously loop through the following steps to play the game:
    1. Wait while user holds down USER button
    2. Light up only LED 0
    3. Wait a random time (between 0.5s and 3.0s)
    4. If user is pressing the USER button already (too soon):
    - Record response time as 5.0s
    - Skip to “Light up all LEDs”
    5. Light up LED 3 & start timer
    6. When user presses USER button, stop timer
    - If timer > 5s, exit with a message without waiting for button press
    7. Light up all LEDs
    8. Display summary:
    - How many ms was the current response time?
    - How many ms is the best response time so far this game? 
    */

    while(1)
    {
        duration = 0; // duration is kept as its a value to exit the while loop in
        //int waittime;
        long long int randomvalue = 0;
        long long int starttime = getTimeInMs();
        int reactiontime = 0;
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr0/brightness");
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr1/brightness");
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr2/brightness");
        runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr3/brightness");

        int buttonpressed = readFromFileToScreen("/sys/class/gpio/gpio72/value");
        
        while(buttonpressed == 0)
        {
            buttonpressed = readFromFileToScreen("/sys/class/gpio/gpio72/value");
            sleepForMs(1);
        }

        runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");
        srand( time(NULL));
        randomvalue = ((rand() % (3000-500 + 1)) + 500) + getTimeInMs();// random value in ms (500ms -> 3000ms)
        // ^ add getTimeInMs() so that its "correctly formatted" for the comparasion

        while(getTimeInMs() < randomvalue)
        {
            sleepForMs(1);
            //waittime++; got rid of this for the same reason as duration
            buttonpressed = readFromFileToScreen("/sys/class/gpio/gpio72/value");
            if(buttonpressed == 0)
            {
                duration = 5000;
                earlypress = true;
                break;
            }
        }

        if(earlypress == false)
        {
            runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");
            starttime = getTimeInMs();
            long long int endtime = starttime + 5000;
            while(getTimeInMs() < endtime)
            {
                sleepForMs(1);
                //duration++; got rid of duration as a timer to accuratly get 5000ms waittime otherwise 
                //            duration++ would cause a delay 
                buttonpressed = readFromFileToScreen("/sys/class/gpio/gpio72/value");
                if(buttonpressed == 0)
                {
                    reactiontime = getTimeInMs() - starttime;
                    printf("Your reaction time now is %d; ", reactiontime);
                    duration = 0;
                    break;
                }
            }
            if(getTimeInMs() >= endtime)
            {
                duration = 5001;
            }
        }
        runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr0/brightness");
        runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr1/brightness");
        runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr2/brightness");
        runCommand("echo 1 > /sys/class/leds/beaglebone:green:usr3/brightness");

        if(earlypress == true)
        {
            printf("you pressed it early\n");
            break;
        }
        else if(duration >= 5000)
        {
            printf("no imput in 5000ms exiting!\n");
            break;
        }
        else if (duration < 5000)
        {
            if(reactiontime < besttime)
            {
                besttime = reactiontime;
                printf("\n NEW BEST TIME, best time now is %d \n", besttime);
            }
            else{
                printf("Your best time so far is %d \n", besttime);
            }
        }
        
    }

    runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr0/brightness");
    runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr1/brightness");
    runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr2/brightness");
    runCommand("echo 0 > /sys/class/leds/beaglebone:green:usr3/brightness");
    printf("We have exited \n");
}
