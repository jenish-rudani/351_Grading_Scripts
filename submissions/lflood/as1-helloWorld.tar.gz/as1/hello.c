/*
    Author: Laura Flood
    Student ID: lflood
    Student Number: 301393452
    Created: 09/29/2022
    Last Updated: 10/06/2022

    This file runs a program for the BeagleBone Green which plays an LED game. LED3 is turned on and the user must press the USER button as quickly as possible. Their reaction time is recorded and the game repeats. If the user does not react within 5 seconds the program is closed. 
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/wait.h>
#include <errno.h>
#define USER_NUM "72"
#define USER_PIN "p8.43"
#define LED_TRIGGER_FILENAME(n) "/sys/class/leds/beaglebone:green:usr" #n "/trigger"
#define LED_BRIGHTNESS_FILENAME(n) "/sys/class/leds/beaglebone:green:usr" #n "/brightness"
#define BUTTON_VALUE_FILE "/sys/class/gpio/gpio72/value"

// Function prototypes
static void startGame(long long bestTime);
static void waitRandomTime();
static int getButtonValue();
static void alterLED(char* LED_File, char* command);
static void turnOnLED(int LED_Num);
static void turnOffAllLEDs();
static void turnOnAllLEDs(); 
static void printHelloWorldToTerminal(); 
static void configurePin(char* pinNumber, char* linuxNum);
static void writeToFile(char *file, char* message); 
static int readFromFile(char *fileName); 
static long long getTimeInMs(void); 
static void sleepForMs(long long delayInMs); 
static void runCommand(char* command);

int main()
{ 
    turnOffAllLEDs(); // set all LEDs' triggers to none
    printHelloWorldToTerminal();
    configurePin(USER_PIN, USER_NUM);
    printf("When LED3 lights up, press the USER button!\n");
    startGame(-1); // start game with negative bestTime to tell program it is the start of the game
    turnOffAllLEDs(); // set all LEDs' triggers to none
}

static void startGame(long long bestTime){

    turnOffAllLEDs();
    //check button state, wait until not pressed
    int busy = 0;
    while (getButtonValue() == 1){
        busy = busy + 1;
    }

    turnOnLED(0);
    waitRandomTime(); // wait between 0.5-3 seconds
    long long  elapsedTime = 0;

    // check if button was pressed before light was turned on
    if (getButtonValue() == 1){
        elapsedTime = 5000;
        goto lightLEDs;
    }

    long long startTime = getTimeInMs();
    long long endTime = 0;
    turnOnLED(3);
   
    // continue checking button state until it is pressed, recrod raction time, exit if no input after 5s
    while(getButtonValue() == 0){ 
        endTime = getTimeInMs();
        elapsedTime = endTime - startTime;

        if(elapsedTime >= 5000){
            printf("No input within 5000ms, quitting game!\n");
            return;
        }
    }

    // check if current attempt is new best time
    if((bestTime < 0) || (bestTime > elapsedTime)){
        bestTime = elapsedTime;
    }

    lightLEDs:turnOnAllLEDs();
    printf("Your reaction time was %lldms! Best so far in game is %lld.\n", elapsedTime, bestTime);

    startGame(bestTime); //loop game 

}

static void printHelloWorldToTerminal(){
    printf("Hello embedded world, from Laura!\n");
}

static int getButtonValue(){
    int button_isPressed = readFromFile(BUTTON_VALUE_FILE);

    // flip button value to be 1 when pressed and 0 when not pressed
    if(button_isPressed == 0){ 
        return 1;
    } else if (button_isPressed == 1){
        return 0;
    }

    // else/error
    return -1;
}

static void configurePin(char* pinNumber, char* linuxNum){
    // set USER button to GPIO mode
    char command[1024] = "config-pin "; 
    strcat(command, pinNumber);
    strcat(command, " gpio");
    runCommand(command); 

    // Configure button as input
    writeToFile("/sys/class/gpio/gpio72/direction", "in");    
}

static void alterLED(char* LED_File, char* command){
    FILE *pLedTriggerFile = fopen(LED_File, "w");

    // check file opened successfully
    if (pLedTriggerFile == NULL){
        printf("ERROR OPENING %s.\n", LED_File);
        exit(1);
    }

    // write to trigger file
    int charWritten = fprintf(pLedTriggerFile, command);
    if (charWritten <= 0) { 
        printf("ERROR WRITING DATA");
        exit(1);
    }

    fclose(pLedTriggerFile);
}  

static void turnOnLED(int LED_Num){
    switch (LED_Num){
        case 0:
            alterLED(LED_TRIGGER_FILENAME(0), "default-on");
            break;
        case 1:
            alterLED(LED_TRIGGER_FILENAME(1), "default-on");
            break;
        case 2:
            alterLED(LED_TRIGGER_FILENAME(2), "default-on");
            break;
        case 3:
            alterLED(LED_TRIGGER_FILENAME(3), "default-on");
            break;
        default:
            printf("Invalid LED number.\n");
            break;
    }    
}

static void turnOffAllLEDs(){
    alterLED(LED_TRIGGER_FILENAME(0), "none");
    alterLED(LED_TRIGGER_FILENAME(1), "none");
    alterLED(LED_TRIGGER_FILENAME(2), "none");
    alterLED(LED_TRIGGER_FILENAME(3), "none");
}

static void turnOnAllLEDs(){
    alterLED(LED_TRIGGER_FILENAME(0), "default-on");
    alterLED(LED_TRIGGER_FILENAME(1), "default-on");
    alterLED(LED_TRIGGER_FILENAME(2), "default-on");
    alterLED(LED_TRIGGER_FILENAME(3), "default-on");
}

static void writeToFile(char *fileName, char* message){
    // Use fopen() to open the file for write access.
    FILE *pFile = fopen(fileName, "w");
    if (pFile == NULL) {
        printf("ERROR: Unable to open %s file. %s\n", fileName, strerror(errno));
        exit(1);
    }

    // Write to data to the file using fprintf():
    fprintf(pFile, "%s", message);

    // Close the file using fclose():
    fclose(pFile);
    pFile = NULL;
    sleepForMs(300); // sleep for 300ms
}

static int readFromFile(char *fileName){
    // open file and check if successful
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read. %s.\n", fileName, strerror(errno));
        exit(-1);
    }

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);

    // Close
    fclose(pFile);
    pFile = NULL;

    // convert output to integer and return
    return atoi(buff);
}

static void waitRandomTime(){
    long long upper = 3000;
    long long lower = 500;
    long long num = (rand() % (upper - lower + 1)) + lower; //source: https://www.geeksforgeeks.org/generating-random-number-range-c/#:~:text=How%20to%20generate%20a%20random,upper%20limit%20of%20the%20range.

    sleepForMs(num);
}

static long long getTimeInMs(void){
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs){
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command){
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it 
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}