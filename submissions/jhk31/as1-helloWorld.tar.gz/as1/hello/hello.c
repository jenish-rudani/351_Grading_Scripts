#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include "LED.h"

#define USER_PATH "/sys/class/gpio/"

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static long long getTimeInMs(void) 
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000 
 + nanoSeconds / 1000000;
 return milliSeconds;
}

void USER_EXPORT() //export pin for USER button
{
    int seconds = 1;
    int nanoseconds = 0;
    struct timespec reqDelay = {seconds, nanoseconds};
    FILE *USER_EXPORT = fopen(USER_PATH "/export", "w");
    
    if (USER_EXPORT == NULL) {
        printf("ERROR: Unable to export gpio72 pin.\n");
        exit(1);
    }

    fprintf(USER_EXPORT, "%d", 72);
    fclose(USER_EXPORT);
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

bool is_USERPressed() 
{
    FILE *USER_INPUT = fopen(USER_PATH "/gpio72/value", "r");
    if (USER_INPUT == NULL) {
        printf("ERROR: Unable to open file for read");
        exit(1);
    }
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    
    USER_INPUT = fopen(USER_PATH "gpio72/value", "r");
    fgets(buff, MAX_LENGTH, USER_INPUT);   
        
    if (strcmp(buff, "1") == 0) { //USER is pressed
        fclose(USER_PATH "gpio72/value");
        return true;        
    }
    else { //USER is not pressed
        fclose(USER_PATH "gpio72/value");
        return false;
    }
}


int random()
{
     time_t t;
   
    // Intializes random number generator for the random wait between 500ms and 3000ms 
    srand((unsigned) time(&t));

    // Prints random number from 500 to 3000
    int x = (rand() % 2500) + 500;

    return x;
}

int main ()
{
    USER_EXPORT();
    LEDinitialize();

    printf("Hello embedded world, from Ryan!\n"); //hello world message

    while(true)
    {
        long long starttime = getTimeInMs();
        long long responsetime = getTimeInMs() - starttime;
        long long besttime;
        long long waittime = random();
        long seconds = 1; //making sure the game isn't rushed
        long nanoseconds = 0; 
        struct timespec reqDelay = {seconds, nanoseconds};

        LEDOn(0); //turns on LED0
        sleepForMs(waittime); //waits for random number between 500ms and 3000ms
        printf("When LED3 lights up, press the USER button!\n");

        // if (!LEDOn(3) && is_USERPressed() == TRUE) { //if USER was pressed too early
        //     printf("the user pressed the button too soon.\n");
        //     LEDAllOn();
        //     printf("Your reaction time was 5000ms; best so far in game is %d\n", besttime);
        // }
        // nanosleep(&reqDelay, (struct timespec *) NULL);
            
        

    //     else if (){
                
    //     }

    //         fprintf(pLED3TriggerFile, "1");
    //         starttime = getTimeInMs();

    //         if (userreacted) {
    //             responsetime = getTimeInMs()-starttime;
    //             besttime = responsetime;
    //         }



        

    // }
   
    return 0;
    }
}