#include "LED.h"

#define LED0_PATH "/sys/class/leds/beaglebone:green:usr0"
#define LED1_PATH "/sys/class/leds/beaglebone:green:usr1"
#define LED2_PATH "/sys/class/leds/beaglebone:green:usr2"
#define LED3_PATH "/sys/class/leds/beaglebone:green:usr3"


void LEDinitialize() 
{
    FILE *pLED0TriggerFile = fopen(LED0_PATH "/trigger", "w");
    FILE *pLED1TriggerFile = fopen(LED1_PATH "/trigger", "w");
    FILE *pLED2TriggerFile = fopen(LED2_PATH "/trigger", "w");
    FILE *pLED3TriggerFile = fopen(LED3_PATH "/trigger", "w");

    if (pLED0TriggerFile == NULL) {
        printf("ERROR OPENING %s.\n", LED0_PATH "/trigger");
        exit(1);
    }
    fprintf(pLED0TriggerFile, "none"); //manual control
    fclose(pLED0TriggerFile);

    if (pLED0TriggerFile == NULL) {
        printf("ERROR OPENING %s.\n", LED1_PATH "/trigger");
        exit(1);
    }
    fprintf(pLED1TriggerFile, "none"); 
    fclose(pLED1TriggerFile);

    if (pLED0TriggerFile == NULL) {
        printf("ERROR OPENING %s.\n", LED2_PATH "/trigger");
        exit(1);
    }
    fprintf(pLED2TriggerFile, "none"); 
    fclose(pLED2TriggerFile);

    if (pLED3TriggerFile == NULL) {
        printf("ERROR OPENING %s.\n", LED3_PATH "/trigger");
        exit(1);
    }
    fprintf(pLED3TriggerFile, "none"); //manual control
    fclose(pLED3TriggerFile);
}

void LEDOn(int x) 
{
    FILE *pLED0BrightnessFile = fopen(LED0_PATH "/brightness", "w");
    FILE *pLED3BrightnessFile = fopen(LED3_PATH "/brightness", "w");

    if (pLED0BrightnessFile != NULL && pLED3BrightnessFile != NULL) {
        if (x == 0) {
            fprintf(pLED0BrightnessFile, "1");
        }
        else if (x == 3) {
            fprintf(pLED3BrightnessFile, "1");
        }
    }  
    fclose(pLED0BrightnessFile);
    fclose(pLED3BrightnessFile); 
}

void LEDAllOn() // for "Light up all LEDs"
{
    FILE *pLED0BrightnessFile = fopen(LED0_PATH "/brightness", "w");
    FILE *pLED1BrightnessFile = fopen(LED1_PATH "/brightness", "w");
    FILE *pLED2BrightnessFile = fopen(LED2_PATH "/brightness", "w");
    FILE *pLED3BrightnessFile = fopen(LED3_PATH "/brightness", "w");

    if (pLED0BrightnessFile == NULL) {
        printf("ERROR OPENING %s.\n", LED0_PATH "/brightness");
        exit(1);
    }
    fprintf(pLED0BrightnessFile, "1"); //turning LED0 on
    fclose(pLED0BrightnessFile);

    if (pLED1BrightnessFile == NULL) {
        printf("ERROR OPENING %s.\n", LED1_PATH "/brightness");
        exit(1);
    }
    fprintf(pLED1BrightnessFile, "1"); //turning LED1 on
    fclose(pLED1BrightnessFile);

    if (pLED2BrightnessFile == NULL) {
        printf("ERROR OPENING %s.\n", LED2_PATH "/brightness");
        exit(1);
    }
    fprintf(pLED2BrightnessFile, "1"); //turning LED2 on
    fclose(pLED2BrightnessFile);

    if (pLED3BrightnessFile == NULL) {
        printf("ERROR OPENING %s.\n", LED3_PATH "/brightness");
        exit(1);
    }
    fprintf(pLED3BrightnessFile, "1"); //turning LED3 on
    fclose(pLED3BrightnessFile);
}