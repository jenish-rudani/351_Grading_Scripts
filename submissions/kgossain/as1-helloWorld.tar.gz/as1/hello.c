#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds=spec.tv_sec;
    long long nanoSeconds=spec.tv_nsec;
    long long milliSeconds= seconds*1000+nanoSeconds/1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS=1000*1000;
    const long long NS_PER_SECOND=1000000000;

    long long delayNs = delayInMs*NS_PER_MS;
    int seconds=delayNs/NS_PER_SECOND;
    int nanoseconds=delayNs % NS_PER_SECOND;

    struct timespec reqDelay={seconds,nanoseconds};
    nanosleep(&reqDelay,(struct timespec*)NULL);
}


static void runCommand(char* command)
{   
    //Execute the shell command (output into pipe)
    FILE *pipe= popen(command, "r");

    //Ignore output of the command; but consume it sp we don't get and error when closing the pipe.
    char buffer[1024];
    while(!feof(pipe) && !ferror(pipe))
    {
        if(fgets(buffer,sizeof(buffer),pipe)== NULL)
            break;
        //printf("--> %s", buffer);
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode=WEXITSTATUS(pclose(pipe));
    if(exitCode!=0)
    {
        perror("Unable to execute command :");
        printf("commnad: %s\n" , command);
        printf("exit code: %d\n", exitCode);
    }
}

int readFromFileToScreen()
{
    int isbuttos0=0;
    FILE *pFile=fopen("/sys/class/gpio/gpio72/value","r");
    if(pFile==NULL)
    {
        printf("ERROR: Unable to open file for read \n");
        exit(-1);
    }

    //Read string(line)
    const int MAX_LENGTH=1024;
    char buff[MAX_LENGTH];
    fgets(buff,MAX_LENGTH,pFile);

    if(buff[0]=='0')
        isbuttos0=0;
    else if(buff[0]=='1')
        isbuttos0=1;

    //close
    fclose(pFile);
    //printf("Read: '%s '\n",buff);
    return isbuttos0;
}


    
float generateRandomTime(float Maxtime,float Mintime)
{
    srand((unsigned int)(NULL));
    return Mintime+(rand()/(float)RAND_MAX)*(Maxtime-Mintime);
}

void setLED0(int value0)
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr0/brightness","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr0/brightness");
        exit(1);
    }
    fprintf(pFile,"%d",value0);
    fclose(pFile);
}

void setLED1(int value1)
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr1/brightness","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr1/brightness");
        exit(1);
    }
    fprintf(pFile,"%d",value1);
    fclose(pFile);
}

void setLED2(int value2)
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr2/brightness","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr2/brightness");
        exit(1);
    }
    fprintf(pFile,"%d",value2);
    fclose(pFile);

}

void setLED3(int value3)
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr3/brightness","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr3/brightness");
        exit(1);
    }
    fprintf(pFile,"%d",value3);
    fclose(pFile);

}

void setupallLEDs(int ledvalue)
{
    setLED0(ledvalue);
    setLED1(ledvalue);
    setLED2(ledvalue);
    setLED3(ledvalue);
}

void resetTrigger0()
{
FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr0/trigger","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr0/trigger");
        exit(1);
    }
    fprintf(pFile,"%s","none");
    fclose(pFile);

}

void resetTrigger1()
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr1/trigger","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr1/trigger");
        exit(1);
    }
    fprintf(pFile,"%s","none");
    fclose(pFile);

}

void resetTrigger2()
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr2/trigger","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr2/trigger");
        exit(1);
    }
    fprintf(pFile,"%s","none");
    fclose(pFile);

}

void resetTrigger3()
{
    FILE *pFile=fopen("/sys/class/leds/beaglebone:green:usr3/trigger","w");
    if(pFile==NULL)
    {
        printf("ERROR OPENING %s","/sys/class/leds/beaglebone:green:usr3/trigger");
        exit(1);
    }
    fprintf(pFile,"%s","none");
    fclose(pFile);

}

void resetTrigger()
{
    resetTrigger0();
    resetTrigger1();
    resetTrigger2();
    resetTrigger3();
}

int main(int argc,char*args [])
{
    printf("Hello embedded world, from Kunal !\n");
    printf("When LED3 lights up, press the USER button !");

    enum States
    {
        s0,
        s1,
        s2,
        s3,
        s4,
    };

    setupallLEDs(0);
    resetTrigger();
    runCommand("config-pin p8.43 gpio");
    enum States myState = s0;
    long long timerStart = 0;
    long long timerStop = 0;
    long long responseTime = 0;
    long long bestresposnetime=5000;
    while(1)
    {
        int isuserbutton=readFromFileToScreen();
        float randtime=generateRandomTime(0.5,3);

        switch(isuserbutton)
        {
            case 1: //Not Pressed
                //As user takes his hands of (1), set led0 ...
                if(myState == s1)
                {
                    //printf("Setting up led0 and sleeping\n")-->for debugging;
                    setLED0(1);
                    myState = s2;
                    sleepForMs(randtime*1000);
                }
                else if(myState == s2)
                {
                    //printf("Setting up led3 and starting timer\n") -->for debugging;
                    setLED3(1);
                    timerStart = getTimeInMs();
                    myState = s3;
                }
                else if(myState == s4)
                {
                    //printf(" Turning off all leds,restarting\n") --> for debugging;
                    myState = s0;
                    setupallLEDs(0);
                    resetTrigger();
                }
                break;


            case 0:// Pressed
                //Wait while user holds down the button (1)
                if(myState == s0)
                {
                    //printf("Holding the button\n") --> for debugging;
                    myState = s1;
                }
                else if(myState == s2)
                {
                    //printf("Oh you pressed too soon\n");
                    timerStop = getTimeInMs();
                    responseTime = 5;
                    setupallLEDs(1);
                    printf("Your Response time %lld ms ",responseTime);
                    myState = s4;//End state
                }
                else if(myState == s3)
                {
                    printf(" Pressed button\n");
                    timerStop = getTimeInMs();
                    if( 5000 < (timerStop-timerStart))
                    {
                        printf("No input within 5000ms ; quitting!\n");
                        setupallLEDs(0);
                        return 0;
                    }
                    else
                    {
                        //printf("Pressed button <5\n");
                        myState = s4;
                        setupallLEDs(1);
                        printf("Your Response time %lld ms ",(timerStop-timerStart));
                        if(bestresposnetime>(timerStop-timerStart))
                        {
                            bestresposnetime=(timerStop-timerStart);
                        }
                        printf(",best so far in game is %lld ms \n",bestresposnetime);
                    }
                }

                break;
        }
        
    }
    return 0;
}