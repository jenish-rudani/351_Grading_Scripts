/**
    Author: Anika Sheikh
    Class: ENSC351
    Professor: Dr. Brian Fraser
    Purpose: 
        Display Simple Message in BeagleBone
        Make a Game on BeagleBone that tests user reaction time by timing their press 
        When LED 3 is on
**/

#include <stdio.h>
#include <fcntl.h>      // for open()
#include <unistd.h>     // for close()
#include <string.h>
#include <sys/epoll.h>  // for epoll()
#include <errno.h>		// Errors
#include <sys/wait.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

//USER INPUT FILES
#define LED0_Path "/sys/class/leds/beaglebone:green:usr0"
#define LED1_Path "/sys/class/leds/beaglebone:green:usr1"
#define LED2_Path "/sys/class/leds/beaglebone:green:usr2"
#define LED3_Path "/sys/class/leds/beaglebone:green:usr3"
#define USER_Path "/sys/class/gpio/gpio72"
#define FILE_MAX_LENGTH 100
#define SLEEP_TIME 1000

//function from Assignment 1 : Build Environment - v1
static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
    if (fgets(buffer, sizeof(buffer), pipe) == NULL)
    break;
        printf("--> %s", buffer); // Uncomment for debugging
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
    perror("Unable to execute command:");
    printf(" command: %s\n", command);
    printf(" exit code: %d\n", exitCode);
 }
}

//Returns the concatenated string from 3 separate string 
static char* getConcatenatedString(char* s1, char* s2, char* s3){
    char * final_string;
    final_string = malloc(sizeof(char)*FILE_MAX_LENGTH);
    snprintf(final_string, FILE_MAX_LENGTH, "%s%s%s",s1, s2, s3);

    return final_string;
}

//Set all led trigger to None and set USER button to active_high
static void helloInit(){
    char trigger[9] = "/trigger\0";
    char active_low[13] = "/active_low\0";

    runCommand(getConcatenatedString("echo none > ", LED0_Path, trigger));
    runCommand(getConcatenatedString("echo none > ", LED1_Path, trigger));
    runCommand(getConcatenatedString("echo none > ", LED2_Path, trigger));
    runCommand(getConcatenatedString("echo none > ", LED3_Path, trigger));
    runCommand(getConcatenatedString("echo 1 > ", USER_Path, active_low));
    runCommand("echo config-pin p8.43 gpio> /dev/null 2>&1");
}

//function from sample code, edgeTrigger.c
static int readLineFromFile(char* fileName, char* buff, unsigned int maxLength)
{
	FILE *file = fopen(fileName, "r");
	int bytes_read = getline(&buff, &maxLength, file);
	fclose(file);
	return bytes_read;
}

//function to turn LED On or off 
static void controlLedBrightness(char* path, int value){
    char value_string[15]= "/brightness\0";
    char final_path[FILE_MAX_LENGTH] = "";
    snprintf(final_path, FILE_MAX_LENGTH, "%s%d%s%s%s", "echo ", value, " > ", path, value_string);
    runCommand(final_path);
}

//function from Assignment 1 : Build Environment - v1
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

//function from Assignment 1 : Build Environment - v1
static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

//funtion to return value from the User gpio file
static int getUserButtonValue(char* user_value_path){
    char buff[FILE_MAX_LENGTH];
    int bytesRead = readLineFromFile(user_value_path, buff, FILE_MAX_LENGTH);
    if (bytesRead > 0) {
        return buff[0] - '0';
    } else {
        fprintf(stderr, "ERROR: Read 0 bytes from GPIO input: %s\n", strerror(errno));
        return -1;
    }
}

//function to print report to the player and set new best time if any
static int printReportAndGetBestTime(long long play_time, long long best_time){
    if(play_time < best_time){
        printf("New best time!\n");
        printf("Your recation time was %lldms; best so far in game is %lldms.\n", play_time, play_time);
        return play_time;
    } else {
        printf("Your recation time was %lldms; best so far in game is %lldms.\n", play_time, best_time);
        return best_time;
    }

}

//get random number from 500 - 3000 to get 0.5s - 3s
static int getRandomTime(){
    return  (rand() % (3000 - 500 + 1)) + 500;
}

//function for handling when user presses button too quick
static void handleTooQuickPush(long long startTime, long long currentTime, long long best_time, char* user_value_path){
    int timeToWait = getRandomTime();
    while(currentTime - startTime < timeToWait){
        controlLedBrightness(LED0_Path, 1);
        int valueChange = getUserButtonValue(user_value_path);
        if(valueChange == 1){
            controlLedBrightness(LED1_Path, 1);
            controlLedBrightness(LED2_Path, 1);
            controlLedBrightness(LED3_Path, 1);

            printf("First Time Pushed Too early\n");
            int best_time = printReportAndGetBestTime(5000, best_time);
        }
        currentTime = getTimeInMs();
    }
}

//set all led trigger to None and turn them all off
static void cleanUp(){
    helloInit();
    controlLedBrightness(LED0_Path, 0);
    controlLedBrightness(LED1_Path, 0);
    controlLedBrightness(LED2_Path, 0);
    controlLedBrightness(LED3_Path, 0);
}

int main() {
    printf("Hello embedded world, from Anika Sheikh!\n\nWhen LED3 lights up, press the USER button!\n");

    bool first_push = true;
    char value_string[8]= "/value\0";
    char user_value_path[FILE_MAX_LENGTH] = "";
    long long best_time = 5000;
    long long play_time = 0;
    long long startTime = 0;
    long long currentTime = 0;
    srand(time(NULL));
    snprintf(user_value_path, FILE_MAX_LENGTH, "%s%s", USER_Path, value_string);
    
    //Initialize BeagleBone
    helloInit();

    while(1){

        int value = getUserButtonValue(user_value_path);
        if(value == 1){

            if(first_push){
                first_push = false;
                sleepForMs(0.5*SLEEP_TIME); //sleep to handle user press
                startTime = getTimeInMs();
                
                handleTooQuickPush(startTime, currentTime, best_time, user_value_path);

                controlLedBrightness(LED0_Path, 0);
                controlLedBrightness(LED1_Path, 0);
                controlLedBrightness(LED2_Path, 0);
                controlLedBrightness(LED3_Path, 0);

                sleepForMs(SLEEP_TIME); //sleep to handle user press

                startTime = getTimeInMs();
                controlLedBrightness(LED3_Path, 1);
            } else {
                play_time = (getTimeInMs()) - startTime;
                best_time = printReportAndGetBestTime(play_time, best_time);

                controlLedBrightness(LED3_Path, 0);

                sleepForMs(getRandomTime());//sleep to handle user press

                startTime = getTimeInMs();
                controlLedBrightness(LED3_Path, 1);
            }

        }else if(value == 0){
            long long downStartTime = getTimeInMs();
            long long downCurrentTime = 0;
            while(downCurrentTime - downStartTime< 5002){
                int valueChange = getUserButtonValue(user_value_path);
                if(valueChange == 1){
                    break;
                } 
                if(valueChange == 0 && (downCurrentTime - downStartTime) >= 5000){
                    printf("No input within 5000ms; quitting!\n");
                    cleanUp();
                    return 0;
                }
                
                downCurrentTime = getTimeInMs();
            }
        } else {
            printf("Some Unexpected Error Has Occured\n");
            break;
        }
    }
    cleanUp(); //Turn off all LEDs
   return 0;
}



