#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include<time.h>
#include <errno.h>		// Errors
#include <fcntl.h>      // for open()


// led 0,1,2,3 trigger files path
#define LED0_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr3/trigger"

// led 0,1,2,3 brighteness files path
#define LED0_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr3/brightness"

// User(Boot button)
#define EXPORT_FILE "/sys/class/gpio/export"
#define USER_BUTTON_DIRECTION_FILE "/sys/class/gpio/gpio72/direction"
#define USER_BUTTON_ACTIVELOW_FILE "/sys/class/gpio/gpio72/active_low"
#define USER_BUTTON_VALUE_FILE "/sys/class/gpio/gpio72/value"

long long getTimeInMs(void) {
	struct timespec spec;
	clock_gettime(CLOCK_REALTIME, &spec);
	long long seconds = spec.tv_sec;
	long long nanoSeconds = spec.tv_nsec;
	long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;

	return milliSeconds;
}

void sleepForMs(long long delayInMs) {
	const long long NS_PER_MS = 1000 * 1000;
	const long long NS_PER_SECOND = 1000000000;

	long long delayNs = delayInMs * NS_PER_MS;
	int seconds = delayNs / NS_PER_SECOND;
	int nanoseconds = delayNs % NS_PER_SECOND;

	struct timespec reqDelay = { seconds, nanoseconds };
	nanosleep(&reqDelay, (struct timespec*)NULL);
}

void runCommand(char* command) {
	// Execute the shell command (output into pipe)
	FILE* pipe = popen(command, "r");

	// Ignore outpur if the command; but consume it
	// So we don't get an error when closing the pipe

	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
		if (fgets(buffer, sizeof(buffer), pipe) == NULL) {
			break;
		}

		printf("---> %s", buffer);
	}

	// Get the exit code from the pipe;
	// non zero is an error
	/*
	int exitcode = WEXITSTATUS(pclose(pipe));
	if (exitcode != 0) {
		perror("Unable to execute command:");
		printf(" command: %s\n", command);
		printf(" exit code: %d\n", exitcode);
	}*/
}
int main(int argc, char* args[])
{
	//CONTROL THE TRIGGER
	//When the program initially starts
	printf("Hello embedded world, from Mercygold!\n");

	// Open led 0,1,2,3 trigger files, with write access and save to a variable
	FILE* pLed0TriggerFile = fopen(LED0_TRIGGER_FILE, "w");
	FILE* pLed1TriggerFile = fopen(LED1_TRIGGER_FILE, "w");
	FILE* pLed2TriggerFile = fopen(LED2_TRIGGER_FILE, "w");
	FILE* pLed3TriggerFile = fopen(LED3_TRIGGER_FILE, "w");

	// Check if Open led trigger file was successfull
	if (pLed0TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED0_TRIGGER_FILE);
		exit(1);
	}
	else if (pLed1TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED1_TRIGGER_FILE);
		exit(1);
	}
	else if (pLed2TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED2_TRIGGER_FILE);
		exit(1);
	}
	else if (pLed3TriggerFile == NULL) {
		printf("ERROR OPENING %s.", LED3_TRIGGER_FILE);
		exit(1);
	}

	// Set/Write all Led triggers (led 0,1,2,3)
	int setLed0Trigger = fprintf(pLed0TriggerFile, "none");
	int setLed1Trigger = fprintf(pLed1TriggerFile, "none");
	int setLed2Trigger = fprintf(pLed2TriggerFile, "none");
	int setLed3Trigger = fprintf(pLed3TriggerFile, "none"); // trigger is timer or none here i wonder?

	// Check if setting trigger(writting to trigger file) was succesfful
	if (setLed0Trigger <= 0) {
		printf("ERROR WRITTING DATA to led 0");
		exit(1);
	}
	else  if (setLed1Trigger <= 0) {
		printf("ERROR WRITTING DATA to led 1");
		exit(1);
	}
	else  if (setLed2Trigger <= 0) {
		printf("ERROR WRITTING DATA to led 2");
		exit(1);
	}
	else  if (setLed3Trigger <= 0) {
		printf("ERROR WRITTING DATA to led 3");
		exit(1);
	}

	// Close trigger file
	// QN: do i need to close trigger file as i do with brightness file
	fclose(pLed0TriggerFile);
	fclose(pLed1TriggerFile);
	fclose(pLed2TriggerFile);
	fclose(pLed3TriggerFile);


	// SETTING THE BRIGHTNESS
	// Open led 0,1,2,3 brightness files, with write access and save to a variable
	FILE* pLed0BrightnessFile = fopen(LED0_BRIGHTNESS_FILE, "w");
	FILE* pLed1BrightnessFile = fopen(LED1_BRIGHTNESS_FILE, "w");
	FILE* pLed2BrightnessFile = fopen(LED2_BRIGHTNESS_FILE, "w");
	FILE* pLed3BrightnessFile = fopen(LED3_BRIGHTNESS_FILE, "w");

	// Check if Open led brightness file was successfull
	if (pLed0BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED0_BRIGHTNESS_FILE);
		exit(1);
	}
	else if (pLed1BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED1_BRIGHTNESS_FILE);
		exit(1);
	}
	else if (pLed2BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED2_BRIGHTNESS_FILE);
		exit(1);
	}
	else if (pLed3BrightnessFile == NULL) {
		printf("ERROR OPENING %s.", LED3_BRIGHTNESS_FILE);
		exit(1);
	}

	// Set or Write initial led 0,1,2,3 state (like on/off)
	int setLed0Brightness = fprintf(pLed0BrightnessFile, "1");
	int setLed1Brightness = fprintf(pLed1BrightnessFile, "0");
	int setLed2Brightness = fprintf(pLed2BrightnessFile, "0");
	int setLed3Brightness = fprintf(pLed3BrightnessFile, "0");

	// close led brightness file after setting the led brightness
	fclose(pLed0BrightnessFile);
	fclose(pLed1BrightnessFile);
	fclose(pLed2BrightnessFile);
	fclose(pLed3BrightnessFile);

	// QN: Do we need the nao sleep thing?
	// we don't in this assig because export has been done for us


// USER (BOOT) BUTTON SETUP
	// Configure pin 72(user button) to be a gpio pin
	runCommand("config-pin p8.72 gpio");

	// Export
	// The exporting has already been done 
	// we don't have to export for this assignment

	// Open User Button direction file
	FILE* pUserDirectionFile = fopen(USER_BUTTON_DIRECTION_FILE, "w");
	if (pUserDirectionFile == NULL) {
		printf("ERROR: Unable to open User gpio72 direction file.\n");
		exit(1);
	}

	// Set User button direction file
	int setUserButtonDirectionAsInput = fprintf(pUserDirectionFile, "in");

	// Close the User Button direction file
	fclose(pUserDirectionFile);

	// User Button active low setting to turn some hardware on
	// Open User Button active low file
	FILE* pUserActiveLowFile = fopen(USER_BUTTON_ACTIVELOW_FILE, "w");
	if (pUserActiveLowFile == NULL) {
		printf("ERROR: Unable to open User gpio72 active_low file.\n");
		exit(1);
	}

	// Set user active low file (read 1-high, 0-low)
	int setUserButtonActiveLow = fprintf(pUserActiveLowFile, "1");

	// Set User button direction file
	fclose(pUserActiveLowFile);

	// GAME STARTS
	int firstTime = 1;
	long long bestTime;
	while (1) {
		// Light up LED 0
		// already done so 

		printf("When LED3 lights up, press the USER button!");

		// Wait a random time (between 0.5 to 3s)
		long long waitTime = 500 + (rand() % 2501);
		sleepForMs(waitTime);

		// Light LED3 
		pLed3BrightnessFile = fopen(LED3_BRIGHTNESS_FILE, "w");
		if (pLed3BrightnessFile == NULL) {
			printf("ERROR OPENING %s.", LED3_BRIGHTNESS_FILE);
			exit(1);
		}
		int setLed3Brightness = fprintf(pLed3BrightnessFile, "1");
		// Start timer
		long long startTime = getTimeInMs();
		fclose(pLed3BrightnessFile);

		long long endTime;
		long long timeElapsed;

		// Check if the user pressed the user button
		int isButtonPressed = 0;
		const int MAX_LENGTH = 1;
		char value[MAX_LENGTH];
		value[0] = -1;
		int compare = (int)value[0];
		while (isButtonPressed != compare) {
			FILE* pUserButtonPressedFile = fopen(USER_BUTTON_VALUE_FILE, "r");
			if (pUserButtonPressedFile == NULL) {
				printf("ERROR: Unable to open file (%s) for read\n ", USER_BUTTON_VALUE_FILE);
				exit(-1);
			}

			fgets(value, MAX_LENGTH, pUserButtonPressedFile);
			compare = (int)value[0];

			//Close 
			fclose(pUserButtonPressedFile);
		}
		endTime = getTimeInMs();


		timeElapsed = endTime - startTime;
		if (firstTime == 1) {
			printf("New best time!");
			bestTime = timeElapsed;
			firstTime = 0;
		}
		else {
			if (timeElapsed < bestTime) {
				bestTime = timeElapsed;
				printf("New best time!");

			}
			else {
				printf("Your reaction time was %lldms; best so far in game is %lldms", timeElapsed, bestTime);
			}
		}

		if (timeElapsed > 5000) {
			printf("No input within 5000ms; quitting!");

			// Turn off all LEDS
			FILE* pLed0BrightnessFile1 = fopen(LED0_BRIGHTNESS_FILE, "w");
			FILE* pLed1BrightnessFile1 = fopen(LED1_BRIGHTNESS_FILE, "w");
			FILE* pLed2BrightnessFile1 = fopen(LED2_BRIGHTNESS_FILE, "w");
			FILE* pLed3BrightnessFile1 = fopen(LED3_BRIGHTNESS_FILE, "w");

			// Check if Open led brightness file was successful
			if (pLed0BrightnessFile1 == NULL) {
				printf("ERROR OPENING %s.", LED0_BRIGHTNESS_FILE);
				exit(1);
			}
			else if (pLed1BrightnessFile1 == NULL) {
				printf("ERROR OPENING %s.", LED1_BRIGHTNESS_FILE);
				exit(1);
			}
			else if (pLed2BrightnessFile1 == NULL) {
				printf("ERROR OPENING %s.", LED2_BRIGHTNESS_FILE);
				exit(1);
			}
			else if (pLed3BrightnessFile1 == NULL) {
				printf("ERROR OPENING %s.", LED3_BRIGHTNESS_FILE);
				exit(1);
			}

			// All the LED being turned off
			int setLed0Brightness1 = fprintf(pLed0BrightnessFile1, "0");
			int setLed1Brightness1 = fprintf(pLed1BrightnessFile1, "0");
			int setLed2Brightness1 = fprintf(pLed2BrightnessFile1, "0");
			int setLed3Brightness1 = fprintf(pLed3BrightnessFile1, "0");

			// close led brightness file after setting the led brightness
			fclose(pLed0BrightnessFile1);
			fclose(pLed1BrightnessFile1);
			fclose(pLed2BrightnessFile1);
			fclose(pLed3BrightnessFile1);

			// end program
			return 0;
		}

		// Light up all LEDS
		FILE* pLed0BrightnessFile2 = fopen(LED0_BRIGHTNESS_FILE, "w");
		FILE* pLed1BrightnessFile2 = fopen(LED1_BRIGHTNESS_FILE, "w");
		FILE* pLed2BrightnessFile2 = fopen(LED2_BRIGHTNESS_FILE, "w");
		FILE* pLed3BrightnessFile2 = fopen(LED3_BRIGHTNESS_FILE, "w");

		// Check if Open led brightness file was successfull
		if (pLed0BrightnessFile2 == NULL) {
			printf("ERROR OPENING %s.", LED0_BRIGHTNESS_FILE);
			exit(1);
		}
		else if (pLed1BrightnessFile2 == NULL) {
			printf("ERROR OPENING %s.", LED1_BRIGHTNESS_FILE);
			exit(1);
		}
		else if (pLed2BrightnessFile2 == NULL) {
			printf("ERROR OPENING %s.", LED2_BRIGHTNESS_FILE);
			exit(1);
		}
		else if (pLed3BrightnessFile2 == NULL) {
			printf("ERROR OPENING %s.", LED3_BRIGHTNESS_FILE);
			exit(1);
		}

		// Turning off all the LED
		int setLed0Brightness2 = fprintf(pLed0BrightnessFile2, "1");
		int setLed1Brightness2 = fprintf(pLed1BrightnessFile2, "1");
		int setLed2Brightness2 = fprintf(pLed2BrightnessFile2, "1");
		int setLed3Brightness2 = fprintf(pLed3BrightnessFile2, "1");

		// close led brightness file after setting the led brightness
		fclose(pLed0BrightnessFile2);
		fclose(pLed1BrightnessFile2);
		fclose(pLed2BrightnessFile2);
		fclose(pLed3BrightnessFile2);
		


		// Wait a few 2 seconds for the user to notice all the leds on
		sleepForMs(2000);


		// Turn off led 1,2,3 and leave led 0 on ready to restart the game again
		FILE* pLed0BrightnessFile3 = fopen(LED0_BRIGHTNESS_FILE, "w");
		FILE* pLed1BrightnessFile3 = fopen(LED1_BRIGHTNESS_FILE, "w");
		FILE* pLed2BrightnessFile3 = fopen(LED2_BRIGHTNESS_FILE, "w");
		FILE* pLed3BrightnessFile3 = fopen(LED3_BRIGHTNESS_FILE, "w");

		// Check if Open led brightness file was successfull
		if (pLed0BrightnessFile3 == NULL) {
			printf("ERROR OPENING %s.", LED0_BRIGHTNESS_FILE);
			exit(1);
		}
		else if (pLed1BrightnessFile3 == NULL) {
			printf("ERROR OPENING %s.", LED1_BRIGHTNESS_FILE);
			exit(1);
		}
		else if (pLed2BrightnessFile3 == NULL) {
			printf("ERROR OPENING %s.", LED2_BRIGHTNESS_FILE);
			exit(1);
		}
		else if (pLed3BrightnessFile3 == NULL) {
			printf("ERROR OPENING %s.", LED3_BRIGHTNESS_FILE);
			exit(1);
		}

		// Turning off all the LED
		int setLed0Brightness3 = fprintf(pLed0BrightnessFile3, "1");
		int setLed1Brightness3 = fprintf(pLed1BrightnessFile3, "0");
		int setLed2Brightness3 = fprintf(pLed2BrightnessFile3, "0");
		int setLed3Brightness3 = fprintf(pLed3BrightnessFile3, "0");

		// close led brightness file after setting the led brightness
		fclose(pLed0BrightnessFile3);
		fclose(pLed1BrightnessFile3);
		fclose(pLed2BrightnessFile3);
		fclose(pLed3BrightnessFile3);

	}

	// Set all Led triggers (led 0,1,2,3) to none
	// already set to none up top

	return 0;
}
