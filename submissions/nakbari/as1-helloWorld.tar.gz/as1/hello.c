#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define LED0_brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED0_trigget "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED1_trigget "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED2_trigget "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_brightness "/sys/class/leds/beaglebone:green:usr3/brightness"
#define LED3_trigget "/sys/class/leds/beaglebone:green:usr3/trigger"
#define user_button "/sys/class/gpio/gpio72/value"

static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
int readFromFileToScreen(char *fileName);
static void runCommand(char* command);
void Trigger (char *LED);
void Brightness (char *LED);
void Turn_OFF (char *LED);


void Trigger (char *LED)
{
FILE *pLed_triggerFile = fopen(LED, "w");
if (pLed_triggerFile == NULL) {
printf("ERROR OPENING %s.", LED);
exit(1);
}
int charWritten = fprintf(pLed_triggerFile, "none");
if (charWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLed_triggerFile );
}


void Brightness (char *LED)
{
FILE *pLed_brightnessFile = fopen(LED, "w");
if (pLed_brightnessFile == NULL) {
printf("ERROR OPENING %s.", LED);
exit(1);
}
int charWritten = fprintf(pLed_brightnessFile, "1");
if (charWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLed_brightnessFile );
}

void Turn_OFF (char *LED)
{
FILE *pLed_brightnessFile = fopen(LED, "w");
if (pLed_brightnessFile == NULL) {
printf("ERROR OPENING %s.", LED);
exit(1);
}
int charWritten = fprintf(pLed_brightnessFile, "0");
if (charWritten <= 0) {
printf("ERROR WRITING DATA");
exit(1);
}
fclose(pLed_brightnessFile );
}


static long long getTimeInMs(void)
{
struct timespec spec;
clock_gettime(CLOCK_REALTIME, &spec);
long long seconds = spec.tv_sec;
long long nanoSeconds = spec.tv_nsec;
long long milliSeconds = seconds * 1000
+ nanoSeconds / 1000000;
return milliSeconds;
}

int readFromFileToScreen(char *fileName)
{
FILE *pFile = fopen(fileName, "r");
if (pFile == NULL) {
printf("ERROR: Unable to open file (%s) for read\n", fileName);
exit(-1);
}
// Read string (line)
const int MAX_LENGTH = 1024;
char buff[MAX_LENGTH];
fgets(buff, MAX_LENGTH, pFile);
// Close
fclose(pFile);
//printf("Read: '%s'\n", buff);
return atoi(buff);
}

static void sleepForMs(long long delayInMs)
{
const long long NS_PER_MS = 1000 * 1000;
const long long NS_PER_SECOND = 1000000000;
long long delayNs = delayInMs * NS_PER_MS;
int seconds = delayNs / NS_PER_SECOND;
int nanoseconds = delayNs % NS_PER_SECOND;
struct timespec reqDelay = {seconds, nanoseconds};
nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
// Execute the shell command (output into pipe)
FILE *pipe = popen(command, "r");
// Ignore output of the command; but consume it
// so we don't get an error when closing the pipe.
char buffer[1024];
while (!feof(pipe) && !ferror(pipe)) {
if (fgets(buffer, sizeof(buffer), pipe) == NULL)
break;
// printf("--> %s", buffer); // Uncomment for debugging
}
// Get the exit code from the pipe; non-zero is an error:
int exitCode = WEXITSTATUS(pclose(pipe));
if (exitCode != 0) {
perror("Unable to execute command:");
printf(" command: %s\n", command);
printf(" exit code: %d\n", exitCode);
}
}


int main()
{

long long response_time = 5000;
long long best_time = 10000;
long long current_time = 0;
long long current_time_1 = 0;
 
printf("Hello embedded world, from nasim!\n");

 while(1)
{
//Turn off all LEDs
Turn_OFF(LED0_brightness);                        //Turn off LED0
Turn_OFF(LED1_brightness);                        //Turn off LED1
Turn_OFF(LED2_brightness);                        //Turn off LED2
Turn_OFF(LED3_brightness);                        //Turn off LED3

runCommand("config-pin p8.43 gpio");                   //call the runComand function to put the user button to be GPIO
runCommand("echo 72 > export");                        //call the runComand function to 

while(readFromFileToScreen(user_button) ==0)
{
    printf("let go of the button to start the game \n");
    sleepForMs(1000);
    } 

//Turn on LED0
Trigger(LED0_trigget);                                 //trigger LED0
Brightness(LED0_brightness);                          //light up LED0

printf("When LED3 lights up, press the USER button!\n");
sleepForMs(2000);

//
if(readFromFileToScreen(user_button)==0)
    {
        Trigger(LED0_trigget);                                  //trigger LED0
        Brightness(LED0_brightness);                           //light up LED0

        Trigger(LED1_trigget);                               //trigger LED1
        Brightness(LED1_brightness);                        //light up LED1

        Trigger(LED2_trigget);                             //trigger LED2
        Brightness(LED2_brightness);                      //light up LED2

        Trigger(LED3_trigget);                           //trigger LED3
        Brightness(LED3_brightness);                    //light up LED3

        printf("user is cheating!! \n");
        printf("Your recation time was %lld \n", response_time);
    }
        else if (readFromFileToScreen(user_button)==1)
        {
            //Turn on LED3
            Trigger(LED3_trigget);                              //trigger LED3
            Brightness(LED3_brightness);                       //light up LED3

            //start timer
            long long start_time = getTimeInMs();              //start the timer by calling getTimeInMs function and put the output into the start_time variable

            while (readFromFileToScreen(user_button)==1)
                {
                    long long end_time = getTimeInMs();          //stop the timer by calling getTimeInMs function and put the output into the end_time variable
                    current_time = end_time - start_time;       //calculate the current time by difference of end and start times

                    //check to see if user is pressing the button more tha 5s
                    if(current_time > 5000)  
                        {
                            printf("No input within 5000ms; quitting! \n");
                            exit(1);                                         //exit the game
                        }
                
        
                    //check to see if user is pressing the button
                    if (readFromFileToScreen(user_button)==0)
                        {
                            long long end_time_1 = getTimeInMs();          //stop the timer by calling getTimeInMs function and put the output into the end_time variable
                            current_time_1 = end_time_1 - start_time;       //calculate the current time by difference of end and start times

                            //Turn on all LEDs
                            Trigger(LED0_trigget);                                  //trigger LED0
                            Brightness(LED0_brightness);                           //light up LED0

                            Trigger(LED1_trigget);                               //trigger LED1
                            Brightness(LED1_brightness);                        //light up LED1

                            Trigger(LED2_trigget);                             //trigger LED2
                            Brightness(LED2_brightness);                      //light up LED2

                            Trigger(LED3_trigget);                           //trigger LED3
                            Brightness(LED3_brightness);                    //light up LED3

                             printf("Your recation time was %lld; ", current_time_1);

                             //check to see what is the best time in the game
                             if(best_time > current_time_1)                    
                                {
                                    best_time = current_time_1;
                                    printf(" \n New best time ! \n");
                                }
                                else
                                    {
                                        printf("best so far in game is %lld \n", best_time);
                                    }

                        }

                }

        }

Turn_OFF(LED0_brightness);                        //Turn off LED0
Turn_OFF(LED1_brightness);                        //Turn off LED1
Turn_OFF(LED2_brightness);                        //Turn off LED2
Turn_OFF(LED3_brightness);                        //Turn off LED3

sleepForMs(1000);

}
 return 0;

} 