#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define triggerLED0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define triggerLED1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define triggerLED2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define triggerLED3 "/sys/class/leds/beaglebone:green:usr3/trigger"

#define brightLED0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define brightLED1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define brightLED2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define brightLED3 "/sys/class/leds/beaglebone:green:usr3/brightness"

#define buttonExport "/sys/class/gpio/export"
#define userButtonDirection "/sys/class/gpio/gpio72/direction"
#define userButtonActiveLow "/sys/class/gpio/gpio72/active_low"
#define userButtonEdge "/sys/class/gpio/gpio72/edge"
#define userButtonValue "/sys/class/gpio/gpio72/value" // 0 if pressed, 1 if not pressed

void writeToFile(char file[], char status[]);
char readFromFileToScreen(char *fileName);
static void runCommand(char *command);
static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
void ledAllOff(void);
void playGame(int currentBest);



int main(int argc, char *args[])
{
    printf("Hello embedded world, from Aneel!\n\n");
    printf("When LED3 lights up, press the USER button!\n");

    ledAllOff();

    runCommand("config-pin p8.43 gpio"); // configure USER button as GPIO

    // configure USER button as input
    runCommand("cd /sys/class/gpio");
    runCommand("echo 72 > export");
    runCommand("cd /sys/class/gpio/gpio72");
    runCommand("echo 1 > active_low");

    playGame(10000); //10000ms is a temporary max score to be rewritten
    
    ledAllOff();

    return 0;
}



void writeToFile(char file[], char status[])
{
    // code to adjust the trigger of LED
    FILE *pFile = fopen(file, "w");
    if (pFile == NULL)
    {
        printf("ERROR OPENING %s.", file);
        exit(1);
    }
    int charWritten = fprintf(pFile, status);
    if (charWritten <= 0)
    {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pFile);
}



static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}



static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}



static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}



char readFromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);
    return *buff;
    // printf("Read: '%s'\n", buff);
}



void ledAllOff(void) {
    // set all LED triggers to none and turn off all LEDs
    writeToFile(triggerLED0, "none");
    writeToFile(brightLED0, "0");
    writeToFile(triggerLED1, "none");
    writeToFile(brightLED1, "0");
    writeToFile(triggerLED2, "none");
    writeToFile(brightLED2, "0");
    writeToFile(triggerLED3, "none");
    writeToFile(brightLED3, "0");
}



void playGame(int currentBest) {
    long long responseTime = 5000;
    //wait while user holds down user button
    while (readFromFileToScreen(userButtonValue) == '0') {
        if (readFromFileToScreen(userButtonValue) == '1') {
            break;
        }
    }
    //light up only LED 0
    writeToFile(brightLED0, "1");
    writeToFile(brightLED1, "0");
    writeToFile(brightLED2, "0");
    writeToFile(brightLED3, "0");
    //wait a random time between 0.5 - 3 seconds
    sleepForMs((rand() % (3000 - 500 + 1)) + 500);
    //if user is pressing button already, record response time as 5000ms
    if (readFromFileToScreen(userButtonValue) == '0') {
        responseTime = 5000;
    } else {
        //light up LED 3
        writeToFile(brightLED1, "0");
        writeToFile(brightLED2, "0");
        writeToFile(brightLED3, "1");
        //start timer
        unsigned long long startTime = getTimeInMs();
        //wait for input
        unsigned int inputReceived = 0;
        while (inputReceived == 0) {
            if (getTimeInMs() - startTime > 5000) { //if 5000ms elapsed without input
                printf("No input within 5000ms, quitting!\n");
                return;
            }
            if (readFromFileToScreen(userButtonValue) == '0') { //button pressed
                inputReceived = 1;
                unsigned long long endTime = getTimeInMs();
                responseTime = endTime - startTime;
            }
        }
    }
    //light up all LEDs
    writeToFile(brightLED0, "1");
    writeToFile(brightLED1, "1");
    writeToFile(brightLED2, "1");
    writeToFile(brightLED3, "1");
    //update best time
    if (responseTime <= currentBest) {
        currentBest = responseTime;
        printf("New best time!\n");
    }
    printf("Your reaction time was %llums; best so far in game is %dms.\n", responseTime, currentBest);
    playGame(currentBest);
}