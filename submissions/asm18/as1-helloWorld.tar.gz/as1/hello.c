//hello.c creates a program to run on a Beaglebone. This program tests the user's
//reaction time by lighting up an LED and seeing how fast the user reacts.
//Done by: Amrit S. Mangat

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include <string.h>

#define LED_0 "/sys/class/leds/beaglebone:green:usr0"
#define LED_1 "/sys/class/leds/beaglebone:green:usr1"
#define LED_2 "/sys/class/leds/beaglebone:green:usr2"
#define LED_3 "/sys/class/leds/beaglebone:green:usr3"

#define USER_BUTTON "/sys/class/gpio/gpio72"

#define MAX_TIME 5000

void initialize();
void closeFiles();
static void runCommand(char* command);
void setUpLED(char* pathLED,FILE* trigger, FILE* brightness);
void setLEDTrigger(FILE* pathTrigger,char *value);
void setLEDBrightness(FILE* pathBrightness, char* value);
char getUserButtonValue();
static void sleepForMs(long long delayInMs);
static long long getTimeInMs(void);
void setLEDOn(FILE* LED);
void setAllLEDOff();
void setAllLEDOn();
void setAllLEDTrigger(char* value);
long long int checkResult(long long current,long long best);

FILE *pLED_0_TriggerFile;
FILE *pLED_0_BrightnessFile;
FILE *pLED_1_TriggerFile;
FILE *pLED_1_BrightnessFile;
FILE *pLED_2_TriggerFile;
FILE *pLED_2_BrightnessFile;
FILE *pLED_3_TriggerFile;
FILE *pLED_3_BrightnessFile;

int MAX_RAND_TIME = 3000;
int MIN_RAND_TIME = 500;
int MAX_TIMER_TIME = 5000;
char* LED_ON = "1";
char* LED_OFF = "0";

int main(int argc, char* args[])
{
      initialize();
      printf("Hello embedded world, from Amrit!\n\n");

      printf("When LED3 lights up, press the USER button!\n");
      setAllLEDTrigger("none");
      
      bool exit=false;

      setAllLEDOff();
      long long best_time = MAX_TIME;
      while(!exit){
        

        while(getUserButtonValue() == '0'){
          //button pressed do nothing
          
        }

        setAllLEDOff();

        setLEDOn(pLED_0_BrightnessFile);

        sleepForMs((rand() % (MAX_RAND_TIME-MIN_RAND_TIME+1))+MIN_RAND_TIME);

        if(getUserButtonValue() == '0'){
          best_time = checkResult(MAX_TIME,best_time);
        }
        else{
          setLEDOn(pLED_3_BrightnessFile);
          long long start_time = getTimeInMs();
          while(getUserButtonValue() != '0'){
            if(((getTimeInMs()-start_time)>=MAX_TIMER_TIME)){
              printf("No input within 5000ms; quitting!\n");
              exit = true;
              fflush(stdout);
              break;
            }

          }
          if(!exit){
          best_time = checkResult(getTimeInMs()-start_time,best_time);
          }
          
        }
        setAllLEDOn();
      }

      setAllLEDOff();

      closeFiles();
    
      return 0; 
}

void initialize(){
      srand(time(0));
      //LED_0 Set-Up
      pLED_0_TriggerFile = fopen(LED_0"/trigger","w");
      pLED_0_BrightnessFile = fopen(LED_0"/brightness","w");

      if(pLED_0_TriggerFile == NULL){
        printf("ERROR OPENING %s/trigger",LED_3);
        exit(1);
      }

      if(pLED_0_BrightnessFile == NULL){
        printf("ERROR OPENING %s/brightness",LED_3);
        exit(1);
      }

      //LED_3 Set-Up
      pLED_3_TriggerFile = fopen(LED_3"/trigger","w");
      pLED_3_BrightnessFile = fopen(LED_3"/brightness","w");

      if(pLED_3_TriggerFile == NULL){
        printf("ERROR OPENING %s/trigger",LED_3);
        exit(1);
      }

      if(pLED_3_BrightnessFile == NULL){
        printf("ERROR OPENING %s/brightness",LED_3);
        exit(1);
      }

      //LED2 Set-Up
      pLED_2_TriggerFile = fopen(LED_2"/trigger","w");
      pLED_2_BrightnessFile = fopen(LED_2"/brightness","w");

      if(pLED_2_TriggerFile == NULL){
        printf("ERROR OPENING %s/trigger",LED_2);
        exit(1);
      }

      if(pLED_2_BrightnessFile == NULL){
        printf("ERROR OPENING %s/brightness",LED_2);
        exit(1);
      }

      //LED1 Set-Up
      pLED_1_TriggerFile = fopen(LED_1"/trigger","w");
      pLED_1_BrightnessFile = fopen(LED_1"/brightness","w");

      if(pLED_1_TriggerFile == NULL){
        printf("ERROR OPENING %s/trigger",LED_1);
        exit(1);
      }

      if(pLED_1_BrightnessFile == NULL){
        printf("ERROR OPENING %s/brightness",LED_1);
        exit(1);
      }

      //USER Button Set-Up
      runCommand("config-pin p8.43 gpio");
      runCommand("cd /sys/class/gpio/gpio72 && echo in > direction");

}

void closeFiles(){
  fclose(pLED_0_BrightnessFile);
  fclose(pLED_0_TriggerFile);
  fclose(pLED_1_BrightnessFile);
  fclose(pLED_1_TriggerFile);
  fclose(pLED_2_BrightnessFile);
  fclose(pLED_2_TriggerFile);
  fclose(pLED_3_BrightnessFile);
  fclose(pLED_3_TriggerFile);
}

void setAllLEDTrigger(char* value){
  setLEDTrigger(pLED_0_TriggerFile,value);
  setLEDTrigger(pLED_1_TriggerFile,value);
  setLEDTrigger(pLED_2_TriggerFile,value);
  setLEDTrigger(pLED_3_TriggerFile,value);
}

void setAllLEDOff(){
      setLEDBrightness(pLED_0_BrightnessFile,LED_OFF);
      setLEDBrightness(pLED_1_BrightnessFile,LED_OFF);
      setLEDBrightness(pLED_2_BrightnessFile,LED_OFF);
      setLEDBrightness(pLED_3_BrightnessFile,LED_OFF);
}

void setAllLEDOn(){
      setLEDBrightness(pLED_0_BrightnessFile,LED_ON);
      setLEDBrightness(pLED_1_BrightnessFile,LED_ON);
      setLEDBrightness(pLED_2_BrightnessFile,LED_ON);
      setLEDBrightness(pLED_3_BrightnessFile,LED_ON);
}
void setLEDOn(FILE* LED){
      setLEDBrightness(LED,LED_ON);

}

void setLEDBrightness(FILE* pathBrightness,char* value){
      int charWritten = fprintf(pathBrightness,value);
      if(charWritten <= 0){
        printf("ERROR WRITING DATA");
        exit(1);
      }
    fflush(pathBrightness);
}

void setLEDTrigger(FILE* pathTrigger,char* value){
      int charWritten = fprintf(pathTrigger,value);
      if(charWritten <= 0){
        printf("ERROR WRITING DATA");
        exit(1);
      }
      fflush(pathTrigger);
}

char getUserButtonValue(){
  FILE *pFile = fopen(USER_BUTTON"/value", "r"); if (pFile == NULL) {
  printf("ERROR: Unable to open file (%s) for read\n", USER_BUTTON);
  exit(-1); }
        // Read string (line)
  const int MAX_LENGTH = 1024; 
  char buff[MAX_LENGTH];
  fgets(buff, MAX_LENGTH, pFile);
  // Close
  fclose(pFile);
  return buff[0];
}

long long int checkResult(long long current, long long best){
  if(current<best){
    printf("New Best Time!\n");
    best = current;
  }
  printf("Your reaction time was %4lldms; best so far in game is %4lldms\n",current,best);
  return best;
  fflush(stdout);
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
                 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer);  // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf("  command:   %s\n", command);
        printf("  exit code: %d\n", exitCode);
} }


