#include <stdio.h> 
#include <stdlib.h>
#include <time.h>
#include <stdint.h>
#include <stdbool.h>

#define DEBUG 0

static long long getTimeInMs(void);
static void sleepForMs(long long delayInMs);
static void runCommand(char* command);
static void initLEDs(void);
static void initUserbutton(void);
static bool isUserButtonPressed(void);
static void lightUpLED(int ledNumber);
static void turnOffLED(int ledNumber);
static void waitRandomTime(void);


int main(int argc, char* args[])
{
    //show welcome msg
    printf("Hello embedded world, from Thomas Kingsman!\n\n");

    //init
    initLEDs();
    initUserbutton();

    //run game forever until break condition is hit 
    printf("When LED3 lights up, press the USER button!\n");
    int bestScore = 5000;
    long long startTime = 0;
    bool runGame = true;

    while(runGame)
    {
        #if DEBUG >= 3
            printf("Entered while loop.\n");
        #endif

        //1:
        //loop until user button isnt pressed 
        bool startGame = true;
        do
        {
            if(isUserButtonPressed()) {
                #if DEBUG >= 2
                    printf("USER pressed too early!\n");
                #endif

                startGame = false;
            }
            else {
                startGame = true;
            }
            sleepForMs(1); //debounce
        } 
        while (!startGame);

        int responseTime = 5000;

        turnOffLED(0);
        turnOffLED(1);
        turnOffLED(2);
        turnOffLED(3);
        
        //2: 
        lightUpLED(0);

        //3: 
        waitRandomTime();

        //4: 
        if(isUserButtonPressed())
        {
            printf("Input too early; quitting!\n");
            break;
        }

        //5: 
        lightUpLED(3);
        startTime = getTimeInMs();
        #if DEBUG >= 1 
            printf("%lld\n", startTime);
        #endif

        //6: 
        //wait til press
        bool userPressed = isUserButtonPressed();
        bool noResponse = false;
        while(!userPressed)
        {
            long long timeDiff = getTimeInMs() - startTime;
            if(timeDiff >= 5000) {
                noResponse = true;
                break;
            }
            userPressed = isUserButtonPressed();
            sleepForMs(1); //debounce
        }
        //check to see if broke by cause of no input 
        if(noResponse)
        {
            printf("No input within 5000ms; quitting!\n");
            break;
        }

        //stop timer once pressed 
        responseTime = getTimeInMs() - startTime;

        //7:
        lightUpLED(0);
        lightUpLED(1);
        lightUpLED(2);
        lightUpLED(4);

        //8:
        if(responseTime < bestScore) {
            bestScore = responseTime;
            printf("New best time!\n");
        }
        printf("Your reaction time was %4dms; best so far in game is %4dms\n", responseTime, bestScore);
    }
    
    initLEDs();

    return 0;
}


static void initLEDs(void)
{
    runCommand("echo none > /sys/class/leds/beaglebone\\:green\\:usr0/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone\\:green\\:usr1/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone\\:green\\:usr2/trigger");
    runCommand("echo none > /sys/class/leds/beaglebone\\:green\\:usr3/trigger");

    runCommand("echo 0 > /sys/class/leds/beaglebone\\:green\\:usr0/brightness");
    runCommand("echo 0 > /sys/class/leds/beaglebone\\:green\\:usr1/brightness");
    runCommand("echo 0 > /sys/class/leds/beaglebone\\:green\\:usr2/brightness");
    runCommand("echo 0 > /sys/class/leds/beaglebone\\:green\\:usr3/brightness");

    #if DEBUG >= 1
        printf("Initialized LEDs.\n");
    #endif

    return;
}


static void initUserbutton(void)
{
    runCommand("config-pin p8.43 gpio");

    sleepForMs(500); //500 not 300 in case of small delay discrepancies 

    runCommand("echo in > /sys/class/gpio/gpio72/direction");
    runCommand("echo 1 > /sys/class/gpio/gpio72/active_low");

    #if DEBUG >= 1
        printf("Initialized user button.\n");
    #endif

    return;
}

static bool isUserButtonPressed(void)
{
    FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", "/sys/class/gpio/gpio72/value");
        exit(-1);
    }
    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);
    // Close
    fclose(pFile);

    #if DEBUG >= 2
        printf("Read from file: '%s'\n", buff);
    #endif
    
    if(buff[0] == '1') {
        #if DEBUG >= 2
            printf("Returned true from isUserButtonPressed()!\n");
        #endif

        return true;
    }
    else {
        return false;
    }
}

static void lightUpLED(int ledNumber)
{
    //49 variable
    //61 total
    char commandString[61] = "echo 1 > /sys/class/leds/beaglebone\\:green\\:usr0/brightness";

    if(ledNumber > 3 || ledNumber < 0) {
        return;
    }
    else {
        sprintf(commandString, "echo 1 > /sys/class/leds/beaglebone\\:green\\:usr%d/brightness", ledNumber);
    }

    #if DEBUG >= 2
        printf("Running command:\n");
        printf(commandString);
        printf("\n");
    #endif

    runCommand(commandString);
    return;
}

static void turnOffLED(int ledNumber)
{
    char commandString[61] = "echo 0 > /sys/class/leds/beaglebone\\:green\\:usr0/brightness";

    if(ledNumber > 3 || ledNumber < 0) {
        return;
    }
    else {
        sprintf(commandString, "echo 0 > /sys/class/leds/beaglebone\\:green\\:usr%d/brightness", ledNumber);
    }

    #if DEBUG >= 2
        printf("Running command:\n");
        printf(commandString);
        printf("\n");
    #endif

    runCommand(commandString);
    return;
}

static void waitRandomTime(void)
{
    int randomTime = (rand() % 2500) + 500; //500 to 3000 ms

    #if DEBUG >= 1
        printf("Waiting for %d ms.\n", randomTime);
    #endif

    sleepForMs(randomTime);
    return;
}


//get time function, taken from a1 outline 
static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + (nanoSeconds / 1000000);
    return milliSeconds;
}


//sleep func, taken from a1 outline
static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}


//run linux command func, taken from a1 outline 
static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
            // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}
