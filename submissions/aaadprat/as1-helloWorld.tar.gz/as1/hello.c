//Come play and become the quickest with ENSC351's latest time reaction recording game

//This game  does not begin until the user releases the user button (if at all pressed)

//LED0 will indicate when you're in the game

//LED3 will indicate that the timer has begun, press the user button
//if you're already pressing the user button before the next timer begins
//the game will catch you cheating and put your response time to be 5000ms
//and turn on all LEDs

//if you don't press the user button for 5secs after the timer begins, it will exit.
//turn on all LEDs 

//Otherwise keep playing and Enjoy! 
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#define trigger_LED0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define brightness_LED0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define trigger_LED1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define brightness_LED1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define trigger_LED2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define brightness_LED2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define trigger_LED3 "/sys/class/leds/beaglebone:green:usr3/trigger"
#define brightness_LED3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define user_bttn "/sys/class/gpio/gpio72/value"

static void runCommand(char* command)
{
	// Execute the shell command (output into pipe)
	FILE *pipe = popen(command, "r");
	// Ignore output of the command; but consume it
	// so we don't get an error when closing the pipe.
	char buffer[1024];
	while (!feof(pipe) && !ferror(pipe)) {
	if (fgets(buffer, sizeof(buffer), pipe) == NULL)
	break;
	// printf("--> %s", buffer); // Uncomment for debugging
	}
	// Get the exit code from the pipe; non-zero is an error:
	int exitCode = WEXITSTATUS(pclose(pipe));
	if (exitCode != 0) {
	perror("Unable to execute command:");
	printf(" command: %s\n", command);
	printf(" exit code: %d\n", exitCode);
	}
}

//TURNS OFF ALL THE LEDs
void turnOff_LEDS()
{
	FILE *pFile0_brightness = fopen(brightness_LED0, "w");
	if (pFile0_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	// Write to data to the file using fprintf()://
	int Led_switch0 = fprintf(pFile0_brightness, "0");
	if (Led_switch0 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile0_brightness);

	FILE *pFile1_brightness = fopen(brightness_LED1, "w");
	if (pFile1_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	// Write to data to the file using fprintf()://
	int Led_switch1 = fprintf(pFile1_brightness, "0");
	if (Led_switch1 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile1_brightness);

	FILE *pFile2_brightness = fopen(brightness_LED2, "w");
	if (pFile2_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	// Write to data to the file using fprintf()://
	int Led_switch2 = fprintf(pFile2_brightness, "0");
	if (Led_switch2 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile2_brightness);

	FILE *pFile3_brightness = fopen(brightness_LED3, "w");
	if (pFile3_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	// Write to data to the file using fprintf()://
	int Led_switch3 = fprintf(pFile3_brightness, "0");
	if (Led_switch3 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile3_brightness);
}

//used professor's code given for assignment1
static void sleepForMs(long long delayInMs)
{
	 const long long NS_PER_MS = 1000 * 1000;
	 const long long NS_PER_SECOND = 1000000000;
	 long long delayNs = delayInMs * NS_PER_MS;
	 int seconds = delayNs / NS_PER_SECOND;
	 int nanoseconds = delayNs % NS_PER_SECOND;
	 struct timespec reqDelay = {seconds, nanoseconds};
	 nanosleep(&reqDelay, (struct timespec *) NULL);
}

//trigger's the LEDs to none so that user can control the LEDs themselves
void triggerFunc_ALEDs()
{
	//triggering LED0//
	FILE *pLed0_TriggerFile = fopen(trigger_LED0, "w");
	if (pLed0_TriggerFile == NULL){
		printf("ERROR: Unable to open the trigger file.\n");
		exit(1);
	}

	// Write data to the file using fprintf()://
	int charWritten0 = fprintf(pLed0_TriggerFile, "none");
	if (charWritten0 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	//closing the file
	fclose(pLed0_TriggerFile);

	//Turning on LED1//
	FILE *pLed1_TriggerFile = fopen(trigger_LED1, "w");
	if (pLed1_TriggerFile == NULL){
		printf("ERROR: Unable to open the trigger file.\n");
		exit(1);
	}

	// Write to data to the file using fprintf()://
	int charWritten1 = fprintf(pLed1_TriggerFile, "none");
	if (charWritten1 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	//closing the file
	fclose(pLed1_TriggerFile);

	//Triggering LED2//
	FILE *pLed2_TriggerFile = fopen(trigger_LED2, "w");
	if (pLed2_TriggerFile == NULL){
		printf("ERROR: Unable to open the trigger file.\n");
		exit(1);
	}

	// Write to data to the file using fprintf()://
	int charWritten2 = fprintf(pLed2_TriggerFile, "none");
	if (charWritten2 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	//closing the file
	fclose(pLed2_TriggerFile);

	//Triggering LED3//
	FILE *pLed3_TriggerFile = fopen(trigger_LED3, "w");
	if (pLed3_TriggerFile == NULL){
		printf("ERROR: Unable to open the trigger file.\n");
		exit(1);
	}

	// Write to data to the file using fprintf()://
	int charWritten3 = fprintf(pLed3_TriggerFile, "none");
	if (charWritten3 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	//closing the file
	fclose(pLed3_TriggerFile);
}

int readFromFileToScreen(char *fileName)
{
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
	printf("ERROR: Unable to open file (%s) for read\n", fileName);
	exit(-1);
	}
	// Read string (line)
	const int MAX_LENGTH = 1024;
	char buff[MAX_LENGTH];
	fgets(buff, MAX_LENGTH, pFile);
	// Close
	fclose(pFile);
	///printf("Read: '%s'\n", buff);
	//converting char* to int to return the USER BUTTON's value
	//GPIO72
	int userVal = atoi(buff);
	return userVal;
}

//TURNS ON THE LED0 
void brightFunc_LED0()
{
	FILE *pFile0_brightness = fopen(brightness_LED0, "w");
	if (pFile0_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	// Write to data to the file using fprintf()://
	int Led_switch0 = fprintf(pFile0_brightness, "1");
	if (Led_switch0 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile0_brightness);
}

//TURNS ON LED3
void brightFunc_LED3()
{
	//Brightness LED3
	FILE *pFile3_brightness = fopen(brightness_LED3, "w");
	if (pFile3_brightness == NULL){
		printf("ERROR: Unable to open the brightness file.\n");
		exit(1);
	}

	// Write to data to the file using fprintf():
	int Led_switch3 = fprintf(pFile3_brightness, "1");
	if (Led_switch3 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	//closing the file
	fclose(pFile3_brightness);
}

//TURNS ON ALL LEDS
void brightFunc_ALEDs()
{
	FILE *pFile0_brightness = fopen(brightness_LED0, "w");
	if (pFile0_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	// Write to data to the file using fprintf()://
	int Led_switch0 = fprintf(pFile0_brightness, "1");
	if (Led_switch0 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile0_brightness);

	//Brightness LED1//
	FILE *pFile1_brightness = fopen(brightness_LED1, "w");
	if (pFile1_brightness == NULL){
		printf("ERROR: Unable to open the brightness file.\n");
		exit(1);
	}

	 //Write to data to the file using fprintf()://
	int Led_switch1 = fprintf(pFile1_brightness, "1");
	if (Led_switch1 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	//closing the file
	fclose(pFile1_brightness);

	//Brightness LED2//
	FILE *pFile2_brightness = fopen(brightness_LED2, "w");
	if (pFile2_brightness == NULL){
		printf("ERROR: Unable to open the brightness file.\n");
		exit(1);
	}

	 //Write to data to the file using fprintf()://
	int Led_switch2 = fprintf(pFile2_brightness, "1");
	if (Led_switch2 <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}

	//closing the file
	fclose(pFile2_brightness);	

	FILE *pFile3_brightness = fopen(brightness_LED3, "w");
	if (pFile3_brightness == NULL){
	printf("ERROR: Unable to open the brightness file.\n");
	exit(1);
	}

	//Write to data to the file using fprintf()://
	int Led_switch3 = fprintf(pFile3_brightness, "1");
	if (Led_switch3 <= 0) {
	printf("ERROR WRITING DATA");
	exit(1);
	}

	fclose(pFile3_brightness);
}

//RECORDS CURRENT TIME
static long long getTimeInMs(void)
{
	 struct timespec spec;
	 clock_gettime(CLOCK_REALTIME, &spec);
	 long long seconds = spec.tv_sec;
	 long long nanoSeconds = spec.tv_nsec;
	 long long milliSeconds = seconds * 1000
	 + nanoSeconds / 1000000;
	 return milliSeconds;
}


///////////////////////////////////////////////////////////////////////////////


int main()
{

printf("Hello embedded world, from Aadpratap\n \n");
printf("When LED3 lights up, press the USER button");

//run commands
runCommand("config-pin p8.43 gpio");
runCommand("echo 72 > export");

//flag- to check if it is time to check 5sec rule for cheating
bool flag = false;
long long lastTime_bttnPressed= 0;
long long response_time;	
long long best_response_time = 6000;

triggerFunc_ALEDs();
turnOff_LEDS();

while(1){
	if (readFromFileToScreen(user_bttn) == 0){
		lastTime_bttnPressed = getTimeInMs();
		 continue;
	}
	else
	{
		break;
	}
}

while(1){
	
	//TURN ON LED0//
	brightFunc_LED0();
	long long random_delay = (rand() % (3000 - 500 + 1)) + 500;
	sleepForMs(random_delay);

  	if(readFromFileToScreen(user_bttn) == 0){
		brightFunc_ALEDs();
		response_time = 5000;
		lastTime_bttnPressed = getTimeInMs();
		printf("Uh Oh, Cheating. The reaction time is %lld \n", response_time);
		continue;
	}

	turnOff_LEDS();
	brightFunc_LED0();
	
	//I have added this delay because both the LEDs (0 and 3) lighting up together
	//and I wanted LED3 to look like a timer
	long long LED_delay = (rand() % (300 -100 + 1)) + 100;
	sleepForMs(LED_delay);

 	//LIGHT up LED3
     brightFunc_LED3();

  	//starting timer 
 	long long initial_time = getTimeInMs();
	long long current_time = 0;
	long long terminating_time = 0;
 	long long final_time = 0;
	

 	while(1){
		current_time = getTimeInMs();
		if(flag == true){
			terminating_time = current_time - lastTime_bttnPressed;
		 	if (terminating_time > 5000)//printf("the termingating time is %lld ",terminating_time);
		 	break;
		 }

 		if(readFromFileToScreen(user_bttn) == 0){
			final_time = getTimeInMs();
			lastTime_bttnPressed = getTimeInMs();
			flag = true;
			response_time = final_time - initial_time;

			if(best_response_time > response_time){
 			best_response_time = response_time;
			printf("New best time! \n");
 			}

			brightFunc_ALEDs();
			printf("Your reaction time is %lld; ", response_time);
 			printf("best so far in the game is %lld \n", best_response_time);
			break;
		}
	}
 	
	if(terminating_time > 5000)
	{
		printf("No input witin 5000ms; quitting! \n");
		triggerFunc_ALEDs();
		brightFunc_ALEDs();
		//turnOff_LEDS();
		exit(1);
	}

}
			
return 0;

}
