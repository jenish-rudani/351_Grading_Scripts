#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <stdbool.h>

#define userButton "/sys/class/gpio/gpio72/value"
#define led0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define led1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define led2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define led3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define ledT0 "/sys/class/leds/beaglebone:green:usr0/trigger"
#define ledT1 "/sys/class/leds/beaglebone:green:usr1/trigger"
#define ledT2 "/sys/class/leds/beaglebone:green:usr2/trigger"
#define ledT3 "/sys/class/leds/beaglebone:green:usr3/trigger"

enum userButtonPosition { Pressed, UnPressed };

//From Assignment Guide
static void sleepForMs(long long delayInMs){
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

//From Assignment Guide
static long long getTimeInMs(void){
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

//From Assignment Guide
int readFromFileToScreen(char *fileName) {
	FILE *file = fopen( fileName, "r");
	if (file == NULL) {
		printf( "ERROR: Unable to open file (%s) for read\n", fileName);
		exit(-1);
	}
    // Read string (line)
	const int max_length = 1024;
	char buff[max_length];
	fgets(buff, max_length, file);
    // Close
	fclose(file);
	return atoi(buff);
}

//From Assignment Guide
void writeFromFileToScreen(char *fileName, int value) {
	FILE *file = fopen( fileName, "w");
	if (file == NULL) {
		printf( "ERROR: Unable to open file (%s) for read\n", fileName);
		exit(-1);
	}
    fprintf(file,"%d", 1);
	fclose(file);
}

//From Assignment Guide
static void runCommand(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }
    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

void initialization() {
    //printf("Start initialise func\n");
	FILE *pfile1 = fopen(led0, "w");
	FILE *pfile2 = fopen(led1, "w");
	FILE *pfile3 = fopen(led2, "w");
	FILE *pfile4 = fopen(led3, "w");

	if (!pfile1 || !pfile2 || !pfile3 || !pfile4) {
		printf("ERROR: Unable to open export file.\n");
		exit(1);
	}
	fprintf(pfile1,"%d", 0);
	fprintf(pfile2,"%d", 0);
	fprintf(pfile3,"%d", 0);
	fprintf(pfile4,"%d", 0);

	fclose(pfile1);
	fclose(pfile2);
	fclose(pfile3);
	fclose(pfile4);
    //printf("end initialise func\n");
}

void brightness(char *file ,int val) {
	FILE *pLedBrightnessFile = fopen(file, "w");
	if (pLedBrightnessFile == NULL) {
		printf("ERROR OPENING %s.", led0);
	}
	fprintf(pLedBrightnessFile,"%d", val);
	fclose(pLedBrightnessFile);
}

enum userButtonPosition buttonPosition() {
    //printf("IN enum func\n");
	if (readFromFileToScreen(userButton) == 0) {
		return Pressed;
	} else {
		return UnPressed;
	}
}

//Turn off all LEDs
void clean() {
	initialization();
}

int main(){
    printf("Hello embedded world, from Shravan!\n \nWhen LED 0 lights up, press the USER button!\n");
    initialization();
    
    long long startTime = 0;
    long long endTime = 0;
	long long responseTime = 0;
	long long bestResponseTime = 5000;
	srand(time(NULL));

	while(1) {
        runCommand("config-pin p8.43 gpio");
		enum userButtonPosition position = buttonPosition();
        //printf("%d\n",position);

		while (position == Pressed) {
            position = buttonPosition();
            //printf("%d\n",position);
			if (position == UnPressed){
				break;
			} 
		}
        //Light up LED 0
        brightness(led0,1);

        double r =  0.5 + ((double)rand()/RAND_MAX) * (3 - 0.5);
        r = r*1000;
        //printf("Random number- %f\n", r);
        sleepForMs(r);

        position = buttonPosition();
        if(position == Pressed){
            responseTime = 5000;
            bestResponseTime = 5000;
            printf("Your reaction time was %lldms; best so far in game is %lldms.\n",responseTime, bestResponseTime);
            break;
        }

        //Light up LED 3 ans start timer
        brightness(led3,1);
        //printf("Timer starts hereeeeee\n");
        startTime  = getTimeInMs(); 

        while(position == UnPressed){
            position = buttonPosition();
            if(position == Pressed){
                endTime = getTimeInMs();
                responseTime = endTime - startTime;

                if(responseTime <= bestResponseTime){
                    bestResponseTime = responseTime;
                    printf("New best time!\n");
                }
                printf("Your reaction time was %lldms; best so far in game is %lldms.\n",responseTime, bestResponseTime);
            }
            endTime = getTimeInMs();
            if((endTime - startTime) > 5000){
                printf("No input within 5000ms; quitting!\n");
                clean();
                return 0;
            }
        }
	}
    brightness(led0,1);
    brightness(led1,1);
    brightness(led2,1);
    brightness(led3,1);

    clean();
	return 0;
}
