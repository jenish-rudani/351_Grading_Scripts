//Assignment 1 ENSC 351 (CMPT 433): This is a program that displays helloworld and plays a LED and button game
//This program will continously loop through a sequence of steps to play a game which displays the current response
//of the user and best response time in the game so far. Response time will be determined by the user pressing the USER button. 

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define LED0_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_TRIGGER_FILE "/sys/class/leds/beaglebone:green:usr3/trigger"

#define LED0_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_BRIGHTNESS_FILE "/sys/class/leds/beaglebone:green:usr3/brightness"

#define USER_BUTTON_VALUE_FILE "/sys/class/gpio/gpio72/value"

FILE* openTriggerFile(char* LEDTriggerFile, char* type){
    FILE *pLEDTriggerFile = fopen (LEDTriggerFile, type);
    if (pLEDTriggerFile == NULL){
        printf("ERROR OPENING %s.", LED0_TRIGGER_FILE);
        exit(1);
    }

    return pLEDTriggerFile;
    
}

void writeToLED(char* LEDTriggerFile, char* value){
    FILE* pLEDTriggerFile =  openTriggerFile(LEDTriggerFile, "w");
    int charWritten = fprintf(pLEDTriggerFile, value);
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    fclose(pLEDTriggerFile);
}

void changeLEDState(char* LEDBrightnessFile, char* onORoff){
    FILE *pLedBrightnessFile = fopen(LEDBrightnessFile, "w");
    if (pLedBrightnessFile == NULL){
        printf("ERROR OPENING %s.", LEDBrightnessFile);
        exit(1);
    }

    int brightnessValue = fprintf(pLedBrightnessFile, onORoff);
    if (brightnessValue <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);
    }
    
    fclose(pLedBrightnessFile);
}


static void sleepForMs(long long delayInMs){
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoSeconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoSeconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command){

    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it 
    // so we don't get an error when closing the pipe. 
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL){
            break;
        }
        // printf("--> %s", buffer);
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0){
        perror("Unable to execute command:");
        printf(" command:   %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }

}

int readFromFileToScreen(char *fileName){
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL){
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);

    // Close
    fclose(pFile);
    return atoi(buff);
    // printf("Read: '%s\n", buff);
}

// Used to get current time
static long long getTimeInMs(void){
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec; 
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}


int main(int argc, char* args[])
{
    printf("Hello embedded world, from Jaspreet!\n\n");
    printf("When LED3 lights up, press the USER button!\n");
    // Executing config-pin to force the button's pin to be treated as GPIO
    runCommand("config-pin p8.43 gpio"); // NOTE TO SELF: 0 means pressed and 1 means not pressed

    int responseTime = 0;
    int bestResponseTime = 0;
    int oldResponseTime = 0;
    int lowesetTimeInMs = 500;
    int hightestTimeInMs = 3000;
    long long timeToSleep = 0;

    srand(time(NULL));
    
    writeToLED(LED0_TRIGGER_FILE, "none");
    writeToLED(LED1_TRIGGER_FILE, "none");
    writeToLED(LED2_TRIGGER_FILE, "none");
    writeToLED(LED3_TRIGGER_FILE, "none");
    

    for (int i=0; i>=0; i++){


        oldResponseTime = bestResponseTime;
        int userButtonState = readFromFileToScreen(USER_BUTTON_VALUE_FILE);
        while (userButtonState == 0){
            userButtonState = readFromFileToScreen(USER_BUTTON_VALUE_FILE);
        }
        changeLEDState(LED0_BRIGHTNESS_FILE, "1");
        changeLEDState(LED1_BRIGHTNESS_FILE, "0");
        changeLEDState(LED2_BRIGHTNESS_FILE, "0");
        changeLEDState(LED3_BRIGHTNESS_FILE, "0");
        
        timeToSleep = (rand() % (hightestTimeInMs-lowesetTimeInMs +1)) + lowesetTimeInMs;
        sleepForMs(timeToSleep);
        
        userButtonState = readFromFileToScreen(USER_BUTTON_VALUE_FILE);
        

        if ( userButtonState == 0) {
            responseTime = 5000; 
            if (bestResponseTime == 0 || responseTime <= bestResponseTime){
                bestResponseTime=responseTime;
            }

            changeLEDState(LED1_BRIGHTNESS_FILE, "1");
            changeLEDState(LED2_BRIGHTNESS_FILE, "1");
            changeLEDState(LED3_BRIGHTNESS_FILE, "1");

            if (oldResponseTime != bestResponseTime){
                printf("New best time!\n");
            }

            printf("Your reaction time was %4dms; best so far in the game is %4dms \n", responseTime, bestResponseTime);
            
        }

        else if (userButtonState == 1){
            changeLEDState(LED3_BRIGHTNESS_FILE, "1");
            long long startTimer = getTimeInMs();
            while(userButtonState == 1){
                userButtonState = readFromFileToScreen(USER_BUTTON_VALUE_FILE);
                if (getTimeInMs()-startTimer == 5000){
                    printf("No input within 5000ms; quitting!\n");
                    changeLEDState(LED0_BRIGHTNESS_FILE, "0");
                    changeLEDState(LED1_BRIGHTNESS_FILE, "0");
                    changeLEDState(LED2_BRIGHTNESS_FILE, "0");
                    changeLEDState(LED3_BRIGHTNESS_FILE, "0");
                    exit(1);
                }
            }
            
            if (userButtonState == 0){
                long long endTimer = getTimeInMs();
                responseTime = endTimer - startTimer;

                if (bestResponseTime == 0 || responseTime <= bestResponseTime){
                    bestResponseTime=responseTime;
                }

                changeLEDState(LED1_BRIGHTNESS_FILE, "1"); 
                changeLEDState(LED2_BRIGHTNESS_FILE, "1"); 
                changeLEDState(LED3_BRIGHTNESS_FILE, "1"); 

                if (oldResponseTime != bestResponseTime){
                    printf("New best time!\n");
                }

                printf("Your reaction time was %4dms; best so far in the game is %4dms \n", responseTime, bestResponseTime);

            }
            
        }
    }
    

    return 0;
}