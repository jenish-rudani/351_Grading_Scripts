#ifndef HELLO_H
#define HELLO_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>

#define MyLedTriggerFile "/sys/class/leds/beaglebone:green:usr"//add LED#/trigger afterwards
#define MyGPIOPinFile "/sys/class/gpio/gpio72" //maybe add (/folder?) afterwards

#define DEBUG_LEVEL 0
#define MAX_FILENAME 100

//open and initialize all LEDs used in this program
//set triggers to none
static void LED_Initialize(void);

//set a chosen LED to a steady light
static void LED_SingleLightUp(int LED_Num);

//set trigger to none
//close all LEDs used in this program
static void LED_ShutOff(void);

//turn off a chosen LED
static void LED_SingleShutOff(int LED_Num);

//configure the USER GPIO to accept inputs before it is used later in the program
static void GPIO_Initialize(void);

//Wait while USER button has undersired value
//Do not proceed until value has changed
//A value of zero means it is being pressed
//A value of one means it is not being pressed
static void GPIO_Wait(int GPIO_UndesiredValue);

//Wait while USER button has undersired value
//Do not proceed until value has changed or USER takes more than 5 seconds
//A value of zero means it is being pressed
//A value of one means it is not being pressed
static long long GPIO_WaitWithTimer(int GPIO_UndesiredValue);

//Perform a single scan of the USER button input
//A value of zero means it is being pressed
//A value of one means it is not being pressed
static int GPIO_Detect(void);

//Wait for a random time between 0.5 and 3 seconds as determed by the random number generator
static void Wait_RandomTime(void);

//Exit the program if the user takes more than 5 seconds to press the USER button during the game
static void Is_TimetoExit(long long time_taken);

//Calculate if the taken taken during the game has beaten the user's best time
static long long Is_BeatTime(long long time_taken, long long best_time);

//Get the current time in milliseconds
static long long Get_TimeInMs(void);

//Sleep for an inputted number of millliseconds
static void Sleep_ForMs(long long delayInMs);

//run a Linux command from the program
static void Run_Command(char* command);

//Read data from a file to the screen i.e. value
static int Read_FromFileToScreen(char *fileName);


#endif