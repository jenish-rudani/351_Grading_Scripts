#include "hello.h"

//function are defined below, then included in the main file hello.c

static void LED_Initialize(void)
{
    LED_SingleLightUp(0);
    LED_SingleLightUp(1);
    LED_SingleLightUp(2);
    LED_SingleLightUp(3);
}

static void LED_ShutOff(void)
{
    LED_SingleShutOff(0);
    LED_SingleShutOff(1);
    LED_SingleShutOff(2);
    LED_SingleShutOff(3);
}

static void LED_SingleLightUp(int LED_Num)
{
    int charWritten = 0;
    char fd_trigger[MAX_FILENAME+1];
    char fd_brightness[MAX_FILENAME+1];

    //print filepath of LED into a string to use in the fopen() functions below.
    snprintf(fd_trigger, MAX_FILENAME, MyLedTriggerFile"%d/trigger",LED_Num);
    snprintf(fd_brightness, MAX_FILENAME, MyLedTriggerFile"%d/brightness",LED_Num);

    FILE *pLedTriggerFileTrigger = fopen(fd_trigger, "w");
    if (pLedTriggerFileTrigger == NULL) {
        printf("ERROR OPENING %s.", fd_trigger);
        exit(1);
    }

    FILE *pLedTriggerFileBrightness = fopen(fd_brightness, "w");
    if (pLedTriggerFileBrightness == NULL) {
        printf("ERROR OPENING %s.", fd_brightness);
        exit(1);
    }

    charWritten = fprintf(pLedTriggerFileTrigger, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);    
    }

    charWritten = fprintf(pLedTriggerFileBrightness, "1");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);    
    }

    fclose(pLedTriggerFileTrigger);
    fclose(pLedTriggerFileBrightness);
}

static void LED_SingleShutOff(int LED_Num)
{
    int charWritten = 0;

    char fd_trigger[MAX_FILENAME+1];
    char fd_brightness[MAX_FILENAME+1];

    //print filepath of LED into a string to use in the fopen() functions below.
    snprintf(fd_trigger, MAX_FILENAME, MyLedTriggerFile"%d/trigger",LED_Num);
    snprintf(fd_brightness, MAX_FILENAME, MyLedTriggerFile"%d/brightness",LED_Num);

    FILE *pLedTriggerFileTrigger = fopen(fd_trigger, "w");
    if (pLedTriggerFileTrigger == NULL) {
        printf("ERROR OPENING %s.", fd_trigger);
        exit(1);
    }

    FILE *pLedTriggerFileBrightness = fopen(fd_brightness, "w");
    if (pLedTriggerFileBrightness == NULL) {
        printf("ERROR OPENING %s.", fd_brightness);
        exit(1);
    }

    charWritten = fprintf(pLedTriggerFileTrigger, "none");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);    
    }

    charWritten = fprintf(pLedTriggerFileBrightness, "0");
    if (charWritten <= 0) {
        printf("ERROR WRITING DATA");
        exit(1);    
    }

    fclose(pLedTriggerFileTrigger);
    fclose(pLedTriggerFileBrightness);
}

static void GPIO_Initialize(void)
{
    Run_Command("config-pin p8.43 gpio && cd " MyGPIOPinFile " && echo in > direction");//USER pin is 8.43 and GPIO number is 72. This configures the button's pin to be input
}

static void GPIO_Wait(int GPIO_UndesiredValue)
{   
    int GPIO_Value = 0;//Initialize GPIO_Value as 0. Value doesn't matter because of do_while loop
    //read the output of the USER pin. If it is the desired value, then exit the loop
    do{
        GPIO_Value = GPIO_Detect();
    }while(GPIO_Value == GPIO_UndesiredValue);
}

static long long GPIO_WaitWithTimer(int GPIO_UndesiredValue)
{
    int GPIO_Value = 0;//Initialize GPIO_Value as 0. Value doesn't matter because of do_while loop
    long long initial_time = Get_TimeInMs();//Get initial time
    long long time_taken = 5000;//Initialize time taken to 5000 ms
    LED_SingleLightUp(3);//Light up LED3

    //read the output of the USER pin. If it is the desired value, then exit the loop
    do{
        GPIO_Value = GPIO_Detect();

        //If the USER takes over 5000 ms, then it is time to exit the program
        long long final_time = Get_TimeInMs();
        time_taken = final_time - initial_time;
        Is_TimetoExit(time_taken);
    }while(GPIO_Value == GPIO_UndesiredValue);

    return time_taken;
}

static int GPIO_Detect(void)
{
    int GPIO_Value = Read_FromFileToScreen(MyGPIOPinFile "/value");
    return GPIO_Value;
}

static void Wait_RandomTime(void)
{
    time_t t;
    srand((unsigned) time(&t));
    Sleep_ForMs((rand()%2500 + 500));

}

static void Is_TimetoExit(long long time_taken)
{
    if(time_taken > 5000){
        printf("No input within 5000 ms; quitting!\n");
        LED_ShutOff();
        exit(0);
    }
}

static long long Is_BeatTime(long long time_taken, long long best_time)
{
    if(time_taken < best_time){
        printf("New best time!\n");
        return time_taken;
    }
    else{
        return best_time;
    }
}

static long long Get_TimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000
    + nanoSeconds / 1000000;
    return milliSeconds;
}

static void Sleep_ForMs(long long delayInMs)
{
    if(DEBUG_LEVEL > 0){
        printf("Time delayed: %lld\n", delayInMs);
    }
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void Run_Command(char* command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

static int Read_FromFileToScreen(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL) {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);

    // Close
    fclose(pFile);

    if(DEBUG_LEVEL > 0){
        printf("Read: %s\n", buff);
    }

    int ReturnAsInt;
    sscanf(buff, "%d", &ReturnAsInt);//convert read value to integer
    return ReturnAsInt;
}