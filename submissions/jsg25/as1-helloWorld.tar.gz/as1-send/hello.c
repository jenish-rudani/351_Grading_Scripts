#include "hello.h"
#include "hello_functions.c"

int main(){
    printf("Hello embedded world, from Jagpreet Grewal\n");

    long long best_time = 5000;//Initialize best time to 5000 ms
    int do_once = 0;//To only execute a command once in the while loop
    
    while(1){
        //Initialize LEDs and GPIO pins
        LED_Initialize();
        GPIO_Initialize();

        GPIO_Wait(0);//Wait while USER pin is being pressed
        
        //turn off all LEDs except LED0
        LED_SingleShutOff(1);
        LED_SingleShutOff(2);
        LED_SingleShutOff(3);
        if(do_once == 0){
            printf("When LED3 lights up, press the USER button!\n\n");//only execute this printf statement once
            do_once++;
        }

        //Use the random number generator to wait a time between 0.5 and 3 seconds
        Wait_RandomTime();

        int USER_current_value = GPIO_Detect();//Detect the current value of the USER button
        long long time_taken = 5000;//Initialize time_taken to 5000 ms.

        //if the user is not pressing the USER button then proceed normally. Otherwise, user's time remains to be 5000 ms.
        //If the user takes over 5000 ms, the program exits.
        if(USER_current_value == 1){
            time_taken = GPIO_WaitWithTimer(1);//Wait while USER pin is not pressed. Time how long the user takes.
        }

        best_time = Is_BeatTime(time_taken, best_time);
        printf("Your recation time was %4lld ms; best so far in game is %4lld ms.\n", time_taken,best_time);
    }

    return 0;
}