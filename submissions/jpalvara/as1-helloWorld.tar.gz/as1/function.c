#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "function.h"

void turnOnLed0()
{
    FILE *LEDHandle = NULL;
    const char *LED0Brightness= "/sys/class/leds/beaglebone:green:usr0/brightness";

	if((LEDHandle = fopen(LED0Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
        return 0;
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle);
 		fclose(LEDHandle);
 	}
}

void turnOffLed0()
{
    FILE *LEDHandle = NULL;
    const char *LED0Brightness= "/sys/class/leds/beaglebone:green:usr0/brightness";

	if((LEDHandle = fopen(LED0Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
        return 0;
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle);
 		fclose(LEDHandle);
 	}
}