#ifndef FUNCTION_H
#define FUNCTION_H

void led0;


#endif
