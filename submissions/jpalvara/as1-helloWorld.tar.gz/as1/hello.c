#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>


#define LED0BRIGHTNESS "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1BRIGHTNESS "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2BRIGHTNESS "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3BRIGHTNESS "/sys/class/leds/beaglebone:green:usr3/brightness"



void turnOnLed0();
void turnOffLed0();
void turnOnLed1();
void turnOffLed1();
void turnOnLed2();
void turnOffLed2();
void turnOnLed3();
void turnOffLed3();
char buttonPress();
//static long long getTimeInMs(void);


void turnOnLed0()
{
    FILE *LEDHandle0 = NULL;
    const char *LED0Brightness= "/sys/class/leds/beaglebone:green:usr0/brightness";
	const char *LED0Trigger= "/sys/class/leds/beaglebone:green:usr0/trigger";

	if((LEDHandle0 = fopen(LED0Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle0);
 		fclose(LEDHandle0);
 	}

	if((LEDHandle0 = fopen(LED0Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle0);
 		fclose(LEDHandle0);
 	}
}

void turnOffLed0()
{
    FILE *LEDHandle = NULL;
    const char *LED0Brightness= "/sys/class/leds/beaglebone:green:usr0/brightness";
	const char *LED0Trigger= "/sys/class/leds/beaglebone:green:usr0/trigger";

	if((LEDHandle = fopen(LED0Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle);
 		fclose(LEDHandle);
 	}

	if((LEDHandle = fopen(LED0Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle);
 		fclose(LEDHandle);
 	}
}

void turnOnLed1()
{
    FILE *LEDHandle1 = NULL;
    const char *LED1Brightness= "/sys/class/leds/beaglebone:green:usr1/brightness";
	const char *LED1Trigger= "/sys/class/leds/beaglebone:green:usr1/trigger";

	if((LEDHandle1 = fopen(LED1Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle1);
 		fclose(LEDHandle1);
 	}

	if((LEDHandle1 = fopen(LED1Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle1);
 		fclose(LEDHandle1);
 	}
}

void turnOffLed1()
{
    FILE *LEDHandle1 = NULL;
    const char *LED1Brightness= "/sys/class/leds/beaglebone:green:usr1/brightness";
	const char *LED1Trigger= "/sys/class/leds/beaglebone:green:usr1/trigger";

	if((LEDHandle1 = fopen(LED1Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle1);
 		fclose(LEDHandle1);
 	}

	if((LEDHandle1 = fopen(LED1Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle1);
 		fclose(LEDHandle1);
 	}
}

void turnOnLed2()
{
    FILE *LEDHandle2 = NULL;
    const char *LED2Brightness= "/sys/class/leds/beaglebone:green:usr2/brightness";
	const char *LED2Trigger= "/sys/class/leds/beaglebone:green:usr2/trigger";

	if((LEDHandle2 = fopen(LED2Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle2);
 		fclose(LEDHandle2);
 	}

	if((LEDHandle2 = fopen(LED2Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle2);
 		fclose(LEDHandle2);
 	}
}

void turnOffLed2()
{
    FILE *LEDHandle2 = NULL;
    const char *LED2Brightness= "/sys/class/leds/beaglebone:green:usr2/brightness";
	const char *LED2Trigger= "/sys/class/leds/beaglebone:green:usr2/trigger";

	if((LEDHandle2 = fopen(LED2Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle2);
 		fclose(LEDHandle2);
 	}

	if((LEDHandle2 = fopen(LED2Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle2);
 		fclose(LEDHandle2);
 	}
}


void turnOnLed3()
{
    FILE *LEDHandle3 = NULL;
    const char *LED3Brightness= "/sys/class/leds/beaglebone:green:usr3/brightness";
	const char *LED3Trigger= "/sys/class/leds/beaglebone:green:usr3/trigger";

	if((LEDHandle3 = fopen(LED3Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle3);
 		fclose(LEDHandle3);
 	}

	if((LEDHandle3 = fopen(LED3Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle3);
 		fclose(LEDHandle3);
 	}
}

void turnOffLed3()
{
    FILE *LEDHandle3 = NULL;
    const char *LED3Brightness= "/sys/class/leds/beaglebone:green:usr3/brightness";
	const char *LED3Trigger= "/sys/class/leds/beaglebone:green:usr3/trigger";

	if((LEDHandle3 = fopen(LED3Brightness, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("0", sizeof(char), 1, LEDHandle3);
 		fclose(LEDHandle3);
 	}

	if((LEDHandle3 = fopen(LED3Trigger, "w+")) == NULL){
 		printf("Error opening file!\n");
 	}
    else {
 		fwrite("1", sizeof(char), 1, LEDHandle3);
 		fclose(LEDHandle3);
 	}
}

char buttonPress()
{
	FILE *pFile = fopen("/sys/class/gpio/gpio72/value", "r");
	char buffer[1024];
	if (pFile == NULL) {
		printf("ERROR: Unable to open file.\n");

	}
	else {
		fgets(buffer, 1024, pFile);
		fclose(pFile);
	}


	return buffer[0];


}

static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");
    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
        break;
        // printf("--> %s", buffer); // Uncomment for debugging
        }
        // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}



 


int main(int argc, char* args[])
{
	//char buffer[100];
	//int userButtonPressed;

	char *configPin = "config-pin p8.43 gpio";
	runCommand(configPin);

	int bestTime = 0;
	int flag = 0;

	turnOnLed0();
	printf("Hello embedded world, from John Alvarado!\n\n");
	printf("When LED3 lights up, press the USER button!\n");


	

	while (1) {

		turnOnLed0();
		turnOffLed1();
		turnOffLed2();
		turnOffLed3();


		long seconds1 = 3;
		struct timespec reqDelay1 = {seconds1};
		char dino = buttonPress();

		do {

			dino = buttonPress();

			if (dino == '0') {
				flag = 1;
			}

			flag = 0;

		} while (nanosleep(&reqDelay1, (struct timespec *) NULL) && (dino == '1')); 



		if (flag == 1)
		{
			turnOnLed0();
			turnOnLed1();
			turnOnLed2();
			turnOnLed3();
			printf("Your reaction time was 5000ms; ");
			printf("best so far in game is  ");
			printf("%dms.\n", bestTime);
			flag = 0;
		}
		else if (flag == 0)
		{
	
			int milSecs = 0;
			char dino1= buttonPress();

			turnOnLed3();


			clock_t clockTimerStart = clock();
		


			while ((dino1 == '1') && (milSecs < 5001)){

				clock_t timeDifference = clock() - clockTimerStart;
				milSecs = timeDifference * 1000 / CLOCKS_PER_SEC;
				
				dino1= buttonPress();
				if (dino1 == '0')
				{
					clock_t timeDifference = clock() - clockTimerStart;
					milSecs = timeDifference * 1000 / CLOCKS_PER_SEC;
					break;
				}

			}

/* 			clock_t timeDifference = clock() - clockTimerStart;
			milSecs = timeDifference * 1000 / CLOCKS_PER_SEC;
 */
			turnOnLed0();
			turnOnLed1();
			turnOnLed2();
			turnOnLed3();
			/* 
				if (milSecs > 5000)
			{
				printf("Your reaction time was 5000ms; ");
				printf("best so far in game is  ");
				printf("%dms.\n", bestTime);
				

			} */

			if (milSecs > 5000)
			{
				printf("No input within 5000ms; quitting!\n");
				return 0;
			}
			else {
				if (milSecs < bestTime){
					bestTime = milSecs;
					printf("New best time!\n");
				}
				printf("Your reaction time was %dms; ", milSecs);
				printf("best so far in game is  ");
				printf("%dms.\n", bestTime);
			}

		}
	}
	
}
