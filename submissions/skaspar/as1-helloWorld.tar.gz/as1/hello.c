#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define LED0_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_TRIGGER_FILE_NAME "/sys/class/leds/beaglebone:green:usr3/trigger"

#define LED0_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_BRIGHTNESS_FILE_NAME "/sys/class/leds/beaglebone:green:usr3/brightness"

#define USER0_BUTTON_VALUE_FILE_NAME "/sys/class/gpio/gpio72/value"

static char* readFromFileToScreen(char *fileName){
	FILE *pFile = fopen(fileName, "r");
	if (pFile == NULL) {
	printf("ERROR: Unable to open file (%s) for read\n", fileName);
	exit(-1);
	}

	// Read string (line)
	const int MAX_LENGTH = 1024;
	char* buff = malloc(MAX_LENGTH);
	fgets(buff, MAX_LENGTH, pFile);
	// Close
	fclose(pFile);
	return buff;
}

static void writeToFile(char *fileName, char *valueToWrite){
	FILE *fileToEdit = fopen(fileName, "w");
	if (fileToEdit == NULL) {
		printf("ERROR OPENING %s\n", fileName);
		exit(1);
	}

	int charWritten = fprintf(fileToEdit, valueToWrite);
	if (charWritten <= 0) {
		printf("ERROR WRITING DATA");
		exit(1);
	}
	fclose(fileToEdit);
}

static void lightUpAllLEDS(){
	writeToFile(LED0_BRIGHTNESS_FILE_NAME, "1");
	writeToFile(LED1_BRIGHTNESS_FILE_NAME, "1");
	writeToFile(LED2_BRIGHTNESS_FILE_NAME, "1");
	writeToFile(LED3_BRIGHTNESS_FILE_NAME, "1");
}

static void turnOFFallLEDS(){
	writeToFile(LED0_BRIGHTNESS_FILE_NAME, "0");
	writeToFile(LED1_BRIGHTNESS_FILE_NAME, "0");
	writeToFile(LED2_BRIGHTNESS_FILE_NAME, "0");
	writeToFile(LED3_BRIGHTNESS_FILE_NAME, "0");
}

static long long getTimeInMs(void)		//returns time in ms
{
 struct timespec spec;
 clock_gettime(CLOCK_REALTIME, &spec);
 long long seconds = spec.tv_sec;
 long long nanoSeconds = spec.tv_nsec;
 long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
 return milliSeconds;
}

static void runCommand(char* command)
{
 // Execute the shell command (output into pipe)
 FILE *pipe = popen(command, "r");
 // Ignore output of the command; but consume it
 // so we don't get an error when closing the pipe.
 char buffer[1024];
 while (!feof(pipe) && !ferror(pipe)) {
 if (fgets(buffer, sizeof(buffer), pipe) == NULL)
 break;
 // printf("--> %s", buffer); // Uncomment for debugging
 }
 // Get the exit code from the pipe; non-zero is an error:
 int exitCode = WEXITSTATUS(pclose(pipe));
 if (exitCode != 0) {
 perror("Unable to execute command:");
 printf(" command: %s\n", command);
 printf(" exit code: %d\n", exitCode);
 }
}

static void sleepRandomTimeBetween500to3000mS(){
	long milliseconds = rand() % (3000L + 1L - 500L) + 500L;	//generate random number between 500 and 3000 ms
	long seconds = milliseconds / 1000;
	long nanoseconds = (milliseconds % 1000) * 1000000;
	//printf("%lu\n", milliseconds);
	struct timespec reqDelay = {seconds, nanoseconds};

	nanosleep(&reqDelay, (struct timespec *) NULL);		//sleep for generated time
}

static void sleepFor500mS(){
	long milliseconds = 500L;
	long seconds = milliseconds / 1000;
	long nanoseconds = (milliseconds % 1000) * 1000000;
	struct timespec reqDelay = {seconds, nanoseconds};

	nanosleep(&reqDelay, (struct timespec *) NULL);	
}

int main() {

	runCommand("config-pin p8.43 gpio");	//configuring user0 button as input

	srand(time(0));		//seeding for random number generation

	//setting LEDs triggers to none
	writeToFile(LED0_TRIGGER_FILE_NAME, "none");
	writeToFile(LED1_TRIGGER_FILE_NAME, "none");
	writeToFile(LED2_TRIGGER_FILE_NAME, "none");
	writeToFile(LED3_TRIGGER_FILE_NAME, "none");

	printf("Hello embedded world, from Sammy Kaspar!\n\n");
	printf("When LED3 lights up, press the USER button!\n");

	int i = 0;	//variable to store run number
	long long respnseTime =0;
	long long bestResponseTime =0;
	while(1){
		turnOFFallLEDS();
		//waiting while user holds user0 button
		while(1){
			if(readFromFileToScreen(USER0_BUTTON_VALUE_FILE_NAME)[0] == '1'){
				break;
			}
		}

		writeToFile(LED0_BRIGHTNESS_FILE_NAME, "1");

		sleepRandomTimeBetween500to3000mS();
		//check if user is pressing button before LED3 lights up
		if(readFromFileToScreen(USER0_BUTTON_VALUE_FILE_NAME)[0] == '0'){
			respnseTime = 5000;		//record reponse time of 5000ms
			if(i==0){		//if first run
				bestResponseTime = respnseTime;
			}
			else{			//if not first run
				if(respnseTime<bestResponseTime){
				bestResponseTime = respnseTime;
				printf("New best time!\n");
				} 
			}
			lightUpAllLEDS();
			//sleep for 0.5 secs before next round
			sleepFor500mS();
		}
		else{
			writeToFile(LED3_BRIGHTNESS_FILE_NAME, "1");	//light up LED3
			long long startTime = getTimeInMs();		//record start time

			while(1){
				//recording time
				respnseTime = getTimeInMs() - startTime;

				//quitting if no input within 5000mS
				if(respnseTime > 5000){
					printf("No input within 5000ms; quitting!\n");

					//restoring LED triggers
					writeToFile(LED0_TRIGGER_FILE_NAME, "heartbeat");
					writeToFile(LED1_TRIGGER_FILE_NAME, "mmc0");
					writeToFile(LED2_TRIGGER_FILE_NAME, "cpu0");
					writeToFile(LED3_TRIGGER_FILE_NAME, "mmc1");
					exit(1);
				}
				else{
					//user clicks button within 5000mS
					if(readFromFileToScreen(USER0_BUTTON_VALUE_FILE_NAME)[0] == '0'){
						respnseTime = getTimeInMs() - startTime;	//record response time
						if(i==0){		//if first run
							bestResponseTime = respnseTime;
							printf("New best time!\n");
						}
						else{			//if not first run
							if(respnseTime<bestResponseTime){
								bestResponseTime = respnseTime;
								printf("New best time!\n");
							} 
						}
						
						break;
					}
				}
			}
			lightUpAllLEDS();
			//sleep for 0.5 secs before next round
			sleepFor500mS();

		}
		printf("Your recation time was %llums; best so far in game is %llums;\n", respnseTime, bestResponseTime);
		i=i+1;		//increment round number
	}
	return 0;
}
