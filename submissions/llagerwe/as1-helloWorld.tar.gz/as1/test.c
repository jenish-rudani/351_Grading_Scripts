#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[])
{


    return 0;
}