// Hello-world time response game
// written by: Leighton Lagerwerf
// SFUID: 301295539
// Resources:
//-ENSC 351/Assignment 1/Sample code written by: Brian Fraser
//-Random number generator within a range:https://www.geeksforgeeks.org/generating-random-number-range-c/
//
// TO-DO LIST
//*display a hello-world welcome message
//-continuously loop through the following steps to play a game
//  -1) wait while user holds down USER (p8.43) button
//  -2) light up only LED0
//  -3) wait a random time (between 0.5s and 3.0s)
//  -4) if user is pressing the USER button already (too soon):
//   -record response time as 5.0s
//   -skip to "light up all LEDS" step
//  -5) light up LED3 & start timer
//  -6) when user presses USER button, stop timer
//   -if timer >5.0s, exit with a message without waiting for button press
//  -7) light up all LEDS
//  -8) display message:
//   -how many ms was the current response time?
//   -how many ms is the best response time so far this game?

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define LED0_TRIGGER "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1_TRIGGER "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2_TRIGGER "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3_TRIGGER "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED0_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3_BRIGHTNESS "/sys/class/leds/beaglebone:green:usr3/brightness"
#define USER_BUTTON "/sys/class/gpio/gpio72/value"

#define NONE "none"
#define ZERO "0"
#define ONE "1"

#define USER_GPIO "config-pin p8.43 gpio"

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;

    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;

    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}

static void runCommand(char *command)
{
    // Execute the shell command (output into pipe)
    FILE *pipe = popen(command, "r");

    // Ignore output of the command; but consume it
    // so we don't get an error when closing the pipe.
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
        // printf("--> %s", buffer); // Uncomment for debugging
    }

    // Get the exit code from the pipe; non-zero is an error:
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

void writeToFile(char *filename, char *data)
{
    FILE *pFile = fopen(filename, "w");
    if (pFile == NULL)
    {
        printf("ERROR: Unable to file.\n");
        exit(1);
    }
    // Write data to the file using fprint():
    fprintf(pFile, data);

    // Close the file using fclose():
    fclose(pFile);
}

int readFromFile(char *fileName)
{
    FILE *pFile = fopen(fileName, "r");
    if (pFile == NULL)
    {
        printf("ERROR: Unable to open file (%s) for read\n", fileName);
        exit(-1);
    }

    // Read string (line)
    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, pFile);

    // Close
    fclose(pFile);

    long temp = 0;
    char *ptr;
    temp = strtol(buff, &ptr, 10);

    return temp;
}

long long rndNum(void)
{
    long long num = (rand() % (3000 - 500 + 1)) + 500;
    return num;
}

int main(int argc, char *args[])
{
    long long reactionTime = 0;
    long long bestTime = 5001;
    long long timeOut = 5000;

    writeToFile(LED0_TRIGGER, NONE);
    writeToFile(LED1_TRIGGER, NONE);
    writeToFile(LED2_TRIGGER, NONE);
    writeToFile(LED3_TRIGGER, NONE);

    runCommand(USER_GPIO);

    printf("Hello embedded world, from Leighton!\n");
    printf("\n");
    printf("When LED3 lights up, press the USER button!\n");

    while (true)
    {
        writeToFile(LED0_BRIGHTNESS, ONE);
        writeToFile(LED1_BRIGHTNESS, ZERO);
        writeToFile(LED2_BRIGHTNESS, ZERO);
        writeToFile(LED3_BRIGHTNESS, ZERO);

        srand(time(0));
        long long waitRnd = 0;
        waitRnd = rndNum();

        sleepForMs(waitRnd);

        if(readFromFile(USER_BUTTON) == 0) {
            reactionTime = 5000;

            writeToFile(LED1_BRIGHTNESS, ONE);
            writeToFile(LED2_BRIGHTNESS, ONE);
            writeToFile(LED3_BRIGHTNESS, ONE);

            if(reactionTime < bestTime) {
                bestTime = reactionTime;
                printf("New best time!\n");
            }

            printf("Your reaction time was %4lldms; best so far in game is %4lldms!\n" ,reactionTime, bestTime);
        }

        else {
            writeToFile(LED3_BRIGHTNESS, ONE);

            long long startTime = 0;
            startTime = getTimeInMs();
            while(readFromFile(USER_BUTTON) == 1) {
                if((getTimeInMs() - startTime) > timeOut) {
                    printf("No input within 5000ms; quitting!\n");
                    exit(0);
                }
                //spin lock
            }

            long long stopTime = 0;
            stopTime = getTimeInMs();
                
            writeToFile(LED1_BRIGHTNESS, ONE);
            writeToFile(LED2_BRIGHTNESS, ONE);
            writeToFile(LED3_BRIGHTNESS, ONE);

            reactionTime = stopTime - startTime;
            if(reactionTime < bestTime) {
                bestTime = reactionTime;
                printf("New best time!\n");
            }

            printf("Your reaction time was %4lldms; best so far in game is %4lldms!\n" ,reactionTime, bestTime);
        }
    }

    return 0;
}