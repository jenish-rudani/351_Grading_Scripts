#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#define ButtonPath "/sys/class/gpio/gpio72/value"
#define LED0Trigger "/sys/class/leds/beaglebone:green:usr0/trigger"
#define LED1Trigger "/sys/class/leds/beaglebone:green:usr1/trigger"
#define LED2Trigger "/sys/class/leds/beaglebone:green:usr2/trigger"
#define LED3Trigger "/sys/class/leds/beaglebone:green:usr3/trigger"
#define LED0brightness "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1brightness "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2brightness "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3brightness "/sys/class/leds/beaglebone:green:usr3/brightness"


static void sleepForMs(long long delayInMs)
{
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *)NULL);
}

static void runCommand(char *command)
{
    FILE *pipe = popen(command, "r");
    char buffer[1024];

    while (!feof(pipe) && !ferror(pipe))
    {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL)
            break;
    }

    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0)
    {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

bool buttonPress()
{
    FILE *buttonFile = fopen(ButtonPath, "r");
    if (buttonFile == NULL)
    {
        printf("ERROR: User Button file is not accessible \n");
        printf("Error number: %d \n", errno);
        exit(-1);
    }

    const int MAX_LENGTH = 1024;
    char buff[MAX_LENGTH];
    fgets(buff, MAX_LENGTH, buttonFile);
    int buttonValue = atoi(buff);

    fclose(buttonFile);
    if (buttonValue == 0)
    {
        return true;
    }
    return false;
}

void led_0_OFF()
{
    FILE *lightOFF = fopen(LED0brightness, "w");
    if (lightOFF == NULL)
    {
        printf("ERROR: Opening brightness file for LED 0.");
        exit(1);
    }
    int charWritten = fprintf(lightOFF, "00");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 0 Brightness");
        exit(1);
    }
    fclose(lightOFF);

    FILE *triggerOFF = fopen(LED0Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 0.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 0 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void led_1_OFF()
{
    FILE *lightOFF = fopen(LED1brightness, "w");
    if (lightOFF == NULL)
    {
        printf("ERROR: Opening brightness file for LED 1.");
        exit(1);
    }
    int charWritten = fprintf(lightOFF, "00");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 1 Brightness");
        exit(1);
    }
    fclose(lightOFF);

    FILE *triggerOFF = fopen(LED1Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 1.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 1 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void led_2_OFF()
{
    FILE *lightOFF = fopen(LED2brightness, "w");
    if (lightOFF == NULL)
    {
        printf("ERROR: Opening brightness file for LED 2.");
        exit(1);
    }
    int charWritten = fprintf(lightOFF, "00");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 2 Brightness");
        exit(1);
    }
    fclose(lightOFF);

    FILE *triggerOFF = fopen(LED2Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 2.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 2 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void led_3_OFF()
{
    FILE *lightOFF = fopen(LED3brightness, "w");
    if (lightOFF == NULL)
    {
        printf("ERROR: Opening brightness file for LED 3.");
        exit(1);
    }
    int charWritten = fprintf(lightOFF, "00");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 3 Brightness");
        exit(1);
    }
    fclose(lightOFF);

    FILE *triggerOFF = fopen(LED3Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 3.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 3 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void led_0_ON()
{
    FILE *LightON = fopen(LED0brightness, "w");
    if (LightON == NULL)
    {
        printf("ERROR: Opening brightness file for LED 0.");
        exit(1);
    }
    int charWritten = fprintf(LightON, "1");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 0 Brightness");
        exit(1);
    }
    fclose(LightON);

    FILE *triggerOFF = fopen(LED0Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 0.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 0 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void led_1_ON()
{   
    FILE *LightON = fopen(LED1brightness, "w");
    if (LightON == NULL)
    {
        printf("ERROR: Opening brightness file for LED 1.");
        exit(1);
    }
    int charWritten = fprintf(LightON, "1");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 1 Brightness");
        exit(1);
    }
    fclose(LightON);

    FILE *triggerOFF = fopen(LED1Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 1.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 1 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}
void led_2_ON()
{
    FILE *LightON = fopen(LED2brightness, "w");
    if (LightON == NULL)
    {
        printf("ERROR: Opening brightness file for LED 2.");
        exit(1);
    }
    int charWritten = fprintf(LightON, "1");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 2 Brightness");
        exit(1);
    }
    fclose(LightON);

    FILE *triggerOFF = fopen(LED2Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 2.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 2 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void led_3_ON()
{
    FILE *LightON = fopen(LED3brightness, "w");
    if (LightON == NULL)
    {
        printf("ERROR: Opening brightness file for LED 3.");
        exit(1);
    }
    int charWritten = fprintf(LightON, "1");
    if (charWritten <= 0)
    {
        printf("ERROR: Changing LED 3 Brightness");
        exit(1);
    }
    fclose(LightON);

    FILE *triggerOFF = fopen(LED3Trigger, "w");
    if (triggerOFF == NULL)
    {
        printf("ERROR: Opeening Trigger file for LED 3.");
        exit(1);
    }
    int triggerValue = fprintf(triggerOFF, "none");
    if (triggerValue <= 0)
    {
        printf("ERROR: Changing LED 3 Trigger");
        exit(1);
    }
    fclose(triggerOFF);
}

void all_LED_On()
{
     led_0_ON();
     led_1_ON();
     led_2_ON();
     led_3_ON();
}

void aal_LED_Off()
{
    led_0_OFF();
    led_1_OFF();
    led_2_OFF();
    led_3_OFF();
}

static long long getTimeInMs(void)
{
    struct timespec spec;
    clock_gettime(CLOCK_REALTIME, &spec);
    long long seconds = spec.tv_sec;
    long long nanoSeconds = spec.tv_nsec;
    long long milliSeconds = seconds * 1000 + nanoSeconds / 1000000;
    return milliSeconds;
}

int main()
{
    printf("Hello Embedded World! from Navpreet Singh Sidhu \n\n");
    printf("When LED3 lights up please press the USER Button\n");

    runCommand("config-pin p8.43 gpio");
    runCommand("echo 72 > export");

    long long responseTime = 5000;
    long long bestResponseTime = 5000;
    while (true)
    {
        aal_LED_Off();
        sleepForMs(1500);
        led_0_ON();

        long long randomWaitingTime = (rand() % (3000 - 500) + 500);
        long long triggerTime = 0;
        long long startTime = getTimeInMs();
        bool buttonPressedInWaiting = true;
        do
        {
            if (buttonPress())
            {
                sleepForMs(500);
                buttonPressedInWaiting = false;
                break;
            }
            long long currentTime = getTimeInMs();
            triggerTime = currentTime - startTime;
        } while (triggerTime < randomWaitingTime);

        if (buttonPressedInWaiting)
        {
            led_3_ON();
            long long startUserTimer = getTimeInMs();
            long long stopUserTimer;
            do
            {
                if (buttonPress())
                {
                    stopUserTimer = getTimeInMs() - startUserTimer;
                    responseTime = stopUserTimer;
                    sleepForMs(500);
                    break;
                }
                else
                {
                    stopUserTimer = getTimeInMs() - startUserTimer;
                }
            } while (stopUserTimer <= 5000);

            if (stopUserTimer > 5000)
            {
                all_LED_On();
                printf("No input within 5 seconds; quitting\n");
                sleepForMs(2000);
                aal_LED_Off();
                exit(-1);
            }
        }
        all_LED_On();
        if (responseTime < bestResponseTime)
        {
            bestResponseTime = responseTime;
            printf("New Best time!\n");
        }
        if (buttonPressedInWaiting == false)
        {
            printf("Your reaction time was 5000;");
            printf("Best so far in game is (%lld) \n", bestResponseTime);
        }
        else
        {
            printf("Your reaction time was (%lld);", responseTime);
            printf("Best so far in game is (%lld) \n", bestResponseTime);
        }
        sleepForMs(1500);
    }
    return 0;
}
